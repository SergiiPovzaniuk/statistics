/**
 * Weryfikuje bezpieczeństwo przesyłanych załączników za pomocą usługi SecureFileGateway.
 * Dla każdego pliku oblicza hash, wywołuje serwis antywirusowy i sprawdza zgodność
 * rozszerzenia z zawartością (Tika). Wyniki cachuje w kontekście sesji.
 * Zwraca HTML z komunikatami o błędach dla plików uznanych za niebezpieczne.
 */
function callService(context) {
    const TARGET_SERVICE = 'ca-complaints-SecureFileGatewayServiceProxy';

    const imul = Math.imul || function(a, b) {
        const ah = (a >>> 16) & 0xffff, al = a & 0xffff;
        const bh = (b >>> 16) & 0xffff, bl = b & 0xffff;
        return ((al * bl) + (((ah * bl + al * bh) << 16) >>> 0)) | 0;
    };

    const fileContents = context.getParameters('fileContents');
    const rawFileNames = context.getParameters('fileNames');
    if (!rawFileNames || !fileContents) return { validationResultMessages: '' };

    const rawString = context.getFirstParameter('fileNames', null);
    if (!rawString) return { validationResultMessages: '' };

    const parsedFileNames = parseJson(rawString);
    if (!Array.isArray(parsedFileNames) || parsedFileNames.length === 0) return { validationResultMessages: '' };

    const contentsArray = fileContents.toArray();
    const cssClass = 'attachments-message-validation';

    let validatedSet = parseJson(context.getValue('validatedAttachments')) || {};
    if (Array.isArray(validatedSet)) {
        const tmp = {};
        for (let i = 0; i < validatedSet.length; i++) tmp[validatedSet[i]] = true;
        validatedSet = tmp;
    }

    let vulnerableMap = parseJson(context.getValue('vulnerableAttachments')) || {};
    for (let hash in vulnerableMap) {
        let entry = vulnerableMap[hash];
        if (entry && !Array.isArray(entry.fileNames)) {
            entry.fileNames = entry.fileName ? [String(entry.fileName)] : [];
        }
    }

    const currentBatchHashes = {};
    const currentBatchNames = {};
    const serviceFailureNames = [];

    for (let index = 0; index < parsedFileNames.length; index++) {
        let fileName = parsedFileNames[index];
        let fileContent = contentsArray[index];
        if (!fileContent) continue;

        let fileHash = calculateHash(fileContent);
        if (!fileHash) continue;

        currentBatchHashes[fileHash] = true;
        if (!currentBatchNames[fileHash]) currentBatchNames[fileHash] = [];
        if (currentBatchNames[fileHash].indexOf(fileName) === -1) currentBatchNames[fileHash].push(fileName);

        if (validatedSet.hasOwnProperty(fileHash)) continue;

        let rawResponse;
        try {
            rawResponse = context.callService(TARGET_SERVICE, {
                fileName: [fileName],
                fileContent: [fileContent],
                fileHash: [fileHash]
            });
        } catch (e) {
            Logger.error('Service call failed [file={}, error={}]', nonsensitive(fileName), e);
            serviceFailureNames.push(fileName);
            continue;
        }

        let resp = unwrapResponse(rawResponse);
        if (!resp) {
            serviceFailureNames.push(fileName);
            continue;
        }

        validatedSet[fileHash] = true;

        let avStatus = getField(resp, 'antivirusValidationStatus');
        let tikaStatus = getField(resp, 'tikaValidationStatus');

        if (avStatus !== 'OK' || tikaStatus !== 'AcceptedType') {
            vulnerableMap[fileHash] = {
                fileNames: [fileName],
                antivirusValidationStatus: avStatus,
                tikaValidationStatus: tikaStatus
            };
        }
    }

    const prunedValidatedSet = {};
    for (let hash in currentBatchHashes) {
        if (validatedSet.hasOwnProperty(hash)) prunedValidatedSet[hash] = true;
    }

    const prunedVulnerableMap = {};
    for (let hash in vulnerableMap) {
        if (!currentBatchNames.hasOwnProperty(hash)) continue;
        prunedVulnerableMap[hash] = {
            fileNames: currentBatchNames[hash],
            antivirusValidationStatus: vulnerableMap[hash].antivirusValidationStatus,
            tikaValidationStatus: vulnerableMap[hash].tikaValidationStatus
        };
    }

    context.setValue('validatedAttachments', JSON.stringify(prunedValidatedSet));
    context.setValue('vulnerableAttachments', JSON.stringify(prunedVulnerableMap));

    const messages = [];
    const seenNames = {};

    for (let hash in prunedVulnerableMap) {
        let info = prunedVulnerableMap[hash];
        let names = info.fileNames || [];
        for (let n = 0; n < names.length; n++) {
            let name = names[n];
            if (seenNames.hasOwnProperty(name)) continue;
            seenNames[name] = true;

            if (info.tikaValidationStatus !== 'AcceptedType') {
                messages.push('<p class="' + cssClass + '">Dodawany plik ' + escapeHtml(name) + ' zawiera zawartość niezgodną z rozszerzeniem!</p>');
            } else if (info.antivirusValidationStatus !== 'OK') {
                messages.push('<p class="' + cssClass + '">Nie można zapisać załącznika ' + escapeHtml(name) + '. Program antywirusowy wykrył podejrzaną zawartość pliku.</p>');
            }
        }
    }

    for (let f = 0; f < serviceFailureNames.length; f++) {
        let name = serviceFailureNames[f];
        if (seenNames.hasOwnProperty(name)) continue;
        seenNames[name] = true;
        messages.push('<p class="' + cssClass + '">Nie udało się zweryfikować bezpieczeństwa pliku ' + escapeHtml(name) + '. Spróbuj ponownie później.</p>');
    }

    return { validationResultMessages: messages.join('') };

    function calculateHash(bytes) {
        if (!bytes || typeof bytes.length === 'undefined') return null;

        let h1 = 0x12345678;
        const len = bytes.length;
        const remainder = len & 3;
        const chunks = len - remainder;
        let k1;

        for (let i = 0; i < chunks; i += 4) {
            k1 = (bytes[i] & 0xff) | ((bytes[i+1] & 0xff) << 8) | ((bytes[i+2] & 0xff) << 16) | ((bytes[i+3] & 0xff) << 24);
            k1 = imul(k1, 0xcc9e2d51); k1 = (k1 << 15) | (k1 >>> 17); k1 = imul(k1, 0x1b873593);
            h1 ^= k1; h1 = (h1 << 13) | (h1 >>> 19); h1 = imul(h1, 5) + 0xe6546b64;
        }

        k1 = 0;
        switch (remainder) {
            case 3: k1 ^= (bytes[chunks + 2] & 0xff) << 16;
            case 2: k1 ^= (bytes[chunks + 1] & 0xff) << 8;
            case 1: k1 ^= bytes[chunks] & 0xff;
                k1 = imul(k1, 0xcc9e2d51); k1 = (k1 << 15) | (k1 >>> 17); k1 = imul(k1, 0x1b873593);
                h1 ^= k1;
        }

        h1 ^= len; h1 ^= h1 >>> 16; h1 = imul(h1, 0x85ebca6b);
        h1 ^= h1 >>> 13; h1 = imul(h1, 0xc2b2ae35); h1 ^= h1 >>> 16;

        let hex = (h1 >>> 0).toString(16);
        while (hex.length < 8) hex = '0' + hex;
        return hex;
    }

    function parseJson(val) {
        try { return JSON.parse(String(val)); } catch (e) { return null; }
    }

    function getField(obj, key) {
        if (obj == null) return '';
        const val = typeof obj.get === 'function' ? obj.get(key) : obj[key];
        return val != null ? String(val) : '';
    }

    function unwrapResponse(raw) {
        let obj = typeof raw === 'string' ? parseJson(raw) : raw;
        if (!obj) return null;
        if (Array.isArray(obj)) obj = obj[0];
        else if (typeof obj.size === 'function' && typeof obj.get === 'function') obj = obj.get(0);
        if (typeof obj === 'string') obj = parseJson(obj);
        return obj || null;
    }

    function escapeHtml(str) {
        return str
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }
}
