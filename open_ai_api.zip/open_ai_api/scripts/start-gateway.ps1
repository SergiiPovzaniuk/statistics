$ErrorActionPreference = "Stop"
$root = Split-Path $PSScriptRoot -Parent
Set-Location $root

$envFile = Join-Path $root ".env"
if (Test-Path $envFile) {
  Get-Content $envFile | ForEach-Object {
    $line = $_.Trim()
    if (-not $line -or $line.StartsWith("#")) { return }
    $i = $line.IndexOf("=")
    if ($i -lt 1) { return }
    $name = $line.Substring(0, $i).Trim()
    $value = $line.Substring($i + 1).Trim()
    Set-Item -Path "Env:$name" -Value $value
  }
}

if (-not $env:UPSTREAM_BASE_URL) { $env:UPSTREAM_BASE_URL = "http://46.174.75.130:8094" }
if (-not $env:UPSTREAM_PAGE_URL) { $env:UPSTREAM_PAGE_URL = "http://46.174.75.130:8094/" }
if (-not $env:TRANSPORT_KEY) { $env:TRANSPORT_KEY = "dev-shared-transport-key" }

Write-Host "UPSTREAM_BASE_URL=$env:UPSTREAM_BASE_URL"
Write-Host "UPSTREAM_PAGE_URL=$env:UPSTREAM_PAGE_URL"
Write-Host "UPSTREAM_HEADLESS=$env:UPSTREAM_HEADLESS"
Write-Host "TRANSPORT_KEY set=$([bool]$env:TRANSPORT_KEY)"

& .\mvnw.cmd spring-boot:run
