package com.openaiapi;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

@SpringBootTest
@AutoConfigureMockMvc
class ChatCompletionsIT {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void health() throws Exception {
        mockMvc.perform(get("/health"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("ok"));
    }

    @Test
    void listModels() throws Exception {
        mockMvc.perform(get("/v1/models"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.object").value("list"))
                .andExpect(jsonPath("$.data[0].id").value("dummy-gpt"));
    }

    @Test
    void textCompletionWithoutTools() throws Exception {
        String body = """
                {
                  "model": "dummy-gpt",
                  "messages": [{"role": "user", "content": "hello"}]
                }
                """;
        mockMvc.perform(post("/v1/chat/completions").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.choices[0].finish_reason").value("stop"))
                .andExpect(jsonPath("$.choices[0].message.content").value("Dummy reply to: hello"));
    }

    @Test
    void toolCallsWhenToolsPresent() throws Exception {
        String body = """
                {
                  "model": "dummy-tools",
                  "messages": [{"role": "user", "content": "read the readme"}],
                  "tools": [{
                    "type": "function",
                    "function": {
                      "name": "read_file",
                      "description": "Read a file",
                      "parameters": {
                        "type": "object",
                        "properties": {"filePath": {"type": "string"}},
                        "required": ["filePath"]
                      }
                    }
                  }]
                }
                """;
        MvcResult toolResult = mockMvc.perform(post("/v1/chat/completions")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.choices[0].finish_reason").value("tool_calls"))
                .andExpect(jsonPath("$.choices[0].message.tool_calls[0].function.name").value("read_file"))
                .andReturn();
        String content = toolResult.getResponse().getContentAsString();
        assertThat(content).contains("filePath").contains("README.md");
        assertThat(content).containsPattern("([A-Za-z]:\\\\\\\\|/).*README\\.md");
    }

    @Test
    void finalAnswerAfterToolResult() throws Exception {
        String body = """
                {
                  "model": "dummy-gpt",
                  "messages": [
                    {"role": "user", "content": "read the readme"},
                    {
                      "role": "assistant",
                      "tool_calls": [{
                        "id": "call_1",
                        "type": "function",
                        "function": {"name": "read_file", "arguments": "{\\"path\\":\\"README.md\\"}"}
                      }]
                    },
                    {"role": "tool", "tool_call_id": "call_1", "content": "# OpenAI Dummy"}
                  ],
                  "tools": [{
                    "type": "function",
                    "function": {"name": "read_file", "parameters": {"type": "object"}}
                  }]
                }
                """;
        mockMvc.perform(post("/v1/chat/completions").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.choices[0].finish_reason").value("stop"))
                .andExpect(jsonPath("$.choices[0].message.content")
                        .value("Dummy provider received tool result: # OpenAI Dummy"));
    }

    @Test
    void streamRequestReturnsSseForClient() throws Exception {
        String body = """
                {
                  "model": "dummy-fast",
                  "stream": true,
                  "messages": [{"role": "user", "content": "hi"}]
                }
                """;
        MvcResult result = mockMvc.perform(post("/v1/chat/completions")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isOk())
                .andReturn();
        String response = result.getResponse().getContentAsString();
        assertThat(response).contains("data: ").contains("[DONE]").contains("chat.completion.chunk");
        assertThat(response.trim()).endsWith("data: [DONE]");
    }
}
