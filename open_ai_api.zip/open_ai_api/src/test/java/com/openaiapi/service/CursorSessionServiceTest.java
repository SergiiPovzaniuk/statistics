package com.openaiapi.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.openaiapi.api.dto.ChatCompletionRequest;
import com.openaiapi.config.AppProperties;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class CursorSessionServiceTest {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private AppProperties appProperties;
    private CursorSessionService service;

    @BeforeEach
    void setUp() {
        appProperties = new AppProperties();
        appProperties.getUpstream().setSessionResume(true);
        appProperties.getUpstream().setCursorCwd("/workspace/project");
        service = new CursorSessionService(appProperties);
    }

    @Test
    void injectsCwdFromConfig() {
        ChatCompletionRequest request = new ChatCompletionRequest();
        request.setModel("composer-2.5");
        request.setMessages(java.util.List.of());

        service.prepareRequest(request);

        assertThat(request.getCursor()).isNotNull();
        assertThat(request.getCursor().getCwd()).isEqualTo("/workspace/project");
    }

    @Test
    void toolsForceAskModeAndSkipHostCwd() {
        ChatCompletionRequest request = new ChatCompletionRequest();
        request.setModel("composer-2.5");
        request.setMessages(java.util.List.of());
        com.openaiapi.api.dto.ToolDefinition tool = new com.openaiapi.api.dto.ToolDefinition();
        request.setTools(java.util.List.of(tool));

        service.prepareRequest(request);

        assertThat(request.getCursor().getMode()).isEqualTo("ask");
        assertThat(request.getCursor().getCwd()).isNull();
    }

    @Test
    void resumesAgentIdFromStoredSession() {
        ObjectNode response = objectMapper.createObjectNode();
        response.put("model", "composer-2.5");
        ObjectNode cursor = response.putObject("cursor");
        cursor.put("agentId", "session-abc");
        cursor.put("runId", "run-1");
        cursor.put("status", "finished");
        service.recordFromResponse(response);

        ChatCompletionRequest request = new ChatCompletionRequest();
        request.setModel("composer-2.5");
        request.setMessages(java.util.List.of());
        service.prepareRequest(request);

        assertThat(request.getCursor().getAgentId()).isEqualTo("session-abc");
    }

    @Test
    void doesNotOverrideExplicitAgentId() {
        ObjectNode response = objectMapper.createObjectNode();
        response.put("model", "composer-2.5");
        ObjectNode cursor = response.putObject("cursor");
        cursor.put("agentId", "stored-session");
        service.recordFromResponse(response);

        ChatCompletionRequest request = new ChatCompletionRequest();
        request.setModel("composer-2.5");
        request.setMessages(java.util.List.of());
        ChatCompletionRequest.CursorOptions cursorOpts = new ChatCompletionRequest.CursorOptions();
        cursorOpts.setAgentId("explicit-session");
        request.setCursor(cursorOpts);
        service.prepareRequest(request);

        assertThat(request.getCursor().getAgentId()).isEqualTo("explicit-session");
    }
}
