package com.openaiapi.provider.dummy;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.openaiapi.api.dto.ChatCompletionRequest;
import com.openaiapi.api.dto.ChatCompletionResponse;
import com.openaiapi.api.dto.ChatMessage;
import com.openaiapi.api.dto.ToolCall;
import com.openaiapi.api.dto.ToolDefinition;
import com.openaiapi.config.AppProperties;
import com.openaiapi.provider.ChatCompletionProvider;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import org.springframework.stereotype.Component;

@Component
public class DummyChatProvider implements ChatCompletionProvider {

    private static final Set<String> PREFERRED_TOOLS = Set.of(
            "read_file",
            "readFile",
            "run_in_terminal",
            "runInTerminal",
            "execute_command",
            "bash");

    private final ObjectMapper objectMapper;
    private final String sampleFile;
    private final String sampleDir;

    public DummyChatProvider(ObjectMapper objectMapper, AppProperties appProperties) {
        this.objectMapper = objectMapper;
        Path file = Path.of(appProperties.getDummy().getSampleFile()).toAbsolutePath().normalize();
        this.sampleFile = file.toString();
        this.sampleDir = file.getParent() != null ? file.getParent().toString() : file.toString();
    }

    @Override
    public String id() {
        return "dummy";
    }

    @Override
    public ChatCompletionResponse complete(ChatCompletionRequest request) {
        String model = request.getModel() == null ? "dummy-gpt" : request.getModel();
        String finishReason;
        ChatCompletionResponse.ResponseMessage message = new ChatCompletionResponse.ResponseMessage();
        message.setRole("assistant");

        if (shouldCallTool(request)) {
            ToolDefinition tool = selectTool(request);
            ToolCall call = buildToolCall(tool);
            message.setContent(null);
            message.setToolCalls(List.of(call));
            finishReason = "tool_calls";
        } else {
            message.setContent(buildTextReply(request));
            finishReason = "stop";
        }

        ChatCompletionResponse.Choice choice = new ChatCompletionResponse.Choice();
        choice.setIndex(0);
        choice.setMessage(message);
        choice.setFinishReason(finishReason);

        ChatCompletionResponse response = new ChatCompletionResponse();
        response.setId("chatcmpl-" + UUID.randomUUID().toString().replace("-", "").substring(0, 24));
        response.setCreated(System.currentTimeMillis() / 1000);
        response.setModel(model);
        response.setChoices(List.of(choice));
        response.setUsage(new ChatCompletionResponse.Usage(16, 32));
        return response;
    }

    private boolean shouldCallTool(ChatCompletionRequest request) {
        List<ToolDefinition> tools = request.getTools();
        if (tools == null || tools.isEmpty()) {
            return false;
        }
        if (isToolChoiceNone(request.getToolChoice())) {
            return false;
        }
        if (lastRoleIsTool(request.getMessages())) {
            return false;
        }
        return true;
    }

    private boolean isToolChoiceNone(JsonNode toolChoice) {
        return toolChoice != null && toolChoice.isTextual() && "none".equalsIgnoreCase(toolChoice.asText());
    }

    private boolean lastRoleIsTool(List<ChatMessage> messages) {
        if (messages == null || messages.isEmpty()) {
            return false;
        }
        String role = messages.getLast().getRole();
        return role != null && "tool".equalsIgnoreCase(role);
    }

    private ToolDefinition selectTool(ChatCompletionRequest request) {
        JsonNode toolChoice = request.getToolChoice();
        if (toolChoice != null && toolChoice.isObject()) {
            JsonNode nameNode = toolChoice.path("function").path("name");
            if (!nameNode.isMissingNode() && !nameNode.asText().isBlank()) {
                String forced = nameNode.asText();
                return request.getTools().stream()
                        .filter(t -> t.getFunction() != null && forced.equals(t.getFunction().getName()))
                        .findFirst()
                        .orElseGet(() -> namedStub(forced));
            }
        }
        return request.getTools().stream()
                .filter(t -> t.getFunction() != null && PREFERRED_TOOLS.contains(t.getFunction().getName()))
                .findFirst()
                .orElse(request.getTools().getFirst());
    }

    private ToolDefinition namedStub(String name) {
        ToolDefinition.FunctionDefinition fn = new ToolDefinition.FunctionDefinition();
        fn.setName(name);
        ToolDefinition tool = new ToolDefinition();
        tool.setFunction(fn);
        return tool;
    }

    private ToolCall buildToolCall(ToolDefinition tool) {
        String name = tool.getFunction() != null ? tool.getFunction().getName() : "unknown";
        JsonNode parameters = tool.getFunction() != null ? tool.getFunction().getParameters() : null;
        ToolCall.FunctionCall fn = new ToolCall.FunctionCall();
        fn.setName(name);
        fn.setArguments(argumentsFor(name, parameters));

        ToolCall call = new ToolCall();
        call.setId("call_" + UUID.randomUUID().toString().replace("-", "").substring(0, 16));
        call.setType("function");
        call.setFunction(fn);
        return call;
    }

    private String argumentsFor(String name, JsonNode parameters) {
        ObjectNode args = objectMapper.createObjectNode();
        if (parameters != null && parameters.isObject()) {
            JsonNode properties = parameters.path("properties");
            JsonNode required = parameters.path("required");
            if (required.isArray() && !required.isEmpty()) {
                for (JsonNode req : required) {
                    putDefault(args, req.asText(), properties.path(req.asText()), name);
                }
            } else if (properties.isObject() && properties.size() > 0) {
                Iterator<String> names = properties.fieldNames();
                while (names.hasNext()) {
                    String prop = names.next();
                    putDefault(args, prop, properties.path(prop), name);
                }
            }
        }
        if (args.isEmpty()) {
            String lower = name.toLowerCase(Locale.ROOT);
            if (lower.contains("read") || lower.contains("file")) {
                args.put("filePath", sampleFile);
            } else if (lower.contains("terminal")
                    || lower.contains("bash")
                    || lower.contains("command")
                    || lower.contains("shell")) {
                args.put("command", "echo dummy-gateway");
            }
        }
        return args.toString();
    }

    private void putDefault(ObjectNode args, String prop, JsonNode schema, String toolName) {
        if (prop == null || prop.isBlank() || args.has(prop)) {
            return;
        }
        String type = schema != null ? schema.path("type").asText("string") : "string";
        String key = prop.toLowerCase(Locale.ROOT);
        String value = valueForProperty(key, type, toolName);
        if ("boolean".equals(type)) {
            args.put(prop, Boolean.parseBoolean(value));
        } else if ("integer".equals(type) || "number".equals(type)) {
            args.put(prop, 1);
        } else if ("array".equals(type)) {
            args.putArray(prop);
        } else if ("object".equals(type)) {
            args.putObject(prop);
        } else {
            args.put(prop, value);
        }
    }

    private String valueForProperty(String key, String type, String toolName) {
        if ("boolean".equals(type)) {
            return "false";
        }
        if (key.contains("command") || key.contains("cmd") || key.contains("script")) {
            return "echo dummy-gateway";
        }
        if (key.contains("workdir") || key.equals("cwd") || key.contains("directory") || key.equals("dir")) {
            return sampleDir;
        }
        if (key.contains("path")
                || key.contains("file")
                || key.contains("uri")
                || key.contains("glob")
                || "filename".equals(key)) {
            return sampleFile;
        }
        if (key.contains("pattern") || key.contains("query")) {
            return "*";
        }
        String lower = toolName.toLowerCase(Locale.ROOT);
        if (lower.contains("read") || lower.contains("file")) {
            return sampleFile;
        }
        if (lower.contains("terminal") || lower.contains("command") || lower.contains("shell")) {
            return "echo dummy-gateway";
        }
        return "dummy";
    }

    private String buildTextReply(ChatCompletionRequest request) {
        if (lastRoleIsTool(request.getMessages())) {
            String toolContent = extractContent(request.getMessages().getLast());
            return "Dummy provider received tool result: " + truncate(toolContent, 200);
        }
        String user = lastUserContent(request.getMessages());
        if (user == null || user.isBlank()) {
            return "Hello from dummy-gateway.";
        }
        return "Dummy reply to: " + truncate(user, 200);
    }

    private String lastUserContent(List<ChatMessage> messages) {
        if (messages == null) {
            return null;
        }
        for (int i = messages.size() - 1; i >= 0; i--) {
            ChatMessage m = messages.get(i);
            if (m.getRole() != null && "user".equalsIgnoreCase(m.getRole())) {
                return extractContent(m);
            }
        }
        return null;
    }

    private String extractContent(ChatMessage message) {
        JsonNode content = message.getContent();
        if (content == null || content.isNull()) {
            return "";
        }
        if (content.isTextual()) {
            return content.asText();
        }
        if (content.isArray()) {
            StringBuilder sb = new StringBuilder();
            for (JsonNode part : content) {
                if (part.has("text")) {
                    if (!sb.isEmpty()) {
                        sb.append(' ');
                    }
                    sb.append(part.get("text").asText(""));
                }
            }
            return sb.toString();
        }
        return content.toString();
    }

    private String truncate(String value, int max) {
        if (value == null) {
            return "";
        }
        return value.length() <= max ? value : value.substring(0, max) + "...";
    }
}
