package com.openaiapi.provider;

import com.openaiapi.config.AppProperties;
import com.openaiapi.provider.cursor.CursorUiProxyProvider;
import com.openaiapi.provider.dummy.DummyChatProvider;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import org.springframework.stereotype.Component;

@Component
public class ProviderRegistry {

    private final Map<String, ChatCompletionProvider> providers;
    private final ChatCompletionProvider defaultProvider;

    public ProviderRegistry(
            List<ChatCompletionProvider> providers,
            AppProperties appProperties,
            CursorUiProxyProvider cursorUiProxyProvider,
            DummyChatProvider dummyChatProvider) {
        this.providers = providers.stream()
                .collect(Collectors.toMap(ChatCompletionProvider::id, Function.identity(), (a, b) -> a));
        this.defaultProvider = appProperties.getUpstream().isEnabled()
                ? cursorUiProxyProvider
                : dummyChatProvider;
    }

    public ChatCompletionProvider resolve(String model) {
        if (model != null && providers.containsKey(model)) {
            return providers.get(model);
        }
        return defaultProvider;
    }
}
