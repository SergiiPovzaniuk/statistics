package com.openaiapi.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.openaiapi.api.dto.ChatCompletionRequest;
import com.openaiapi.config.AppProperties;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class CursorSessionService {

    private final AppProperties appProperties;
    private final Map<String, String> agentIdsByModel = new ConcurrentHashMap<>();

    public CursorSessionService(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    public void prepareRequest(ChatCompletionRequest request) {
        if (request == null) {
            return;
        }
        ChatCompletionRequest.CursorOptions cursor = request.getCursor();
        if (cursor == null) {
            cursor = new ChatCompletionRequest.CursorOptions();
            request.setCursor(cursor);
        }

        boolean hasTools = request.getTools() != null && !request.getTools().isEmpty();
        if (hasTools) {
            cursor.setMode("ask");
            cursor.setCwd(null);
        } else {
            String cwd = appProperties.getUpstream().getCursorCwd();
            if (StringUtils.hasText(cwd) && !StringUtils.hasText(cursor.getCwd())) {
                cursor.setCwd(cwd);
            }
        }

        if (!appProperties.getUpstream().isSessionResume()) {
            return;
        }
        if (StringUtils.hasText(cursor.getAgentId()) || !StringUtils.hasText(request.getModel())) {
            return;
        }
        String stored = agentIdsByModel.get(request.getModel());
        if (StringUtils.hasText(stored)) {
            cursor.setAgentId(stored);
        }
    }

    public void recordFromResponse(JsonNode response) {
        if (!appProperties.getUpstream().isSessionResume() || response == null) {
            return;
        }
        JsonNode cursor = response.path("cursor");
        if (cursor.isMissingNode() || cursor.isNull()) {
            return;
        }
        String agentId = cursor.path("agentId").asText(null);
        String model = response.path("model").asText(null);
        if (StringUtils.hasText(agentId) && StringUtils.hasText(model)) {
            agentIdsByModel.put(model, agentId);
        }
    }
}
