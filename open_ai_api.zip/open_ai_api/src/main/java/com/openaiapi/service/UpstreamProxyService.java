package com.openaiapi.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.openaiapi.api.dto.ChatCompletionRequest;
import com.openaiapi.api.dto.ModelListResponse;
import com.openaiapi.api.dto.ModelObject;
import com.openaiapi.config.AppProperties;
import com.openaiapi.playwright.PlaywrightUiTransport;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.server.ResponseStatusException;

@Service
public class UpstreamProxyService {

    private final AppProperties appProperties;
    private final ObjectMapper objectMapper;
    private final RestClient restClient;
    private final PlaywrightUiTransport playwrightUiTransport;
    private final CursorSessionService cursorSessionService;

    public UpstreamProxyService(
            AppProperties appProperties,
            ObjectMapper objectMapper,
            PlaywrightUiTransport playwrightUiTransport,
            CursorSessionService cursorSessionService) {
        this.appProperties = appProperties;
        this.objectMapper = objectMapper;
        this.playwrightUiTransport = playwrightUiTransport;
        this.cursorSessionService = cursorSessionService;
        org.springframework.http.client.SimpleClientHttpRequestFactory factory =
                new org.springframework.http.client.SimpleClientHttpRequestFactory();
        factory.setConnectTimeout(30_000);
        factory.setReadTimeout(Math.max(60_000, appProperties.getUpstream().getResponseTimeoutMs()));
        this.restClient = RestClient.builder().requestFactory(factory).build();
    }

    public boolean isEnabled() {
        return appProperties.getUpstream().isEnabled();
    }

    public Map<String, String> proxyHealth() {
        return restClient.get()
                .uri(url(appProperties.getUpstream().getHealthPath()))
                .retrieve()
                .body(new org.springframework.core.ParameterizedTypeReference<Map<String, String>>() {});
    }

    public ModelListResponse proxyModels() {
        var spec = restClient.get().uri(url(appProperties.getUpstream().getModelsPath()));
        String apiKey = appProperties.getUpstream().getApiKey();
        if (apiKey != null && !apiKey.isBlank()) {
            spec = spec.header("Authorization", "Bearer " + apiKey);
        }
        try {
            return spec.retrieve().body(ModelListResponse.class);
        } catch (RestClientResponseException ex) {
            throw new ResponseStatusException(HttpStatus.valueOf(ex.getStatusCode().value()), ex.getResponseBodyAsString());
        }
    }

    public ModelObject proxyModel(String id) {
        ModelListResponse list = proxyModels();
        return list.getData().stream()
                .filter(m -> id.equals(m.getId()))
                .findFirst()
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Model not found: " + id));
    }

    public JsonNode proxyChatJson(ChatCompletionRequest request) {
        boolean needsUpstreamReset = cursorSessionService.prepareRequest(request);
        if (needsUpstreamReset) {
            try {
                proxyUiReset();
            } catch (Exception ignored) {
                // best-effort: chat must still proceed with a fresh session
            }
        }
        if (appProperties.getUpstream().isUsePlaywright()) {
            return playwrightUiTransport.proxyChat(request);
        }
        ObjectNode body = objectMapper.valueToTree(request);
        body.put("stream", false);
        return postChat(body);
    }

    public Map<String, Object> proxyUiReset() {
        try {
            @SuppressWarnings("unchecked")
            Map<String, Object> body = restClient.post()
                    .uri(url("/ui/reset"))
                    .retrieve()
                    .body(Map.class);
            return body != null ? body : Map.of("status", "ok");
        } catch (RestClientResponseException ex) {
            throw upstreamError(ex);
        }
    }

    private JsonNode postChat(JsonNode body) {
        var spec = restClient.post()
                .uri(url(appProperties.getUpstream().getChatPath()))
                .contentType(MediaType.APPLICATION_JSON)
                .body(body);
        String apiKey = appProperties.getUpstream().getApiKey();
        if (apiKey != null && !apiKey.isBlank()) {
            spec = spec.header("Authorization", "Bearer " + apiKey);
        }
        try {
            return spec.retrieve().body(JsonNode.class);
        } catch (RestClientResponseException ex) {
            throw upstreamError(ex);
        }
    }

    private String url(String path) {
        String base = appProperties.getUpstream().getBaseUrl().replaceAll("/$", "");
        String p = path.startsWith("/") ? path : "/" + path;
        return base + p;
    }

    private ResponseStatusException upstreamError(RestClientResponseException ex) {
        return new ResponseStatusException(HttpStatus.valueOf(ex.getStatusCode().value()), ex.getResponseBodyAsString());
    }
}
