package com.openaiapi.service;

import com.openaiapi.api.dto.ModelListResponse;
import com.openaiapi.api.dto.ModelObject;
import com.openaiapi.config.AppProperties;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.server.ResponseStatusException;

@Service
public class ModelService {

    private final AppProperties appProperties;
    private final UpstreamProxyService upstreamProxyService;
    private final long created = System.currentTimeMillis() / 1000;

    public ModelService(AppProperties appProperties, UpstreamProxyService upstreamProxyService) {
        this.appProperties = appProperties;
        this.upstreamProxyService = upstreamProxyService;
    }

    public ModelListResponse list() {
        if (upstreamProxyService.isEnabled()) {
            ModelListResponse upstream = upstreamProxyService.proxyModels();
            return new ModelListResponse(enrich(upstream.getData()));
        }
        return new ModelListResponse(enrich(appProperties.getModels().stream().map(this::toModel).toList()));
    }

    public ModelObject get(String id) {
        if (upstreamProxyService.isEnabled()) {
            return enrich(upstreamProxyService.proxyModel(id));
        }
        return appProperties.getModels().stream()
                .filter(m -> m.getId().equals(id))
                .findFirst()
                .map(this::toModel)
                .map(this::enrich)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Model not found: " + id));
    }

    private ModelObject toModel(AppProperties.ModelConfig config) {
        ModelObject model = new ModelObject();
        model.setId(config.getId());
        model.setName(config.getName());
        model.setCreated(created);
        return model;
    }

    private List<ModelObject> enrich(List<ModelObject> models) {
        if (models == null) {
            return List.of();
        }
        return models.stream().map(this::enrich).toList();
    }

    private ModelObject enrich(ModelObject model) {
        if (!StringUtils.hasText(model.getName())) {
            model.setName(model.getId());
        }
        long contextWindow = appProperties.getModelDefaults().getMaxModelLen();
        if (model.getMaxModelLen() == null || model.getMaxModelLen() <= 0) {
            model.setMaxModelLen(contextWindow);
        }
        if (model.getContextLength() == null || model.getContextLength() <= 0) {
            model.setContextLength(model.getMaxModelLen());
        }
        return model;
    }
}
