package com.openaiapi.api;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import org.springframework.web.util.ContentCachingRequestWrapper;

@Component
public class RequestLoggingFilter extends OncePerRequestFilter {

    private static final Logger log = LoggerFactory.getLogger(RequestLoggingFilter.class);

    @Override
    protected void doFilterInternal(
            HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        ContentCachingRequestWrapper wrapped = new ContentCachingRequestWrapper(request);
        try {
            filterChain.doFilter(wrapped, response);
        } finally {
            if (wrapped.getRequestURI().contains("/v1/")) {
                byte[] buf = wrapped.getContentAsByteArray();
                String body = buf.length == 0
                        ? ""
                        : new String(buf, 0, Math.min(buf.length, 4000), StandardCharsets.UTF_8);
                log.info("{} {} -> {} body={}", wrapped.getMethod(), wrapped.getRequestURI(), response.getStatus(), body);
            }
        }
    }
}
