package com.openaiapi.api;

import com.openaiapi.playwright.BrowserNotReadyException;
import com.openaiapi.playwright.PlaywrightAutomationException;
import com.openaiapi.playwright.PlaywrightBrowserSession;
import com.openaiapi.service.UpstreamProxyService;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
public class PlaywrightReadinessFilter extends OncePerRequestFilter {

    private final UpstreamProxyService upstreamProxyService;
    private final PlaywrightBrowserSession browserSession;

    public PlaywrightReadinessFilter(
            UpstreamProxyService upstreamProxyService, PlaywrightBrowserSession browserSession) {
        this.upstreamProxyService = upstreamProxyService;
        this.browserSession = browserSession;
    }

    @Override
    protected void doFilterInternal(
            jakarta.servlet.http.HttpServletRequest request,
            HttpServletResponse response,
            jakarta.servlet.FilterChain filterChain)
            throws IOException, jakarta.servlet.ServletException {
        if (upstreamProxyService.isEnabled()
                && request.getRequestURI().contains("/v1/chat/completions")
                && !browserSession.isReady()) {
            response.sendError(HttpServletResponse.SC_SERVICE_UNAVAILABLE, "Playwright session is starting");
            return;
        }
        filterChain.doFilter(request, response);
    }
}
