package com.openaiapi.api.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ModelObject {

    private String id;
    private String name;
    private String object = "model";
    private long created;
    private String ownedBy = "open-ai-api";
    private Long maxModelLen;
    private Long contextLength;

    public String getOwnedBy() {
        return ownedBy;
    }

    public void setOwnedBy(String ownedBy) {
        this.ownedBy = ownedBy;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getObject() {
        return object;
    }

    public void setObject(String object) {
        this.object = object;
    }

    public long getCreated() {
        return created;
    }

    public void setCreated(long created) {
        this.created = created;
    }

    public Long getMaxModelLen() {
        return maxModelLen;
    }

    public void setMaxModelLen(Long maxModelLen) {
        this.maxModelLen = maxModelLen;
    }

    public Long getContextLength() {
        return contextLength;
    }

    public void setContextLength(Long contextLength) {
        this.contextLength = contextLength;
    }
}
