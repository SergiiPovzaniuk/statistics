package com.openaiapi.api;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.openaiapi.api.dto.ChatCompletionRequest;
import com.openaiapi.api.dto.ModelListResponse;
import com.openaiapi.api.dto.ModelObject;
import com.openaiapi.service.ChatCompletionService;
import com.openaiapi.service.ModelService;
import com.openaiapi.service.StreamAdapterService;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1")
public class OpenAiController {

    private final ChatCompletionService chatCompletionService;
    private final ModelService modelService;
    private final StreamAdapterService streamAdapterService;
    private final ObjectMapper objectMapper;

    public OpenAiController(
            ChatCompletionService chatCompletionService,
            ModelService modelService,
            StreamAdapterService streamAdapterService,
            ObjectMapper objectMapper) {
        this.chatCompletionService = chatCompletionService;
        this.modelService = modelService;
        this.streamAdapterService = streamAdapterService;
        this.objectMapper = objectMapper;
    }

    @GetMapping("/models")
    public ModelListResponse listModels() {
        return modelService.list();
    }

    @GetMapping("/models/{id}")
    public ModelObject getModel(@PathVariable String id) {
        return modelService.get(id);
    }

    @PostMapping(
            value = "/chat/completions",
            produces = {MediaType.APPLICATION_JSON_VALUE, "text/event-stream"})
    public void chatCompletions(@RequestBody ChatCompletionRequest request, HttpServletResponse response)
            throws IOException {
        boolean streamToClient = request.isStream();
        request.setStream(false);
        JsonNode completion = chatCompletionService.completeJson(request);

        if (streamToClient) {
            response.setStatus(HttpServletResponse.SC_OK);
            response.setCharacterEncoding(StandardCharsets.UTF_8.name());
            response.setContentType("text/event-stream");
            response.setHeader("Cache-Control", "no-cache");
            response.setHeader("Connection", "keep-alive");
            streamAdapterService.writeAsSse(completion, response.getWriter());
            return;
        }

        response.setStatus(HttpServletResponse.SC_OK);
        response.setCharacterEncoding(StandardCharsets.UTF_8.name());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        objectMapper.writeValue(response.getWriter(), completion);
    }
}
