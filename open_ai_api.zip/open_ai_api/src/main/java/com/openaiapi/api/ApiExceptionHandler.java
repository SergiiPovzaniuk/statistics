package com.openaiapi.api;

import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import com.openaiapi.playwright.BrowserNotReadyException;
import com.openaiapi.playwright.PlaywrightAutomationException;

@RestControllerAdvice
public class ApiExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(ApiExceptionHandler.class);

    @ExceptionHandler(BrowserNotReadyException.class)
    public ResponseEntity<Map<String, Object>> browserNotReady(BrowserNotReadyException ex) {
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(error("browser_not_ready", ex.getMessage()));
    }

    @ExceptionHandler(PlaywrightAutomationException.class)
    public ResponseEntity<Map<String, Object>> playwrightError(PlaywrightAutomationException ex) {
        log.warn("Playwright automation error: {}", ex.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                .body(error("playwright_error", ex.getMessage()));
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, Object>> badJson(HttpMessageNotReadableException ex) {
        log.warn("Bad request body: {}", ex.getMostSpecificCause().getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(error("invalid_request_error", ex.getMostSpecificCause().getMessage()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> other(Exception ex) {
        log.error("Unhandled error", ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(error("server_error", ex.getMessage() == null ? "internal error" : ex.getMessage()));
    }

    private Map<String, Object> error(String type, String message) {
        return Map.of("error", Map.of("message", message, "type", type));
    }
}
