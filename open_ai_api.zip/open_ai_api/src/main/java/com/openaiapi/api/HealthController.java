package com.openaiapi.api;

import com.openaiapi.service.UpstreamProxyService;
import java.util.Map;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HealthController {

    private final UpstreamProxyService upstreamProxyService;

    public HealthController(UpstreamProxyService upstreamProxyService) {
        this.upstreamProxyService = upstreamProxyService;
    }

    @GetMapping("/health")
    public Map<String, String> health() {
        if (upstreamProxyService.isEnabled()) {
            return upstreamProxyService.proxyHealth();
        }
        return Map.of("status", "ok");
    }
}
