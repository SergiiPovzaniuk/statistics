package com.openaiapi.playwright;

import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitUntilState;
import com.openaiapi.config.AppProperties;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class PlaywrightBrowserSession {

    private static final Logger log = LoggerFactory.getLogger(PlaywrightBrowserSession.class);

    private final PlaywrightBrowserManager browserManager;
    private final AppProperties appProperties;
    private final Object lock = new Object();

    private BrowserContext context;
    private Page page;
    private volatile boolean ready;

    public PlaywrightBrowserSession(PlaywrightBrowserManager browserManager, AppProperties appProperties) {
        this.browserManager = browserManager;
        this.appProperties = appProperties;
    }

    @PostConstruct
    void warmUp() {
        if (!appProperties.getUpstream().isEnabled() || !appProperties.getUpstream().isUsePlaywright()) {
            return;
        }
        synchronized (lock) {
            openPage();
            ready = true;
            log.info("Playwright page ready at {}", appProperties.getUpstream().getPageUrl());
        }
    }

    public boolean isReady() {
        return ready;
    }

    public Page page() {
        synchronized (lock) {
            openPage();
            return page;
        }
    }

    @PreDestroy
    void shutdown() {
        synchronized (lock) {
            closeContext();
            ready = false;
        }
    }

    private void openPage() {
        if (context != null && page != null && !page.isClosed()) {
            return;
        }
        closeContext();
        Browser browser = browserManager.getBrowser();
        context = browser.newContext();
        page = context.newPage();
        page.navigate(
                appProperties.getUpstream().getPageUrl(),
                new Page.NavigateOptions().setWaitUntil(WaitUntilState.LOAD));
        page.locator("[data-testid='send']").waitFor();
    }

    private void closeContext() {
        if (context != null) {
            try {
                context.close();
            } catch (Exception ignored) {
            }
            context = null;
            page = null;
        }
    }
}
