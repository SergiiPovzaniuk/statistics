package com.openaiapi.playwright;

public class PlaywrightAutomationException extends RuntimeException {

    public PlaywrightAutomationException(String message) {
        super(message);
    }

    public PlaywrightAutomationException(String message, Throwable cause) {
        super(message, cause);
    }
}
