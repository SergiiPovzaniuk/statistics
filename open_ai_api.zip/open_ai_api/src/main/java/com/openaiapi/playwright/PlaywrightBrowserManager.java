package com.openaiapi.playwright;

import com.openaiapi.config.AppProperties;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Playwright;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component
public class PlaywrightBrowserManager {

    private static final Logger log = LoggerFactory.getLogger(PlaywrightBrowserManager.class);

    private final AppProperties appProperties;
    private final Object lock = new Object();
    private Playwright playwright;
    private Browser browser;

    public PlaywrightBrowserManager(AppProperties appProperties) {
        this.appProperties = appProperties;
    }

    @PostConstruct
    void warmUp() {
        if (appProperties.getUpstream().isEnabled() && appProperties.getUpstream().isUsePlaywright()) {
            getBrowser();
        }
    }

    public Browser getBrowser() {
        synchronized (lock) {
            if (browser != null && browser.isConnected()) {
                return browser;
            }
            return launchBrowser();
        }
    }

    public boolean isConnected() {
        synchronized (lock) {
            return browser != null && browser.isConnected();
        }
    }

    @PreDestroy
    void shutdown() {
        synchronized (lock) {
            if (browser != null) {
                try {
                    browser.close();
                } catch (Exception ex) {
                    log.warn("Failed to close browser", ex);
                }
                browser = null;
            }
            if (playwright != null) {
                playwright.close();
                playwright = null;
            }
        }
    }

    private Browser launchBrowser() {
        try {
            if (playwright == null) {
                playwright = Playwright.create();
            }
            var options = new BrowserType.LaunchOptions()
                    .setHeadless(appProperties.getUpstream().isHeadless());
            browser = playwright.chromium().launch(options);
            log.info("Playwright browser launched");
            return browser;
        } catch (Exception ex) {
            throw new BrowserNotReadyException("Failed to launch Playwright browser", ex);
        }
    }
}
