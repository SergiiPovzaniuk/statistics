package com.openaiapi.playwright;

import static com.openaiapi.playwright.UiSelectors.A0;
import static com.openaiapi.playwright.UiSelectors.P1;
import static com.openaiapi.playwright.UiSelectors.P2;
import static com.openaiapi.playwright.UiSelectors.P3;
import static com.openaiapi.playwright.UiSelectors.STATE_DONE;
import static com.openaiapi.playwright.UiSelectors.STATE_ERROR;
import static com.openaiapi.playwright.UiSelectors.STATE_IDLE;
import static com.openaiapi.playwright.UiSelectors.STATE_LOADING;
import static com.openaiapi.playwright.UiSelectors.testId;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.openaiapi.api.dto.ChatCompletionRequest;
import com.openaiapi.config.AppProperties;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class PlaywrightUiTransport {

    private static final Logger log = LoggerFactory.getLogger(PlaywrightUiTransport.class);
    private static final int CHUNK = 256 * 1024;

    private final PlaywrightBrowserSession browserSession;
    private final AppProperties appProperties;
    private final ObjectMapper objectMapper;
    private final Object lock = new Object();

    public PlaywrightUiTransport(
            PlaywrightBrowserSession browserSession,
            AppProperties appProperties,
            ObjectMapper objectMapper) {
        this.browserSession = browserSession;
        this.appProperties = appProperties;
        this.objectMapper = objectMapper;
    }

    public JsonNode proxyChat(ChatCompletionRequest request) {
        if (!browserSession.isReady()) {
            throw new BrowserNotReadyException("Playwright session is not ready");
        }
        synchronized (lock) {
            Page page = browserSession.page();
            try {
                ObjectNode body = objectMapper.valueToTree(request);
                body.put("stream", false);
                String payload = objectMapper.writeValueAsString(body);
                String path = appProperties.getUpstream().getChatPath();
                if (path == null || path.isBlank()) {
                    path = "/ui/run";
                }

                page.locator(testId(A0)).waitFor();
                injectPayload(page, payload);
                // Fire-and-forget: do not await fetch inside evaluate (Playwright default ~30s).
                page.evaluate(
                        """
                        ({ path }) => {
                          const payload = window.__b;
                          window.__b = '';
                          const p5 = document.querySelector('[data-testid="p5"]');
                          const p3 = document.querySelector('[data-testid="p3"]');
                          const p1 = document.querySelector('[data-testid="p1"]');
                          const p2 = document.querySelector('[data-testid="p2"]');
                          const STATE = { '0': '0 idle', '1': '1 load', '2': '2 done', '3': '3 err' };
                          const setState = (s) => {
                            if (!p3) return;
                            p3.dataset.state = s;
                            p3.textContent = STATE[s] ?? s;
                          };
                          if (p5 && path) p5.value = path;
                          if (p1) p1.value = '';
                          if (p2) p2.value = '';
                          setState('1');
                          if (typeof window.__x?.run === 'function') {
                            void window.__x.run(payload, path);
                            return;
                          }
                          const gen = (window.__gen = (window.__gen || 0) + 1);
                          void fetch(path, {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/json' },
                            body: payload,
                          }).then(async (res) => {
                            if (gen !== window.__gen) return;
                            const text = await res.text();
                            if (gen !== window.__gen) return;
                            if (p2) p2.value = String(res.status);
                            if (p1) p1.value = text;
                            setState(res.ok ? '2' : '3');
                          }).catch((err) => {
                            if (gen !== window.__gen) return;
                            if (p2) p2.value = '';
                            if (p1) p1.value = String(err);
                            setState('3');
                          });
                        }
                        """,
                        Map.of("path", path));

                waitForDoneOrThrow(page);

                String state = page.locator(testId(P3)).getAttribute("data-state");
                String httpStatus = page.locator(testId(P2)).inputValue().trim();
                String responseText = page.locator(testId(P1)).inputValue().trim();

                if (STATE_ERROR.equals(state)) {
                    throw upstreamError(httpStatus, responseText);
                }
                if (responseText.isBlank()) {
                    recoverPage();
                    throw new PlaywrightAutomationException("UI returned empty response");
                }

                JsonNode parsed = objectMapper.readTree(responseText);
                if (parsed.has("error")) {
                    int status = parseStatus(httpStatus, 502);
                    if (status < 400) {
                        status = 502;
                    }
                    throw upstreamError(String.valueOf(status), responseText);
                }
                if (!parsed.has("choices") || !parsed.get("choices").isArray() || parsed.get("choices").isEmpty()) {
                    recoverPage();
                    throw new PlaywrightAutomationException("Upstream response has no choices: " + responseText);
                }
                return parsed;
            } catch (PlaywrightAutomationException | BrowserNotReadyException ex) {
                throw ex;
            } catch (Exception ex) {
                recoverPage();
                throw new PlaywrightAutomationException("Playwright UI automation failed: " + ex.getMessage(), ex);
            }
        }
    }

    private void recoverPage() {
        try {
            browserSession.reload();
        } catch (Exception ex) {
            log.warn("Failed to reload Playwright page after error: {}", ex.getMessage());
        }
    }

    private void injectPayload(Page page, String payload) {
        page.evaluate("() => { window.__b = ''; }");
        for (int i = 0; i < payload.length(); i += CHUNK) {
            String part = payload.substring(i, Math.min(payload.length(), i + CHUNK));
            page.evaluate("(c) => { window.__b += c; }", part);
        }
    }

    private void waitForDone(Page page) {
        Locator status = page.locator(testId(P3));
        long deadline = System.currentTimeMillis() + appProperties.getUpstream().getResponseTimeoutMs();
        while (System.currentTimeMillis() < deadline) {
            String state = status.getAttribute("data-state");
            if (STATE_DONE.equals(state) || STATE_ERROR.equals(state)) {
                return;
            }
            if (STATE_IDLE.equals(state) || STATE_LOADING.equals(state) || state == null) {
                page.waitForTimeout(200);
                continue;
            }
            page.waitForTimeout(200);
        }
        throw new PlaywrightAutomationException("Timed out waiting for UI response");
    }

    private void waitForDoneOrThrow(Page page) {
        try {
            waitForDone(page);
        } catch (PlaywrightAutomationException ex) {
            recoverPage();
            throw ex;
        }
    }

    private int parseStatus(String httpStatus, int fallback) {
        try {
            if (httpStatus != null && !httpStatus.isBlank()) {
                return Integer.parseInt(httpStatus.trim());
            }
        } catch (NumberFormatException ignored) {
        }
        return fallback;
    }

    @SuppressWarnings("unchecked")
    private PlaywrightAutomationException upstreamError(String httpStatus, String responseText) {
        int status = parseStatus(httpStatus, 502);
        if (status < 400) {
            status = 502;
        }
        try {
            Map<String, Object> body = objectMapper.readValue(responseText, Map.class);
            return new PlaywrightAutomationException(status, body);
        } catch (Exception ignored) {
            return new PlaywrightAutomationException("UI error (HTTP " + httpStatus + "): " + responseText);
        }
    }
}
