package com.openaiapi.playwright;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.openaiapi.api.dto.ChatCompletionRequest;
import com.openaiapi.config.AppProperties;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class PlaywrightUiTransport {

    private final PlaywrightBrowserSession browserSession;
    private final AppProperties appProperties;
    private final ObjectMapper objectMapper;
    private final Object lock = new Object();

    public PlaywrightUiTransport(
            PlaywrightBrowserSession browserSession,
            AppProperties appProperties,
            ObjectMapper objectMapper) {
        this.browserSession = browserSession;
        this.appProperties = appProperties;
        this.objectMapper = objectMapper;
    }

    public JsonNode proxyChat(ChatCompletionRequest request) {
        if (!browserSession.isReady()) {
            throw new BrowserNotReadyException("Playwright session is not ready");
        }
        synchronized (lock) {
            Page page = browserSession.page();
            try {
                ObjectNode body = objectMapper.valueToTree(request);
                body.put("stream", false);
                String payload = objectMapper.writeValueAsString(body);

                page.evaluate(
                        """
                        (payload) => {
                          const status = document.querySelector('[data-testid="status"]');
                          const response = document.querySelector('[data-testid="response"]');
                          const http = document.querySelector('[data-testid="http-status"]');
                          const request = document.querySelector('[data-testid="request"]');
                          if (status) { status.dataset.state = 'idle'; status.textContent = 'idle'; }
                          if (response) response.value = '';
                          if (http) http.value = '';
                          if (request) {
                            request.value = payload;
                            request.dispatchEvent(new Event('input', { bubbles: true }));
                          }
                        }
                        """,
                        payload);
                page.locator("[data-testid='send']").click();
                waitForLoading(page);
                waitForDone(page);

                String state = page.locator("[data-testid='status']").getAttribute("data-state");
                String httpStatus = page.locator("[data-testid='http-status']").inputValue().trim();
                String responseText = page.locator("[data-testid='response']").inputValue().trim();

                if ("error".equals(state)) {
                    throw upstreamError(httpStatus, responseText);
                }
                if (responseText.isBlank()) {
                    throw new PlaywrightAutomationException("UI returned empty response");
                }

                JsonNode parsed = objectMapper.readTree(responseText);
                if (parsed.has("error")) {
                    throw upstreamError(httpStatus, responseText);
                }
                if (!parsed.has("choices") || !parsed.get("choices").isArray() || parsed.get("choices").isEmpty()) {
                    throw new PlaywrightAutomationException("Upstream response has no choices: " + responseText);
                }
                return parsed;
            } catch (PlaywrightAutomationException | BrowserNotReadyException ex) {
                throw ex;
            } catch (Exception ex) {
                throw new PlaywrightAutomationException("Playwright UI automation failed: " + ex.getMessage(), ex);
            }
        }
    }

    private void waitForLoading(Page page) {
        Locator status = page.locator("[data-testid='status']");
        long deadline = System.currentTimeMillis() + 15_000;
        while (System.currentTimeMillis() < deadline) {
            String state = status.getAttribute("data-state");
            if ("loading".equals(state) || "done".equals(state) || "error".equals(state)) {
                return;
            }
            page.waitForTimeout(50);
        }
    }

    private void waitForDone(Page page) {
        Locator status = page.locator("[data-testid='status']");
        long deadline = System.currentTimeMillis() + appProperties.getUpstream().getResponseTimeoutMs();
        while (System.currentTimeMillis() < deadline) {
            String state = status.getAttribute("data-state");
            if ("done".equals(state) || "error".equals(state)) {
                return;
            }
            page.waitForTimeout(200);
        }
        throw new PlaywrightAutomationException("Timed out waiting for UI response");
    }

    @SuppressWarnings("unchecked")
    private PlaywrightAutomationException upstreamError(String httpStatus, String responseText) {
        int status = 502;
        try {
            if (httpStatus != null && !httpStatus.isBlank()) {
                status = Integer.parseInt(httpStatus.trim());
            }
        } catch (NumberFormatException ignored) {
        }
        try {
            Map<String, Object> body = objectMapper.readValue(responseText, Map.class);
            return new PlaywrightAutomationException(status, body);
        } catch (Exception ignored) {
            return new PlaywrightAutomationException("UI error (HTTP " + httpStatus + "): " + responseText);
        }
    }
}
