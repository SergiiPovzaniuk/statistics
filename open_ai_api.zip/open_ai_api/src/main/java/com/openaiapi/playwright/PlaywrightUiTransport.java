package com.openaiapi.playwright;

import static com.openaiapi.playwright.UiSelectors.A0;
import static com.openaiapi.playwright.UiSelectors.P1;
import static com.openaiapi.playwright.UiSelectors.P2;
import static com.openaiapi.playwright.UiSelectors.P3;
import static com.openaiapi.playwright.UiSelectors.STATE_DONE;
import static com.openaiapi.playwright.UiSelectors.STATE_ERROR;
import static com.openaiapi.playwright.UiSelectors.testId;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;
import com.microsoft.playwright.options.WaitForSelectorState;
import com.openaiapi.api.dto.ChatCompletionRequest;
import com.openaiapi.api.dto.ModelListResponse;
import com.openaiapi.config.AppProperties;
import com.openaiapi.crypto.PayloadCrypto;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.ReentrantLock;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service
public class PlaywrightUiTransport {

    private static final Logger log = LoggerFactory.getLogger(PlaywrightUiTransport.class);
    private static final int CHUNK = 256 * 1024;

    private final PlaywrightBrowserSession browserSession;
    private final AppProperties appProperties;
    private final ObjectMapper objectMapper;
    private final PayloadCrypto payloadCrypto;
    private final ReentrantLock lock = new ReentrantLock();
    private final AtomicBoolean busy = new AtomicBoolean(false);

    public PlaywrightUiTransport(
            PlaywrightBrowserSession browserSession,
            AppProperties appProperties,
            ObjectMapper objectMapper,
            PayloadCrypto payloadCrypto) {
        this.browserSession = browserSession;
        this.appProperties = appProperties;
        this.objectMapper = objectMapper;
        this.payloadCrypto = payloadCrypto;
    }

    public boolean isBusy() {
        return busy.get();
    }

    public ModelListResponse proxyModels() {
        String path = appProperties.getUpstream().getModelsPath();
        if (!StringUtils.hasText(path)) {
            path = "/ui/models";
        }
        BrowserFetchResult result = browserFetch("GET", path, null, true);
        try {
            if (result.status() < 200 || result.status() >= 300) {
                throw upstreamError(String.valueOf(result.status()), result.body());
            }
            ModelListResponse list = objectMapper.readValue(result.body(), ModelListResponse.class);
            if (list == null || list.getData() == null) {
                throw new PlaywrightAutomationException("UI /models returned empty list");
            }
            return list;
        } catch (PlaywrightAutomationException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new PlaywrightAutomationException("Failed to parse UI models response: " + ex.getMessage(), ex);
        }
    }

    public Map<String, Object> proxyHealth() {
        String path = appProperties.getUpstream().getHealthPath();
        if (!StringUtils.hasText(path)) {
            path = "/health";
        }
        BrowserFetchResult result = browserFetch("GET", path, null, false);
        try {
            if (result.status() < 200 || result.status() >= 300) {
                throw new PlaywrightAutomationException(
                        "UI health failed (HTTP " + result.status() + "): " + result.body());
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> body = objectMapper.readValue(result.body(), Map.class);
            return body != null ? body : Map.of("status", "ok");
        } catch (PlaywrightAutomationException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new PlaywrightAutomationException("Failed to parse UI health response: " + ex.getMessage(), ex);
        }
    }

    public Map<String, Object> proxyUiReset() {
        BrowserFetchResult result = browserFetch("POST", "/ui/reset", "", true);
        try {
            if (result.status() < 200 || result.status() >= 300) {
                throw upstreamError(String.valueOf(result.status()), result.body());
            }
            if (!StringUtils.hasText(result.body())) {
                return Map.of("status", "ok");
            }
            @SuppressWarnings("unchecked")
            Map<String, Object> body = objectMapper.readValue(result.body(), Map.class);
            return body != null ? body : Map.of("status", "ok");
        } catch (PlaywrightAutomationException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new PlaywrightAutomationException("Failed to parse UI reset response: " + ex.getMessage(), ex);
        }
    }

    public JsonNode proxyChat(ChatCompletionRequest request) {
        if (!browserSession.isReady()) {
            throw new BrowserNotReadyException("Playwright session is not ready");
        }
        if (!lock.tryLock()) {
            throw new ConcurrentBusyException(
                    "Another chat is already in progress (concurrency=1). Retry later.");
        }
        busy.set(true);
        try {
            Page page = browserSession.page();
            try {
                ObjectNode body = objectMapper.valueToTree(request);
                body.put("stream", false);
                String payload = payloadCrypto.seal(objectMapper.writeValueAsString(body));
                String path = appProperties.getUpstream().getChatPath();
                if (path == null || path.isBlank()) {
                    path = "/ui/run";
                }
                String transportKey = appProperties.getUpstream().getTransportKey();
                if (!StringUtils.hasText(transportKey)) {
                    throw new PlaywrightAutomationException("TRANSPORT_KEY is required for UI transport");
                }

                page.locator(testId(A0))
                        .waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.ATTACHED));
                page.evaluate("(k) => { window.__k = k; }", transportKey);
                injectPayload(page, payload);
                page.evaluate(
                        """
                        ({ path, transportKey }) => {
                          const payload = window.__b;
                          window.__b = '';
                          const p3 = document.querySelector('[data-testid="p3"]');
                          const p1 = document.querySelector('[data-testid="p1"]');
                          const p2 = document.querySelector('[data-testid="p2"]');
                          const STATE = { '0': '0 idle', '1': '1 load', '2': '2 done', '3': '3 err' };
                          const setState = (s) => {
                            if (!p3) return;
                            p3.dataset.state = s;
                            p3.textContent = STATE[s] ?? s;
                          };
                          if (p1) p1.value = '';
                          if (p2) p2.value = '';
                          setState('1');
                          const headers = {
                            'Content-Type': 'text/plain; charset=utf-8',
                            'x-transport-key': transportKey,
                          };
                          if (typeof window.__x?.run === 'function') {
                            void window.__x.run(payload, path, transportKey);
                            return;
                          }
                          const gen = (window.__gen = (window.__gen || 0) + 1);
                          void fetch(path, {
                            method: 'POST',
                            headers: {
                              ...headers,
                              Accept: 'text/event-stream, text/plain',
                            },
                            body: payload,
                          }).then(async (res) => {
                            if (gen !== window.__gen) return;
                            const ct = (res.headers.get('content-type') || '').toLowerCase();
                            let status = res.status;
                            let text = '';
                            if (ct.includes('text/event-stream') && res.body) {
                              const reader = res.body.getReader();
                              const decoder = new TextDecoder();
                              let buf = '';
                              let event = 'message';
                              let dataLines = [];
                              let donePayload = null;
                              const flush = () => {
                                if (!dataLines.length && event === 'message') return;
                                const data = dataLines.join('\\n');
                                dataLines = [];
                                const ev = event;
                                event = 'message';
                                if (ev === 'ping') return;
                                if (ev === 'done') donePayload = JSON.parse(data);
                              };
                              while (true) {
                                const chunk = await reader.read();
                                if (chunk.done) break;
                                buf += decoder.decode(chunk.value, { stream: true });
                                let idx;
                                while ((idx = buf.indexOf('\\n')) >= 0) {
                                  let line = buf.slice(0, idx);
                                  buf = buf.slice(idx + 1);
                                  if (line.endsWith('\\r')) line = line.slice(0, -1);
                                  if (line === '') { flush(); continue; }
                                  if (line.startsWith('event:')) { event = line.slice(6).trim(); continue; }
                                  if (line.startsWith('data:')) dataLines.push(line.slice(5).trimStart());
                                }
                              }
                              flush();
                              if (!donePayload || typeof donePayload.body !== 'string') {
                                throw new Error('SSE missing done event');
                              }
                              status = Number(donePayload.status) || status;
                              text = donePayload.body;
                            } else {
                              text = await res.text();
                            }
                            if (gen !== window.__gen) return;
                            if (p2) p2.value = String(status);
                            if (p1) p1.value = text;
                            setState(status >= 200 && status < 300 ? '2' : '3');
                          }).catch((err) => {
                            if (gen !== window.__gen) return;
                            if (p2) p2.value = '';
                            if (p1) p1.value = String(err);
                            setState('3');
                          });
                        }
                        """,
                        Map.of("path", path, "transportKey", transportKey));
                waitForDoneOrThrow(page);

                String state = page.locator(testId(P3)).getAttribute("data-state");
                String httpStatus = page.locator(testId(P2)).inputValue().trim();
                String responseText = page.locator(testId(P1)).inputValue().trim();

                if (isBrowserFetchFailure(responseText)) {
                    recoverPage();
                    throw new PlaywrightAutomationException(
                            "UI fetch failed (connection dropped during long run): " + responseText);
                }

                if (STATE_ERROR.equals(state)) {
                    throw upstreamError(httpStatus, responseText);
                }
                if (responseText.isBlank()) {
                    recoverPage();
                    throw new PlaywrightAutomationException("UI returned empty response");
                }

                String plain = unsealResponse(responseText);
                JsonNode parsed = objectMapper.readTree(plain);
                if (parsed.has("error")) {
                    int status = parseStatus(httpStatus, 502);
                    if (status < 400) {
                        status = 502;
                    }
                    throw upstreamError(String.valueOf(status), responseText);
                }
                if (!parsed.has("choices") || !parsed.get("choices").isArray() || parsed.get("choices").isEmpty()) {
                    recoverPage();
                    throw new PlaywrightAutomationException("Upstream response has no choices: " + plain);
                }
                return parsed;
            } catch (PlaywrightAutomationException | BrowserNotReadyException | ConcurrentBusyException ex) {
                throw ex;
            } catch (Exception ex) {
                recoverPage();
                throw new PlaywrightAutomationException("Playwright UI automation failed: " + ex.getMessage(), ex);
            }
        } finally {
            busy.set(false);
            lock.unlock();
        }
    }

    public void recoverUi() {
        recoverPage();
    }

    private record BrowserFetchResult(int status, String body) {}

    private BrowserFetchResult browserFetch(String method, String path, String body, boolean requireTransportKey) {
        if (!browserSession.isReady()) {
            throw new BrowserNotReadyException("Playwright session is not ready");
        }
        if (!lock.tryLock()) {
            throw new ConcurrentBusyException(
                    "Another browser request is already in progress (concurrency=1). Retry later.");
        }
        busy.set(true);
        try {
            Page page = browserSession.page();
            String transportKey = appProperties.getUpstream().getTransportKey();
            if (requireTransportKey && !StringUtils.hasText(transportKey)) {
                throw new PlaywrightAutomationException("TRANSPORT_KEY is required for UI transport");
            }
            page.locator(testId(A0))
                    .waitFor(new Locator.WaitForOptions().setState(WaitForSelectorState.ATTACHED));
            if (StringUtils.hasText(transportKey)) {
                page.evaluate("(k) => { window.__k = k; }", transportKey);
            }

            Map<String, Object> args = new LinkedHashMap<>();
            args.put("method", method);
            args.put("path", path);
            args.put("body", body == null ? "" : body);
            args.put("transportKey", transportKey == null ? "" : transportKey);
            args.put("requireTransportKey", requireTransportKey);

            @SuppressWarnings("unchecked")
            Map<String, Object> raw = (Map<String, Object>) page.evaluate(
                    """
                    async ({ method, path, body, transportKey, requireTransportKey }) => {
                      const headers = { Accept: 'application/json, text/plain, */*' };
                      if (requireTransportKey || transportKey) {
                        headers['x-transport-key'] = transportKey;
                      }
                      const init = { method, headers };
                      if (method !== 'GET' && method !== 'HEAD') {
                        headers['Content-Type'] = 'text/plain; charset=utf-8';
                        init.body = body ?? '';
                      }
                      try {
                        const res = await fetch(path, init);
                        return { status: res.status, body: await res.text(), error: '' };
                      } catch (err) {
                        return { status: 0, body: String(err), error: String(err) };
                      }
                    }
                    """,
                    args);

            int status = raw.get("status") instanceof Number n ? n.intValue() : 0;
            String responseBody = raw.get("body") == null ? "" : String.valueOf(raw.get("body"));
            String error = raw.get("error") == null ? "" : String.valueOf(raw.get("error"));
            if (status == 0 || isBrowserFetchFailure(responseBody) || isBrowserFetchFailure(error)) {
                recoverPage();
                throw new PlaywrightAutomationException(
                        "UI fetch failed: " + (error.isBlank() ? responseBody : error));
            }
            return new BrowserFetchResult(status, responseBody);
        } catch (PlaywrightAutomationException | BrowserNotReadyException | ConcurrentBusyException ex) {
            throw ex;
        } catch (Exception ex) {
            recoverPage();
            throw new PlaywrightAutomationException("Playwright UI fetch failed: " + ex.getMessage(), ex);
        } finally {
            busy.set(false);
            lock.unlock();
        }
    }

    private boolean isBrowserFetchFailure(String responseText) {
        if (responseText == null || responseText.isBlank()) {
            return false;
        }
        String t = responseText.trim();
        return t.startsWith("TypeError:")
                || t.contains("Failed to fetch")
                || t.contains("ERR_CONNECTION")
                || t.contains("ERR_EMPTY_RESPONSE")
                || t.contains("ERR_INCOMPLETE_CHUNKED_ENCODING");
    }

    private String unsealResponse(String responseText) {
        try {
            return payloadCrypto.unseal(responseText);
        } catch (IllegalArgumentException ex) {
            throw new PlaywrightAutomationException("Failed to unseal UI response: " + ex.getMessage(), ex);
        }
    }

    private void recoverPage() {
        try {
            browserSession.reload();
        } catch (Exception ex) {
            log.warn("Failed to reload Playwright page after error: {}", ex.getMessage());
        }
    }

    private void injectPayload(Page page, String payload) {
        page.evaluate("() => { window.__b = ''; }");
        for (int i = 0; i < payload.length(); i += CHUNK) {
            String part = payload.substring(i, Math.min(payload.length(), i + CHUNK));
            page.evaluate("(c) => { window.__b += c; }", part);
        }
    }

    private void waitForDone(Page page) {
        Locator status = page.locator(testId(P3));
        long deadline = System.currentTimeMillis() + appProperties.getUpstream().getResponseTimeoutMs();
        while (System.currentTimeMillis() < deadline) {
            String state = status.getAttribute("data-state");
            if (STATE_DONE.equals(state) || STATE_ERROR.equals(state)) {
                return;
            }
            page.waitForTimeout(200);
        }
        throw new PlaywrightAutomationException("Timed out waiting for UI response");
    }

    private void waitForDoneOrThrow(Page page) {
        try {
            waitForDone(page);
        } catch (PlaywrightAutomationException ex) {
            recoverPage();
            throw ex;
        }
    }

    private int parseStatus(String httpStatus, int fallback) {
        try {
            if (httpStatus != null && !httpStatus.isBlank()) {
                return Integer.parseInt(httpStatus.trim());
            }
        } catch (NumberFormatException ignored) {
        }
        return fallback;
    }

    @SuppressWarnings("unchecked")
    private PlaywrightAutomationException upstreamError(String httpStatus, String responseText) {
        int status = parseStatus(httpStatus, 502);
        if (status < 400) {
            status = 502;
        }
        try {
            String plain = responseText;
            if (responseText != null && responseText.startsWith(PayloadCrypto.PREFIX)) {
                plain = payloadCrypto.unseal(responseText);
            }
            Map<String, Object> body = objectMapper.readValue(plain, Map.class);
            return new PlaywrightAutomationException(status, body);
        } catch (Exception ignored) {
            return new PlaywrightAutomationException("UI error (HTTP " + httpStatus + "): " + responseText);
        }
    }
}
