# Use Cursor gateway with VS Code Copilot

The gateway exposes an OpenAI Chat Completions API on localhost and proxies to the Cursor ACP service (`open_ai_cursor_api`) via Playwright browser automation. VS Code Copilot connects via **BYOK Custom Endpoint**.

API contract: [VSCODE_COPILOT_API_SPEC.md](VSCODE_COPILOT_API_SPEC.md)

## Two-machine setup

| Machine | Runs | Role |
|---------|------|------|
| **Host PC** | `open_ai_cursor_api` on port 8081 | Cursor CLI agent edits local projects |
| **Remote PC** | `open_ai_api` on port 18080 + VS Code Copilot | Browser-only internet; Playwright drives host UI |

**Host PC:**

```bash
cd open_ai_cursor_api
PORT=8081 node --env-file=.env dist/index.js
```

**Remote PC** — set `app.upstream.page-url` to `http://<host-ip>:8081/` in `application.yml`, then:

```bash
cd open_ai_api
./mvnw spring-boot:run
```

## 1. Verify gateway

```bash
curl http://127.0.0.1:18080/health
curl http://127.0.0.1:18080/v1/models
```

Expected: Cursor models (`composer-2.5`, `auto`, etc.) when upstream is reachable.

## 2. Configure VS Code Copilot

1. Open **Chat** → **Manage Language Models**
2. **Add Models** → **Custom Endpoint**
3. Merge [`chatLanguageModels.example.json`](chatLanguageModels.example.json) into `chatLanguageModels.json`
4. Use gateway URL: `http://127.0.0.1:18080/v1/chat/completions`
5. Use Cursor model ids (`composer-2.5`, `auto`, …) — not `dummy-*` for production

**Common failures:**

- `url` pointing at `http://127.0.0.1:8081/...` — that is the Cursor API host. Use the **gateway** at `18080`.
- Playwright not ready — ensure host Cursor API UI is reachable at `app.upstream.page-url`.

## 3. How it works

1. Copilot → `POST /v1/chat/completions` on gateway (18080)
2. Gateway injects `cursor.cwd` / `cursor.agentId` and forwards via Playwright to host `/ui/run`
3. Cursor CLI ACP agent runs on host and edits local project files
4. Response includes `cursor: { agentId, runId, status }` for session resume
5. If Copilot sends `stream: true`, gateway adapts JSON to SSE

File edits happen on the **host** via Cursor agent, not via VS Code Copilot tools.

## 4. Configuration

| Key | Description |
|-----|-------------|
| `app.upstream.page-url` | Host Cursor API UI (browser-reachable) |
| `app.upstream.cursor-cwd` | Workspace path on host (`CURSOR_LOCAL_CWD`) |
| `app.upstream.session-resume` | Auto-resume ACP sessions between turns |

## 5. Offline smoke tests

Set `app.upstream.enabled: false` and use `dummy-*` models for protocol tests without Cursor.

```bash
curl http://127.0.0.1:18080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d "{\"model\":\"dummy-gpt\",\"messages\":[{\"role\":\"user\",\"content\":\"hello\"}]}"
```
