# Use dummy gateway with VS Code Copilot (Agent mode)

The service exposes an OpenAI Chat Completions API on localhost. VS Code Copilot connects to it via **BYOK Custom Endpoint** with `toolCalling: true`, so Agent mode can run tools.

API contract (methods, bodies, agent loop): [VSCODE_COPILOT_API_SPEC.md](VSCODE_COPILOT_API_SPEC.md)

## 1. Start the gateway

From the project root:

```bash
./mvnw spring-boot:run
```

Default URL: `http://127.0.0.1:18080`

Check it is up:

```bash
curl http://127.0.0.1:18080/health
curl http://127.0.0.1:18080/v1/models
```

Expected: `{"status":"ok"}` and a list with `dummy-gpt`, `dummy-fast`, `dummy-tools`.

If another process already owns the port, stop it or start with a different `--server.port` and update every model `url` to match.

Keep this terminal open while you use Copilot.

## 2. Open Language Models in VS Code

1. Install / enable **GitHub Copilot Chat** (VS Code Chat).
2. Open the **Chat** view.
3. Open the **model picker** (model name dropdown next to the chat input).
4. Choose **Manage Language Models** (gear),  
   or Command Palette (`Ctrl+Shift+P`) → **Chat: Manage Language Models**.

## 3. Add a Custom Endpoint

1. In the Language Models editor, choose **Add Models**.
2. Select **Custom Endpoint**.
3. Fill the wizard roughly as:
   - **Group / display name:** `Local Dummy Gateway`
   - **API key:** `local` (any non-empty value is fine; auth is disabled on the gateway)
   - **API type:** **Chat Completions**
4. VS Code opens `chatLanguageModels.json`. Replace / merge with the content of [`chatLanguageModels.example.json`](chatLanguageModels.example.json).

Minimal example:

```json
[
  {
    "name": "Local Dummy Gateway",
    "vendor": "customendpoint",
    "apiKey": "local",
    "apiType": "chat-completions",
    "models": [
      {
        "id": "dummy-gpt",
        "name": "Dummy GPT",
        "url": "http://127.0.0.1:18080/v1/chat/completions",
        "toolCalling": true,
        "vision": false,
        "maxInputTokens": 128000,
        "maxOutputTokens": 4096
      },
      {
        "id": "dummy-fast",
        "name": "Dummy Fast",
        "url": "http://127.0.0.1:18080/v1/chat/completions",
        "toolCalling": true,
        "vision": false,
        "maxInputTokens": 128000,
        "maxOutputTokens": 4096
      },
      {
        "id": "dummy-tools",
        "name": "Dummy Tools",
        "url": "http://127.0.0.1:18080/v1/chat/completions",
        "toolCalling": true,
        "vision": false,
        "maxInputTokens": 128000,
        "maxOutputTokens": 4096
      }
    ]
  }
]
```

**Common failures:**

- `url` pointing at `http://127.0.0.1:8081/v1/chat/completions` — that is the Cursor API (needs `SERVICE_API_KEY`). Use the **gateway**: `http://127.0.0.1:18080/v1/chat/completions`.
- Empty / missing API key in Custom Endpoint — set any non-empty key (e.g. `local`) via **Chat: Manage Language Models**. The gateway does not validate it; the Playwright path uses `/ui/run` (no key).

5. Save the file.
6. Confirm each model shows **tools** capability and is **visible** in the Language Models editor (eye icon on if hidden).
7. If models do not appear, reload the window: Command Palette → **Developer: Reload Window**.

Important:

- `"toolCalling": true` is required for **Agent** mode.
- `"url"` must be the **full** chat completions path (`.../v1/chat/completions`), not only the base host.
- `"id"` is the model name sent to the gateway (`dummy-gpt`, etc.).

## 4. Use Agent mode with a dummy model

1. Open **Chat**.
2. Set mode to **Agent** (not Ask / Edit only).
3. In the model picker, select **Dummy GPT** (or **Dummy Fast** / **Dummy Tools**).
4. Send a request that needs a tool, for example:  
   `List files in the workspace` or `Read README.md`.
5. Expected flow with the dummy provider:
   1. Gateway returns a `tool_calls` response (e.g. `read_file` / preferred tool).
   2. Copilot runs the tool in VS Code.
   3. Copilot posts the tool result back.
   4. Gateway returns a short final text reply acknowledging the tool result.

Without tools in the request, you only get a plain text echo-style reply (`Dummy reply to: ...`).

## 5. Switch models in the picker

All three entries map to the same dummy backend today; they exist so you can verify model selection in Copilot:

| Picker name   | Model id      |
|---------------|---------------|
| Dummy GPT     | `dummy-gpt`   |
| Dummy Fast    | `dummy-fast`  |
| Dummy Tools   | `dummy-tools` |

Change the picker between them and send another chat message — the JSON response `model` field matches the selected id.

## 6. Troubleshooting

| Symptom | What to check |
|---------|----------------|
| Models missing in picker | `toolCalling: true`, model visibility (eye), reload window |
| Connection / network error | Gateway running; URL host/port; `curl /health` |
| `Server error: 500` | Wrong port (must be `18080` unless overridden); `curl` the same `url` from the JSON |
| Agent never calls tools | Mode is **Agent**; selected model has tools capability; ask for something that needs a tool |
| Immediate text, no tools | Normal if the client sends no `tools` array or `tool_choice: none` |

## 7. Optional curl checks (no VS Code)

Text:

```bash
curl http://127.0.0.1:18080/v1/chat/completions -H "Content-Type: application/json" -d "{\"model\":\"dummy-gpt\",\"messages\":[{\"role\":\"user\",\"content\":\"hello\"}]}"
```

Tool call:

```bash
curl http://127.0.0.1:18080/v1/chat/completions -H "Content-Type: application/json" -d "{\"model\":\"dummy-tools\",\"messages\":[{\"role\":\"user\",\"content\":\"read\"}],\"tools\":[{\"type\":\"function\",\"function\":{\"name\":\"read_file\",\"parameters\":{\"type\":\"object\"}}}]}"
```
