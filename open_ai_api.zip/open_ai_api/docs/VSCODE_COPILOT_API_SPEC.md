# VS Code Copilot HTTP API Specification

Contract for this gateway when used as a VS Code Copilot **BYOK Custom Endpoint** with `apiType: chat-completions`.

Setup guide: [VSCODE_COPILOT_SETUP.md](VSCODE_COPILOT_SETUP.md)  
Example model config: [chatLanguageModels.example.json](chatLanguageModels.example.json)

## 1. Base URL and authentication

| Item | Value |
|------|--------|
| Base URL | `http://127.0.0.1:18080` |
| Copilot model `url` | **Full** chat path: `http://127.0.0.1:18080/v1/chat/completions` |
| Wire format | JSON (request/response), UTF-8 |
| Auth (gateway today) | Disabled — Bearer token accepted/ignored if present |

Headers Copilot (or compatible clients) may send:

| Header | Required | Notes |
|--------|----------|--------|
| `Content-Type` | Yes for POST body | `application/json` |
| `Authorization` | No (optional) | `Bearer <apiKey>` from `chatLanguageModels.json` |
| `Accept` | No | Prefer `application/json` |

Copilot does **not** call a bare base URL only. Configure the full `/v1/chat/completions` path in each model’s `url`.

Models shown in the Copilot picker come from `chatLanguageModels.json`. `GET /v1/models` is recommended for other clients and discovery, but Copilot Chat does not depend on it for picker population.

---

## 2. Endpoint matrix

| Method | Path | Used by Copilot Chat | Required for Copilot | Purpose |
|--------|------|----------------------|----------------------|---------|
| `POST` | `/v1/chat/completions` | Yes — every chat / agent turn | **Required** | Completions, streaming, tool calls |
| `GET` | `/v1/models` | Rarely / other clients | Recommended | List available models |
| `GET` | `/v1/models/{id}` | Optional | Optional | Get one model |
| `GET` | `/health` | No | Optional | Ops / smoke test |

Primary traffic:

```http
POST /v1/chat/completions HTTP/1.1
Host: 127.0.0.1:18080
Content-Type: application/json
Authorization: Bearer local
```

Copilot may send `"stream": true`; this gateway **forbids SSE** and always returns a single JSON `chat.completion` body.

---

## 3. `GET /health`

**Not used by Copilot.** Useful for operators.

### Request

```http
GET /health HTTP/1.1
Host: 127.0.0.1:18080
```

### Response `200`

```json
{ "status": "ok" }
```

---

## 4. `GET /v1/models`

### Request

```http
GET /v1/models HTTP/1.1
Host: 127.0.0.1:18080
```

### Response `200`

OpenAI list shape:

```json
{
  "object": "list",
  "data": [
    {
      "id": "dummy-gpt",
      "object": "model",
      "created": 1784141898,
      "owned_by": "open-ai-api"
    }
  ]
}
```

Configured model ids today: `dummy-gpt`, `dummy-fast`, `dummy-tools`.

---

## 5. `GET /v1/models/{id}`

### Request

```http
GET /v1/models/dummy-gpt HTTP/1.1
Host: 127.0.0.1:18080
```

### Response `200`

```json
{
  "id": "dummy-gpt",
  "object": "model",
  "created": 1784141898,
  "owned_by": "open-ai-api"
}
```

### Response `404`

Unknown id.

---

## 6. `POST /v1/chat/completions` (required)

This is the only endpoint VS Code Copilot **must** reach for chat and agent mode.

### 6.1 Request fields

| Field | Type | Required | Notes |
|-------|------|----------|--------|
| `model` | string | Yes (practically) | Echoed on response; must match configured model `id` |
| `messages` | array | Yes | Conversation history |
| `tools` | array | No | Present in Agent mode |
| `tool_choice` | string \| object | No | `"none"` \| `"auto"` \| `{ "type":"function", "function": { "name": "..." } }` |
| `stream` | boolean | No | Always treated as `false`; responses are never SSE |
| `temperature` | number | No | Accepted, ignored by dummy provider |
| `max_tokens` | number | No | Accepted, ignored by dummy provider |

Unknown fields must not cause failure (ignore).

#### Message object

| Field | Type | Roles | Notes |
|-------|------|-------|--------|
| `role` | string | all | `system` \| `user` \| `assistant` \| `tool` |
| `content` | string \| array \| null | | String, multimodal parts `[{ "type","text" }]`, or null when `tool_calls` set |
| `tool_calls` | array | assistant | OpenAI tool call objects |
| `tool_call_id` | string | tool | Links result to prior `tool_calls[].id` |
| `name` | string | tool (optional) | Function name |

#### Tool definition object

```json
{
  "type": "function",
  "function": {
    "name": "read_file",
    "description": "...",
    "parameters": {
      "type": "object",
      "properties": { "filePath": { "type": "string" } },
      "required": ["filePath"]
    }
  }
}
```

### 6.2 Example — plain Ask (no tools)

```http
POST /v1/chat/completions HTTP/1.1
Host: 127.0.0.1:18080
Content-Type: application/json
```

```json
{
  "model": "dummy-gpt",
  "messages": [
    { "role": "user", "content": "hello" }
  ]
}
```

Expected: `finish_reason: "stop"`, `message.content` text.

### 6.3 Example — Agent first turn (tools present)

```json
{
  "model": "dummy-tools",
  "stream": false,
  "messages": [
    { "role": "user", "content": "Read the project README" }
  ],
  "tools": [
    {
      "type": "function",
      "function": {
        "name": "read_file",
        "description": "Read a file from disk",
        "parameters": {
          "type": "object",
          "properties": {
            "filePath": { "type": "string", "description": "Absolute path" }
          },
          "required": ["filePath"]
        }
      }
    }
  ],
  "tool_choice": "auto"
}
```

Expected: `finish_reason: "tool_calls"`, `message.tool_calls[]` with `function.name` and JSON string `arguments`.

### 6.4 Example — Agent follow-up (tool result)

After Copilot runs the tool locally, it POSTs again with the prior assistant `tool_calls` and a `tool` message:

```json
{
  "model": "dummy-tools",
  "messages": [
    { "role": "user", "content": "Read the project README" },
    {
      "role": "assistant",
      "tool_calls": [
        {
          "id": "call_abc123",
          "type": "function",
          "function": {
            "name": "read_file",
            "arguments": "{\"filePath\":\"C:\\\\Users\\\\sergi\\\\projects\\\\open_ai_api\\\\README.md\"}"
          }
        }
      ]
    },
    {
      "role": "tool",
      "tool_call_id": "call_abc123",
      "content": "# OpenAI-Compatible Dummy Gateway\n..."
    }
  ],
  "tools": [
    {
      "type": "function",
      "function": {
        "name": "read_file",
        "parameters": {
          "type": "object",
          "properties": { "filePath": { "type": "string" } },
          "required": ["filePath"]
        }
      }
    }
  ]
}
```

Expected: `finish_reason: "stop"`, final assistant `content` (no further `tool_calls` when last message is `tool`).

### 6.5 Example — stream ignored

Clients may send `"stream": true`; the gateway still returns a single JSON `chat.completion` body.

---

## 7. Response contract

### 7.1 Non-streaming (`stream: false` or omitted)

`Content-Type: application/json`

```json
{
  "id": "chatcmpl-...",
  "object": "chat.completion",
  "created": 1784141900,
  "model": "dummy-gpt",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "content": "Dummy reply to: hello"
      },
      "finish_reason": "stop"
    }
  ],
  "usage": {
    "prompt_tokens": 16,
    "completion_tokens": 32,
    "total_tokens": 48
  }
}
```

Tool-call variant:

```json
{
  "id": "chatcmpl-...",
  "object": "chat.completion",
  "created": 1784141900,
  "model": "dummy-tools",
  "choices": [
    {
      "index": 0,
      "message": {
        "role": "assistant",
        "tool_calls": [
          {
            "id": "call_...",
            "type": "function",
            "function": {
              "name": "read_file",
              "arguments": "{\"filePath\":\"C:\\\\Users\\\\sergi\\\\projects\\\\open_ai_api\\\\README.md\"}"
            }
          }
        ]
      },
      "finish_reason": "tool_calls"
    }
  ],
  "usage": {
    "prompt_tokens": 16,
    "completion_tokens": 32,
    "total_tokens": 48
  }
}
```

| `finish_reason` | Meaning |
|-----------------|---------|
| `stop` | Final text answer in `message.content` |
| `tool_calls` | Model requests tool execution via `message.tool_calls` |

### 7.2 Streaming / SSE

Forbidden. Never returns `text/event-stream`. `stream: true` is ignored; response is always §7.1 JSON.

---

## 8. Agent tool-call sequence

Copilot owns tool execution. The gateway only returns OpenAI-shaped `tool_calls` and later consumes `role: "tool"` results.

```mermaid
sequenceDiagram
  participant Copilot as VSCode_Copilot
  participant GW as Spring_Gateway
  participant Tools as VSCode_Tools
  Copilot->>GW: POST /v1/chat/completions with tools
  GW-->>Copilot: finish_reason tool_calls
  Copilot->>Tools: execute tool locally
  Tools-->>Copilot: tool result or error text
  Copilot->>GW: POST /v1/chat/completions with tool message
  GW-->>Copilot: finish_reason stop content
```

### Implementation notes (VS Code tools, not OpenAI protocol)

These are constraints of **VS Code Copilot tools**, not of the HTTP schema:

| Tool (example) | Argument requirement |
|----------------|----------------------|
| `read_file` | Required property is typically `filePath` (not `path`) |
| `read_file` | `filePath` must be an **absolute** filesystem path |
| Terminal-like tools | Often expect a `command` (or similar) string |

The dummy provider fills `arguments` from each tool’s JSON Schema `required` / `properties` when present.

---

## 9. Status codes and errors

| Code | When |
|------|------|
| `200` | Successful completion or stream start |
| `400` | Unreadable / invalid JSON body |
| `404` | `GET /v1/models/{id}` unknown id |
| `500` | Unhandled server error |

Error body shape (JSON):

```json
{
  "error": {
    "message": "human readable detail",
    "type": "invalid_request_error"
  }
}
```

`type` may be `invalid_request_error` or `server_error`.

Wrong port (e.g. Copilot pointed at another local app on `8080`) often surfaces in VS Code as a generic **Server error: 500** — verify `url` matches this gateway (`18080` by default).

---

## 10. Curl cookbook

Replace host/port if you override `server.port`.

### Health

```bash
curl http://127.0.0.1:18080/health
```

### List models

```bash
curl http://127.0.0.1:18080/v1/models
```

### Text completion

```bash
curl http://127.0.0.1:18080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d "{\"model\":\"dummy-gpt\",\"messages\":[{\"role\":\"user\",\"content\":\"hello\"}]}"
```

### Tool call

```bash
curl http://127.0.0.1:18080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d "{\"model\":\"dummy-tools\",\"messages\":[{\"role\":\"user\",\"content\":\"read\"}],\"tools\":[{\"type\":\"function\",\"function\":{\"name\":\"read_file\",\"parameters\":{\"type\":\"object\",\"properties\":{\"filePath\":{\"type\":\"string\"}},\"required\":[\"filePath\"]}}}]}"
```

### Stream

```bash
curl -N http://127.0.0.1:18080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d "{\"model\":\"dummy-fast\",\"stream\":true,\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}"
```

---

## 11. Copilot configuration mapping

| `chatLanguageModels.json` | HTTP / runtime |
|---------------------------|----------------|
| `apiType: "chat-completions"` | Uses this Chat Completions contract |
| `models[].url` | Exact `POST` target URL |
| `models[].id` | Sent as request `model` |
| `models[].toolCalling: true` | Required for Agent mode / tools in picker |
| `apiKey` | Sent as `Authorization: Bearer ...` (ignored by gateway today) |

Out of scope for this gateway contract: Anthropic Messages API, OpenAI Responses API, Cursor-specific routing.
