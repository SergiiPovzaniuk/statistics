# OpenAI-Compatible Dummy Gateway

Local Spring Boot (Java 21) gateway for VS Code Copilot. Proxies OpenAI Chat Completions to the Cursor API Control UI at `http://127.0.0.1:8081/ui/run`.

## Run

```bash
./mvnw spring-boot:run
```

Listens on `http://127.0.0.1:18080`.

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Health check |
| GET | `/v1/models` | List models |
| GET | `/v1/models/{id}` | Get model |
| POST | `/v1/chat/completions` | Chat completions. Upstream (Playwright page) is JSON REST only. If client sends `stream: true` (VS Code Copilot), gateway adapts the result to SSE for the client. |

## VS Code Copilot (BYOK)

Step-by-step: [`docs/VSCODE_COPILOT_SETUP.md`](docs/VSCODE_COPILOT_SETUP.md)

HTTP methods / request contract: [`docs/VSCODE_COPILOT_API_SPEC.md`](docs/VSCODE_COPILOT_API_SPEC.md)

Template: [`docs/chatLanguageModels.example.json`](docs/chatLanguageModels.example.json) (`toolCalling: true`).

## Smoke test

```bash
curl http://127.0.0.1:18080/v1/models
curl http://127.0.0.1:18080/v1/chat/completions -H "Content-Type: application/json" -d "{\"model\":\"dummy-gpt\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}"
```

## Future

`app.future.vscode-bridge-url` is reserved for a provider that proxies Cursor traffic to a VS Code Copilot bridge.

## Upstream (Cursor API Control via Playwright)

When `app.upstream.use-playwright: true` (default), chat requests are automated through the browser UI at `http://127.0.0.1:8081/` (fill request → Send → read response). Start the Cursor API service on `8081` first.
