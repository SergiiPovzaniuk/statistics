# OpenAI-Compatible Cursor Gateway

Spring Boot (Java 21) gateway for VS Code Copilot. Proxies OpenAI Chat Completions to the Cursor ACP service (`open_ai_cursor_api`) via Playwright browser automation.

## Architecture

```
Remote PC (VS Code + open_ai_api)          Host PC (Cursor API proxy only)
┌─────────────────────────────┐            ┌──────────────────────────────┐
│ VS Code Copilot             │            │ open_ai_cursor_api :8081     │
│ open_ai_api :18080          │ Playwright │ Cursor CLI ACP (ask mode)    │
│ Tools edit remote workspace │ ─────────► │ LLM only — no host file edits│
└─────────────────────────────┘            └──────────────────────────────┘
```

- **Agent mode** (`tools[]`): Cursor returns OpenAI `tool_calls`; **VS Code executes them on the remote PC**.
- **Ask / Plan**: text answers; host does not write project files (`CURSOR_ACP_MODE=ask` by default).

## Run

**Host PC** (Cursor API):

```bash
cd open_ai_cursor_api
PORT=8081 node --env-file=.env dist/index.js
```

**Remote PC** (gateway):

```bash
cd open_ai_api
./mvnw spring-boot:run
```

Listens on `http://127.0.0.1:18080`. Set `app.upstream.page-url` to the host IP reachable via browser.

## Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/health` | Health check (proxies upstream when enabled) |
| GET | `/v1/models` | List models (from Cursor upstream when enabled) |
| GET | `/v1/models/{id}` | Get model |
| POST | `/v1/chat/completions` | Chat completions via Cursor ACP. `stream: true` adapted to SSE for Copilot. |

## Configuration

| Key | Default | Description |
|-----|---------|-------------|
| `app.upstream.enabled` | `true` | Proxy to Cursor API |
| `app.upstream.page-url` | `http://127.0.0.1:8081/` | Browser UI for Playwright |
| `app.upstream.cursor-cwd` | empty | Optional; only for non-tool Ask/Plan. Not injected when `tools[]` present |
| `app.upstream.session-resume` | `true` | Auto-resume ACP sessions via `cursor.agentId` |
| `app.llm.enabled` | `false` | Optional LLM fallback (off by default) |

Models starting with `dummy-` use the local dummy provider for offline smoke tests.

## VS Code Copilot (BYOK)

Step-by-step: [`docs/VSCODE_COPILOT_SETUP.md`](docs/VSCODE_COPILOT_SETUP.md)

HTTP contract: [`docs/VSCODE_COPILOT_API_SPEC.md`](docs/VSCODE_COPILOT_API_SPEC.md)

Template: [`docs/chatLanguageModels.example.json`](docs/chatLanguageModels.example.json)

## Smoke test

```bash
curl http://127.0.0.1:18080/health
curl http://127.0.0.1:18080/v1/models
curl http://127.0.0.1:18080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d "{\"model\":\"dummy-gpt\",\"messages\":[{\"role\":\"user\",\"content\":\"hi\"}]}"
```
