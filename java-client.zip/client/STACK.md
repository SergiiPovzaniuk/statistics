# Stack Setup (Remote-First)

Four-service integration for Copilot Desktop + Cursor Agent SDK.

## Topology

```
┌─────────────────┐     :8080      ┌─────────────────┐   Playwright   ┌──────────────────┐
│  java-client    │ ─────────────► │  client         │ ─────────────► │  http_manager    │
│  (local JavaFX) │ ◄─ enc SSE ─── │  (local Spring) │                │  (remote :5554)  │
└─────────────────┘                └─────────────────┘                └────────┬─────────┘
                                                                                 │ /ui/cursor/*
                                                                                 ▼
                                                                        ┌──────────────────┐
                                                                        │  cursor_api      │
                                                                        │  (remote :3000)  │
                                                                        └──────────────────┘
```

## Remote host (cursor_api + http_manager)

### cursor_api

```bash
cd cursor_api
cp .env.example .env
# Set CURSOR_API_KEY, TRANSPORT_ENCRYPTION_KEY, WORKSPACE_PATH
npm install
npm run dev
```

`.env` minimum:

```env
CURSOR_API_KEY=crsr_...
BASIC_AUTH_USER=cursor
BASIC_AUTH_PASSWORD=web123
TRANSPORT_ENCRYPTION_KEY=<32-byte-base64>
WORKSPACE_PATH=/path/to/workspace
```

Verify: `curl http://<remote>:3000/`

### http_manager

```bash
cd http_manager
cp .env.example .env
npm install
npm run dev
```

`.env`:

```env
API_PORT=5554
CURSOR_WEB_URL=http://127.0.0.1:3000
```

Docker: use `CURSOR_WEB_URL=http://host.docker.internal:3000` in `docker-compose.yml`.

Verify: open `http://<remote>:5554` → Cursor tab → session → `encryptionKey` returned.

## Developer machine (client + java-client)

### client

```powershell
$env:PROXY_UI_URL="http://46.174.75.130:5554/"
$env:CURSOR_WEB_USERNAME="cursor"
$env:CURSOR_WEB_PASSWORD="web123"
cd client
mvn spring-boot:run
```

Verify: `curl http://localhost:8080/api/session`

### java-client

```bash
cd java-client
mvn javafx:run
```

Defaults: URL `http://localhost:8080`, user `cursor`, pass `web123`.

1. **Connect** (defaults work if client is running)
2. **Open Folder** — local workspace
3. **Agent** mode — chat applies `file_op` to local disk

## Startup order

1. cursor_api `:3000`
2. http_manager `:5554`
3. client `:8080`
4. java-client

## Credentials (must match)

| Service | User | Password |
|---------|------|----------|
| cursor_api | `cursor` | `web123` |
| http_manager Cursor tab | `cursor` | `web123` |
| client env | `cursor` | `web123` |
| java-client Connect | `cursor` | `web123` |

## Troubleshooting

| Symptom | Check |
|---------|-------|
| 401 on session | Auth mismatch between http_manager UI creds and cursor_api `.env` |
| client Playwright timeout | `PROXY_UI_URL` reachable; http_manager running |
| Chat fails, session OK | Encrypted chat passthrough; ensure `allow-plaintext=false` |
| No file changes | java-client in **Agent** mode; workspace folder open |
