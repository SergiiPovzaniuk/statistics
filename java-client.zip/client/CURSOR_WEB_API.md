# Cursor Web Service — API Specification

HTTP API for the **Cursor Web** application: a browser-hosted IDE that proxies chat to the Cursor Agent SDK on the server PC. Clients authenticate with HTTP Basic Auth, encrypt chat payloads with AES-256-GCM, and receive streaming results over Server-Sent Events (SSE).

**Base URL:** `http://<host>:3000` (default port)

**UI entry point:** `GET /` — serves the IDE (no API auth on the HTML page; API calls require credentials).

---

## Table of contents

1. [Architecture](#architecture)
2. [Authentication](#authentication)
3. [Transport encryption](#transport-encryption)
4. [Endpoints](#endpoints)
5. [Chat streaming (SSE)](#chat-streaming-sse)
6. [File operations (`file_op`)](#file-operations-file_op)
7. [Workspace API](#workspace-api)
8. [Sessions & multi-turn chat](#sessions--multi-turn-chat)
9. [Data types](#data-types)
10. [Errors](#errors)
11. [Server configuration](#server-configuration)
12. [Client integration](#client-integration)

---

## Architecture

```
java-client :8080  →  client (Playwright) :8080  →  http_manager :5554  →  cursor_api :3000
                                                                                      ↓
                                                                               @cursor/sdk Agent
```

This service (`client`) exposes the same `/api/*` contract. Chat: encrypted payload in, encrypted SSE out.

| Layer | Protocol | Notes |
|-------|----------|-------|
| Transport | HTTP | No WebSockets for chat |
| Auth | HTTP Basic | All `/api/*` routes |
| Chat body | AES-256-GCM JSON | Request + each SSE `data:` line |
| Streaming | SSE | `Content-Type: text/event-stream` |
| Workspace | Plain JSON | File list/read/write on server disk |

**Agent / Extension mode:** The model does **not** write to the client filesystem. It emits `file_op` SSE events; the **client** applies creates/updates/deletes locally (real disk, server workspace, or in-memory virtual files).

**Ask mode:** Q&A only — no `file_op` events.

---

## Authentication

All routes under `/api/*` require HTTP Basic Authentication when `BASIC_AUTH_USER` and `BASIC_AUTH_PASSWORD` are set on the server.

```http
Authorization: Basic <base64(username:password)>
```

| Status | Meaning |
|--------|---------|
| `401` | Missing or invalid credentials |
| `WWW-Authenticate` | `Basic realm="Cursor Web"` |

If auth env vars are unset, API routes are open (not recommended for production).

**Browser IDE:** Credentials are entered on a sign-in screen and stored in `sessionStorage`; each `fetch` includes the `Authorization` header.

**CORS:** `Access-Control-Allow-Origin: *` with `Authorization` allowed — suitable for static clients on other origins.

**Preflight:** `OPTIONS` requests to `/api/*` return `204` with CORS headers.

---

## Transport encryption

Chat requests and SSE events use **AES-256-GCM** with a shared key from `TRANSPORT_ENCRYPTION_KEY` (32 bytes, base64).

### Encrypted payload shape

```typescript
interface EncryptedPayload {
  v: 1;
  iv: string;        // 12-byte nonce, base64
  ciphertext: string; // base64
  tag: string;        // 16-byte GCM auth tag, base64
}
```

### Bootstrap

1. `GET /api/session` (authenticated) → returns `encryptionKey` (same value as server env).
2. Client encrypts `ChatRequest` JSON → POST `/api/chat`.
3. Client decrypts each SSE `data:` line to obtain `SSEEvent` objects.

### Plaintext bypass

Set `ALLOW_PLAINTEXT=true` on the server to accept unencrypted JSON bodies and emit unencrypted SSE events. **Development only.**

---

## Endpoints

### Summary

| Method | Path | Auth | Description |
|--------|------|------|-------------|
| `GET` | `/api/session` | Yes | Bootstrap: encryption key + workspace info |
| `GET` | `/api/models` | Yes | List available Cursor models |
| `POST` | `/api/chat` | Yes | Streaming chat (SSE) |
| `GET` | `/api/workspace` | Yes | List server workspace tree |
| `GET` | `/api/workspace/file` | Yes | Read file from server workspace |
| `PUT` | `/api/workspace/file` | Yes | Write file to server workspace |
| `DELETE` | `/api/workspace/file` | Yes | Delete file/folder in server workspace |
| `POST` | `/api/workspace/mkdir` | Yes | Create folder in server workspace |

---

### `GET /api/session`

Initialize client session. Call once after sign-in (or when credentials change).

**Request**

```http
GET /api/session
Authorization: Basic <credentials>
```

**Response `200`**

```json
{
  "encryptionKey": "Bo6yeObKlxPLzm/GV41ZAhHfittXvVYz1D84NtHE61A=",
  "workspacePath": "C:\\Users\\dev\\projects\\my-app",
  "workspaceName": "my-app",
  "workspacePaths": [
    "package.json",
    "src/",
    "src/app/page.tsx"
  ]
}
```

| Field | Type | Description |
|-------|------|-------------|
| `encryptionKey` | `string` | Base64 AES-256 key for chat encrypt/decrypt |
| `workspacePath` | `string` | Absolute server `WORKSPACE_PATH` |
| `workspaceName` | `string` | Last segment of workspace path |
| `workspacePaths` | `string[]` | Relative paths; directories end with `/` |

**Errors:** `401` auth, `500` missing `TRANSPORT_ENCRYPTION_KEY` or invalid `WORKSPACE_PATH`.

---

### `GET /api/models`

List models available to the server's Cursor API key.

**Request**

```http
GET /api/models
Authorization: Basic <credentials>
```

**Response `200`**

```json
{
  "models": [
    { "id": "default", "label": "Auto", "contextLimit": 128000 },
    { "id": "composer-2.5", "label": "Composer 2.5", "contextLimit": 128000 },
    { "id": "claude-sonnet-4-6", "label": "Sonnet 4.6", "contextLimit": 200000 }
  ]
}
```

**Model selection**

| `id` | Behavior |
|------|----------|
| `"default"` | **Auto** — Cursor picks a cost-efficient model (recommended) |
| `"auto"` or `""` | Treated as Auto |
| Any other `id` | Fixed model for all turns in that agent session |

---

### `POST /api/chat`

Send a user message and receive a streaming assistant response.

**Request**

```http
POST /api/chat
Authorization: Basic <credentials>
Content-Type: application/octet-stream

<body: JSON string of EncryptedPayload decrypting to ChatRequest>
```

**Decrypted body (`ChatRequest`)**

```typescript
interface ChatRequest {
  model: string;      // "default" or explicit model id
  mode: "agent" | "ask" | "extension";
  context: string;    // file snippets, rules, workspace summary
  prompt: string;     // user message (required)
  sessionId?: string; // reuse from prior "done" event for multi-turn
}
```

**Validation**

| Field | Rule |
|-------|------|
| `prompt` | Required, non-empty after trim |
| `model` | Required unless Auto (`default` / `auto` / empty) |
| `mode` | Must be `agent`, `ask`, or `extension` |

**Response `200`**

```http
Content-Type: text/event-stream
Cache-Control: no-cache
Connection: keep-alive
```

Stream format — one event per line:

```
data: {"v":1,"iv":"...","ciphertext":"...","tag":"..."}

```

Decrypt each `data:` payload to `SSEEvent` (see [Chat streaming](#chat-streaming-sse)).

**Error responses**

| Status | Body |
|--------|------|
| `400` | Encrypted JSON `{ "error": "message" }` |
| `401` | `Authentication required` |

Runtime errors are emitted as SSE `{ type: "error", message }` and the stream closes.

---

### `GET /api/workspace`

List files and folders under server `WORKSPACE_PATH`.

**Response `200`**

```json
{
  "workspacePath": "C:\\Users\\dev\\projects\\my-app",
  "name": "my-app",
  "paths": ["README.md", "src/", "src/index.ts"]
}
```

Skipped directories: `node_modules`, `.git`, `.next`, `dist`, `build`, `.turbo`, `coverage`.

---

### `GET /api/workspace/file`

Read a single file from the server workspace.

**Query**

| Param | Required | Description |
|-------|----------|-------------|
| `path` | Yes | Relative path (forward slashes) |

```http
GET /api/workspace/file?path=src%2Fapp.ts
```

**Response `200`**

```json
{
  "path": "src/app.ts",
  "content": "export const x = 1;\n"
}
```

**Errors:** `400` missing path, `404` not found, `500` other.

Paths outside `WORKSPACE_PATH` return `500` with `"Path outside workspace"`.

---

### `PUT /api/workspace/file`

Create or overwrite a file on the server workspace.

**Body**

```json
{
  "path": "src/new-file.ts",
  "content": "export {};\n"
}
```

**Response `200`**

```json
{
  "ok": true,
  "path": "src/new-file.ts"
}
```

Parent directories are created automatically.

---

### `DELETE /api/workspace/file`

Delete a file or directory in the server workspace.

**Query**

| Param | Required | Description |
|-------|----------|-------------|
| `path` | Yes | Relative path |
| `dir` | No | `"1"` to delete directory recursively |

**Response `200`**

```json
{
  "ok": true,
  "path": "src/old-file.ts"
}
```

---

### `POST /api/workspace/mkdir`

Create a directory (and parents) in the server workspace.

**Body**

```json
{
  "path": "src/components"
}
```

**Response `200`**

```json
{
  "ok": true,
  "path": "src/components"
}
```

---

## Chat streaming (SSE)

### Event types

```typescript
type SSEEvent =
  | { type: "token"; content: string }
  | { type: "thinking"; content: string }
  | { type: "tool"; name: string; status: string; summary?: string }
  | {
      type: "file_op";
      operation: "create" | "update" | "delete";
      path: string;
      content?: string;
    }
  | { type: "read_op"; path: string }
  | { type: "shell_op"; command: string; cwd?: string }
  | {
      type: "usage";
      model: string;
      inputTokens: number;
      outputTokens: number;
      cacheReadTokens?: number;
      cacheWriteTokens?: number;
      contextLimit?: number;
    }
  | {
      type: "context";
      chars: number;
      estimatedTokens: number;
      contextLimit?: number;
    }
  | { type: "done"; sessionId: string; agentId: string }
  | { type: "error"; message: string };
```

### Event order (typical)

1. `context` — pre-run size estimate (after server trims `context` to budget)
2. `token` / `thinking` — streamed assistant output (many events)
3. `read_op` / `shell_op` / `file_op` — zero or more, during/after tokens in `agent` / `extension` mode
4. `usage` — token counts when the model turn ends
5. `done` — persist `sessionId` for the next message
6. `error` — terminal failure (may appear instead of `done`)

### Client handling

| Event | Action |
|-------|--------|
| `token` | Append to assistant message UI |
| `thinking` | Optional reasoning panel |
| `tool` | Tool status card (legacy; local agent suppresses remote tools) |
| `file_op` | Apply change on **client** filesystem (see below) |
| `read_op` | Client reads local file and returns content in follow-up turn |
| `shell_op` | Client runs shell command locally (auto-run) |
| `usage` | Update token meter |
| `context` | Show estimated context size |
| `done` | Store `sessionId`; optional `agentId` for debugging |
| `error` | Show error; start new `sessionId` if crypto/auth failed |

### Parsing SSE (client pseudocode)

```typescript
const reader = response.body.getReader();
const decoder = new TextDecoder();
let buffer = "";

while (true) {
  const { done, value } = await reader.read();
  if (done) break;
  buffer += decoder.decode(value, { stream: true });
  const parts = buffer.split("\n\n");
  buffer = parts.pop() ?? "";
  for (const part of parts) {
    const line = part.split("\n").find((l) => l.startsWith("data: "));
    if (!line) continue;
    const payload = JSON.parse(line.slice(6));
    const event = isEncrypted(payload)
      ? await decryptSSEEvent(encryptionKey, payload)
      : payload;
    onEvent(event);
  }
}
```

---

## File operations (`file_op`)

Emitted only when `mode` is **`agent`** or **`extension`**. The server parses `vscode-file` fenced blocks from the model output.

### Model output format (heredoc)

````markdown
```vscode-file
create
src/utils.ts
---
export const add = (a: number, b: number) => a + b;
```
````

| Line | Content |
|------|---------|
| 1 | `create` \| `update` \| `delete` |
| 2 | Relative path (forward slashes) |
| 3 | `---` |
| 4+ | Full file content (create/update only) |

Alternative (small files): JSON inside ` ```vscode-file ` fence:

```json
{"op":"create","path":"test.txt","content":"hello"}
```

### SSE `file_op` event

```json
{
  "type": "file_op",
  "operation": "create",
  "path": "src/utils.ts",
  "content": "export const add = ..."
}
```

### Client apply semantics

| `operation` | Client action |
|---------------|---------------|
| `create` | Write `content` to `path` (create virtual file if no disk access) |
| `update` | Overwrite `path` with `content` |
| `delete` | Remove `path` |

**Virtual mode (browser IDE):** When the client cannot access local disk, files live in memory. Agent changes apply automatically without a diff modal.

**Server workspace mode:** Client may call `PUT /api/workspace/file` instead of local FS.

---

## Read operations (`read_op`)

Emitted when the model outputs a `vscode-read` fence in `agent` / `extension` mode. The **client** reads the file locally and sends content back in a follow-up message.

### Model output format

````markdown
```vscode-read
src/App.java
```
````

### SSE `read_op` event

```json
{ "type": "read_op", "path": "src/App.java" }
```

---

## Shell operations (`shell_op`)

Emitted when the model outputs a `vscode-shell` fence. The **client** runs the command locally (auto-run, no approval).

### Model output format

````markdown
```vscode-shell
npm test
```
````

Optional second line = relative cwd subdirectory:

````markdown
```vscode-shell
npm test
client
```
````

### SSE `shell_op` event

```json
{ "type": "shell_op", "command": "npm test", "cwd": "client" }
```

---

## Workspace API

The workspace API operates on the server's `WORKSPACE_PATH` only. It does **not** access the remote user's local machine.

Use cases:

- Browse/edit the project on the **server PC**
- Fallback when `GET /api/workspace` is unavailable — `GET /api/session` includes `workspacePaths`

Security: all paths are resolved under `WORKSPACE_PATH`; traversal outside the root is rejected.

---

## Sessions & multi-turn chat

Server stores in-memory session records:

```typescript
{ agentId: string; mode: ChatMode; createdAt: number }
```

| Client `sessionId` | Server behavior |
|--------------------|-----------------|
| Omitted / new UUID | `Agent.create()` — new Cursor agent |
| Known `sessionId` | `Agent.resume(agentId)` — continues conversation |

**New chat:** Generate a new `sessionId` (UUID) on the client; do not send the old one.

**Server restart:** In-memory sessions are lost; clients must start a new `sessionId`.

The Cursor SDK always runs in `agent` mode internally; `ask` / `extension` only change prompt rules and whether `file_op` is parsed.

---

## Data types

### `ChatMode`

| Value | Description |
|-------|-------------|
| `agent` | Local file edits via `file_op` |
| `ask` | Read-only Q&A |
| `extension` | Same file semantics as `agent` (VS Code extension compatibility) |

### `ModelOption`

```typescript
interface ModelOption {
  id: string;
  label: string;
  contextLimit?: number;
}
```

### Context budget

Server trims `context` to `MAX_CONTEXT_CHARS` (default `32000`) before sending to the model, keeping ~70% head and ~30% tail with a truncation marker.

Token estimate: `ceil(chars / 4)`.

---

## Errors

| HTTP | When |
|------|------|
| `400` | Invalid chat body, missing fields |
| `401` | Basic auth failure |
| `404` | Workspace file not found |
| `500` | Server misconfiguration, Cursor API failure, workspace I/O |

SSE `error` events (decrypted):

| Message (examples) | Cause |
|--------------------|-------|
| `CURSOR_API_KEY is not set` | Server env |
| `TRANSPORT_ENCRYPTION_KEY is not set` | Server env |
| `Plaintext requests are disabled` | Client sent unencrypted body |
| `Cursor agent run failed` | SDK run error |

---

## Server configuration

`.env` on the server PC:

```env
CURSOR_API_KEY=crsr_...
BASIC_AUTH_USER=cursor
BASIC_AUTH_PASSWORD=web123
TRANSPORT_ENCRYPTION_KEY=<base64-32-bytes>
WORKSPACE_PATH=C:\path\to\project
ALLOW_PLAINTEXT=false
ALLOWED_DEV_ORIGINS=192.168.1.13,localhost,127.0.0.1
MAX_CONTEXT_CHARS=32000
```

| Variable | Required | Description |
|----------|----------|-------------|
| `CURSOR_API_KEY` | Yes | Cursor API key |
| `BASIC_AUTH_USER` | Recommended | API username |
| `BASIC_AUTH_PASSWORD` | Recommended | API password |
| `TRANSPORT_ENCRYPTION_KEY` | Yes | 32-byte key, base64 |
| `WORKSPACE_PATH` | Yes | Server project root for SDK + workspace API |
| `ALLOW_PLAINTEXT` | No | `true` to skip encryption (dev only) |
| `ALLOWED_DEV_ORIGINS` | No | Next.js dev HMR hosts |
| `MAX_CONTEXT_CHARS` | No | Context trim limit (default 32000) |

Generate encryption key:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

---

## Client integration

### Minimal flow

1. Sign in → store Basic Auth credentials.
2. `GET /api/session` → cache `encryptionKey`.
3. `GET /api/models` → populate model picker.
4. Build `context` from open files, `@mentions`, and optional user context.
5. Encrypt `ChatRequest` → `POST /api/chat` → read SSE until `done` or `error`.
6. On `file_op` → apply to virtual/local/server filesystem.
7. Reuse `sessionId` from `done` for follow-up messages.

### Remote browser client

| Access | Filesystem |
|--------|------------|
| `http://<server-ip>:3000` | Use **virtual files** (+F) or **Server** workspace button |
| Local folder picker | Requires secure context (HTTPS or localhost) — optional |

### Related documentation

- [VSCODE_EXTENSION_API.md](./VSCODE_EXTENSION_API.md) — VS Code extension client, shared protocol details, and reference implementation patterns.

---

## Changelog

| Version | Notes |
|---------|-------|
| 0.1.0 | Initial Cursor Web API: session, models, chat SSE, workspace CRUD, virtual file client |
