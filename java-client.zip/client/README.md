# Playwright Proxy Client (Cursor Web API)

Java 21 Spring Boot bridge between **java-client** and remote **http_manager**. Playwright drives the http_manager Cursor tab; this service exposes the same `/api/*` contract as cursor_api.

## Architecture

```
java-client  →  client (this) :8080  →  Playwright  →  http_manager :5554  →  cursor_api :3000
```

Chat accepts **encrypted** `EncryptedPayload` bodies and returns **encrypted** SSE (spec-compliant passthrough for java-client).

## Configuration

| Property | Env var | Default |
|---|---|---|
| `playwright.proxy-ui.url` | `PROXY_UI_URL` | `http://46.174.75.130:5554/` |
| `cursor-web.username` | `CURSOR_WEB_USERNAME` | `cursor` |
| `cursor-web.password` | `CURSOR_WEB_PASSWORD` | `web123` |
| `cursor-web.allow-plaintext` | `CURSOR_WEB_ALLOW_PLAINTEXT` | `false` |
| `playwright.chrome.executable-path` | `CHROME_EXECUTABLE_PATH` | Chrome path |

http_manager must set `CURSOR_WEB_URL` to cursor_api on the same remote host.

## API (mirrors Cursor Web)

| Method | Path |
|---|---|
| GET | `/api/session` |
| GET | `/api/models` |
| GET | `/api/workspace` |
| GET | `/api/workspace/file?path=` |
| PUT | `/api/workspace/file` |
| DELETE | `/api/workspace/file?path=&dir=` |
| POST | `/api/workspace/mkdir` |
| POST | `/api/chat` |

`POST /api/chat`: encrypted payload in → encrypted SSE out. Plaintext only when `allow-plaintext=true` (dev).

## Run (remote http_manager)

```powershell
$env:PROXY_UI_URL="http://46.174.75.130:5554/"
$env:CURSOR_WEB_USERNAME="cursor"
$env:CURSOR_WEB_PASSWORD="web123"
mvn spring-boot:run
```

Local http_manager override: `$env:PROXY_UI_URL="http://localhost:5554/"`

## Tests

```bash
mvn test
mvn test -Dintegration.tests=true
```

See [STACK.md](STACK.md) for full remote stack setup.
