package com.client.proxy.crypto;

import com.client.proxy.dto.EncryptedPayload;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class SseParserService {

    private final ObjectMapper objectMapper;
    private final TransportCryptoService cryptoService;

    public SseParserService(ObjectMapper objectMapper, TransportCryptoService cryptoService) {
        this.objectMapper = objectMapper;
        this.cryptoService = cryptoService;
    }

    public List<JsonNode> parseEvents(String raw, String encryptionKey, boolean allowPlaintext) {
        List<JsonNode> events = new ArrayList<>();
        if (raw == null || raw.isBlank()) {
            return events;
        }

        if (raw.contains("data: ")) {
            parseSseBlocks(raw, encryptionKey, allowPlaintext, events);
        } else {
            parseJsonLines(raw, encryptionKey, allowPlaintext, events);
        }
        return events;
    }

    private void parseSseBlocks(String raw, String encryptionKey, boolean allowPlaintext, List<JsonNode> events) {
        for (String part : raw.split("\n\n")) {
            if (part.isBlank()) {
                continue;
            }
            String line = null;
            for (String item : part.split("\n")) {
                if (item.startsWith("data: ")) {
                    line = item.substring(6);
                    break;
                }
            }
            addParsedEvent(line, encryptionKey, allowPlaintext, events);
        }
    }

    private void parseJsonLines(String raw, String encryptionKey, boolean allowPlaintext, List<JsonNode> events) {
        for (String line : raw.split("\n")) {
            if (line.isBlank()) {
                continue;
            }
            addParsedEvent(line.trim(), encryptionKey, allowPlaintext, events);
        }
    }

    private void addParsedEvent(String line, String encryptionKey, boolean allowPlaintext, List<JsonNode> events) {
        if (line == null || line.isBlank()) {
            return;
        }
        try {
            JsonNode parsed = objectMapper.readTree(line);
            if (!allowPlaintext && encryptionKey != null && isEncrypted(parsed)) {
                EncryptedPayload payload = objectMapper.convertValue(parsed, EncryptedPayload.class);
                events.add(objectMapper.valueToTree(cryptoService.decryptJson(encryptionKey, payload, JsonNode.class)));
            } else {
                events.add(parsed);
            }
        } catch (Exception ignored) {
        }
    }

    public boolean isEncrypted(JsonNode node) {
        return node.has("v")
                && node.get("v").asInt() == 1
                && node.has("iv")
                && node.has("ciphertext")
                && node.has("tag");
    }

    public List<String> extractEncryptedLines(String raw) {
        List<String> lines = new ArrayList<>();
        if (raw == null || raw.isBlank()) {
            return lines;
        }
        if (raw.contains("data: ")) {
            for (String part : raw.split("\n\n")) {
                if (part.isBlank()) {
                    continue;
                }
                for (String item : part.split("\n")) {
                    if (item.startsWith("data: ")) {
                        addEncryptedLine(item.substring(6).trim(), lines);
                        break;
                    }
                }
            }
        } else {
            for (String line : raw.split("\n")) {
                if (!line.isBlank()) {
                    addEncryptedLine(line.trim(), lines);
                }
            }
        }
        return lines;
    }

    public String formatEncryptedSse(String raw) {
        StringBuilder sb = new StringBuilder();
        for (String line : extractEncryptedLines(raw)) {
            sb.append("data: ").append(line).append("\n\n");
        }
        return sb.toString();
    }

    private void addEncryptedLine(String line, List<String> lines) {
        if (line.isBlank()) {
            return;
        }
        try {
            JsonNode parsed = objectMapper.readTree(line);
            if (isEncrypted(parsed)) {
                lines.add(line);
            }
        } catch (Exception ignored) {
        }
    }
}
