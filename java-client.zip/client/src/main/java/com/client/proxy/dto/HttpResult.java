package com.client.proxy.dto;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.List;
import java.util.Map;

public record HttpResult(int status, Map<String, String> headers, JsonNode body, String raw, boolean ok) {
}
