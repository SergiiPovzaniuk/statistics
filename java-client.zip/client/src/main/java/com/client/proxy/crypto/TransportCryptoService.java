package com.client.proxy.crypto;

import com.client.proxy.dto.EncryptedPayload;
import com.client.proxy.exception.ProxyAutomationException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.springframework.stereotype.Service;

@Service
public class TransportCryptoService {

    private static final int IV_LENGTH = 12;
    private static final int TAG_LENGTH = 16;

    private final ObjectMapper objectMapper;
    private final SecureRandom secureRandom = new SecureRandom();

    public TransportCryptoService(ObjectMapper objectMapper) {
        this.objectMapper = objectMapper;
    }

    public EncryptedPayload encryptJson(String keyBase64, Object data) {
        try {
            byte[] key = decodeKey(keyBase64);
            byte[] iv = new byte[IV_LENGTH];
            secureRandom.nextBytes(iv);
            byte[] plaintext = objectMapper.writeValueAsBytes(data);
            byte[] sealed = encrypt(key, iv, plaintext);
            byte[] ciphertext = new byte[sealed.length - TAG_LENGTH];
            byte[] tag = new byte[TAG_LENGTH];
            System.arraycopy(sealed, 0, ciphertext, 0, ciphertext.length);
            System.arraycopy(sealed, ciphertext.length, tag, 0, TAG_LENGTH);
            return new EncryptedPayload(1, encodeBase64(iv), encodeBase64(ciphertext), encodeBase64(tag));
        } catch (Exception ex) {
            throw new ProxyAutomationException("Failed to encrypt payload", ex);
        }
    }

    public <T> T decryptJson(String keyBase64, EncryptedPayload payload, Class<T> type) {
        try {
            byte[] key = decodeKey(keyBase64);
            byte[] iv = Base64.getDecoder().decode(payload.iv());
            byte[] ciphertext = Base64.getDecoder().decode(payload.ciphertext());
            byte[] tag = Base64.getDecoder().decode(payload.tag());
            byte[] combined = new byte[ciphertext.length + tag.length];
            System.arraycopy(ciphertext, 0, combined, 0, ciphertext.length);
            System.arraycopy(tag, 0, combined, ciphertext.length, tag.length);
            byte[] plaintext = decrypt(key, iv, combined);
            return objectMapper.readValue(plaintext, type);
        } catch (Exception ex) {
            throw new ProxyAutomationException("Failed to decrypt payload", ex);
        }
    }

    public boolean isEncryptedPayload(Object value) {
        if (!(value instanceof EncryptedPayload payload)) {
            return false;
        }
        return payload.v() == 1
                && payload.iv() != null
                && payload.ciphertext() != null
                && payload.tag() != null;
    }

    private byte[] encrypt(byte[] key, byte[] iv, byte[] plaintext) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, iv));
        return cipher.doFinal(plaintext);
    }

    private byte[] decrypt(byte[] key, byte[] iv, byte[] combined) throws Exception {
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, iv));
        return cipher.doFinal(combined);
    }

    private byte[] decodeKey(String keyBase64) {
        byte[] key = Base64.getDecoder().decode(keyBase64);
        if (key.length != 32) {
            throw new ProxyAutomationException("Encryption key must be 32 bytes");
        }
        return key;
    }

    private String encodeBase64(byte[] bytes) {
        return Base64.getEncoder().encodeToString(bytes);
    }
}
