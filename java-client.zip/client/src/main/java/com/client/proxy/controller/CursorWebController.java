package com.client.proxy.controller;

import com.client.proxy.dto.ChatStreamResult;
import com.client.proxy.dto.WorkspaceFileWriteRequest;
import com.client.proxy.dto.WorkspaceMkdirRequest;
import com.client.proxy.service.CursorWebService;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.Valid;
import java.nio.charset.StandardCharsets;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.mvc.method.annotation.StreamingResponseBody;

@RestController
@RequestMapping("/api")
public class CursorWebController {

    private final CursorWebService cursorWebService;

    public CursorWebController(CursorWebService cursorWebService) {
        this.cursorWebService = cursorWebService;
    }

    @GetMapping("/session")
    public ResponseEntity<JsonNode> session() {
        return ResponseEntity.ok(cursorWebService.getSession());
    }

    @GetMapping("/models")
    public ResponseEntity<JsonNode> models() {
        return ResponseEntity.ok(cursorWebService.getModels());
    }

    @GetMapping("/workspace")
    public ResponseEntity<JsonNode> workspace() {
        return ResponseEntity.ok(cursorWebService.getWorkspace());
    }

    @GetMapping("/workspace/file")
    public ResponseEntity<JsonNode> workspaceFile(@RequestParam String path) {
        return ResponseEntity.ok(cursorWebService.getWorkspaceFile(path));
    }

    @PutMapping("/workspace/file")
    public ResponseEntity<JsonNode> putWorkspaceFile(@Valid @RequestBody WorkspaceFileWriteRequest request) {
        return ResponseEntity.ok(cursorWebService.putWorkspaceFile(request));
    }

    @DeleteMapping("/workspace/file")
    public ResponseEntity<JsonNode> deleteWorkspaceFile(
            @RequestParam String path, @RequestParam(required = false, defaultValue = "false") boolean dir) {
        return ResponseEntity.ok(cursorWebService.deleteWorkspaceFile(path, dir));
    }

    @PostMapping("/workspace/mkdir")
    public ResponseEntity<JsonNode> mkdir(@Valid @RequestBody WorkspaceMkdirRequest request) {
        return ResponseEntity.ok(cursorWebService.mkdirWorkspace(request));
    }

    @PostMapping(value = "/chat", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public ResponseEntity<StreamingResponseBody> chat(@RequestBody JsonNode body) {
        ChatStreamResult result = cursorWebService.chat(body);
        StreamingResponseBody stream = outputStream -> {
            if (result.encrypted()) {
                outputStream.write(result.encryptedSse().getBytes(StandardCharsets.UTF_8));
                return;
            }
            for (JsonNode event : result.plaintextEvents()) {
                outputStream.write(("data: " + event + "\n\n").getBytes(StandardCharsets.UTF_8));
            }
        };
        return ResponseEntity.ok()
                .contentType(MediaType.TEXT_EVENT_STREAM)
                .body(stream);
    }
}
