package com.client.proxy.dto;

import jakarta.validation.constraints.NotBlank;

public record ChatRequestDto(
        @NotBlank String model,
        @NotBlank String mode,
        String context,
        @NotBlank String prompt,
        String sessionId) {
}
