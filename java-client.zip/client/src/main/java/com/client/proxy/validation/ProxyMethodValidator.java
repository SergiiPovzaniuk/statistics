package com.client.proxy.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class ProxyMethodValidator implements ConstraintValidator<ValidProxyMethod, String> {

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null) {
            return false;
        }
        return "GET".equalsIgnoreCase(value) || "POST".equalsIgnoreCase(value);
    }
}
