package com.client.proxy.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
public record ProxyResponseDto(
        Integer status,
        Map<String, String> headers,
        Object body,
        String contentType,
        String raw,
        String resolvedUrl,
        Boolean ok,
        String error
) {
}
