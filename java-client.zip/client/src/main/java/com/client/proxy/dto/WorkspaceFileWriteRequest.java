package com.client.proxy.dto;

import jakarta.validation.constraints.NotBlank;

public record WorkspaceFileWriteRequest(@NotBlank String path, String content) {
}
