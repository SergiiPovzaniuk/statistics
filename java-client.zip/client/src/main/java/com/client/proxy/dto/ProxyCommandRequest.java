package com.client.proxy.dto;

import com.client.proxy.validation.ValidProxyMethod;
import jakarta.validation.constraints.NotBlank;
import java.util.Map;

public record ProxyCommandRequest(
        @NotBlank @ValidProxyMethod String method,
        @NotBlank String url,
        Map<String, String> headers,
        Object body
) {
}
