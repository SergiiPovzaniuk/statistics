package com.client.proxy.dto;

import com.fasterxml.jackson.databind.JsonNode;
import java.util.List;

public record ChatStreamResult(boolean encrypted, String encryptedSse, List<JsonNode> plaintextEvents) {}
