package com.client.proxy.health;

import com.client.proxy.service.PlaywrightBrowserManager;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component
public class PlaywrightHealthIndicator implements HealthIndicator {

    private final PlaywrightBrowserManager browserManager;

    public PlaywrightHealthIndicator(PlaywrightBrowserManager browserManager) {
        this.browserManager = browserManager;
    }

    @Override
    public Health health() {
        if (browserManager.isBrowserConnected()) {
            return Health.up().withDetail("browser", "connected").build();
        }
        return Health.up().withDetail("browser", "not launched yet").build();
    }
}
