package com.client.proxy.dto;

import jakarta.validation.constraints.NotBlank;

public record WorkspaceMkdirRequest(@NotBlank String path) {
}
