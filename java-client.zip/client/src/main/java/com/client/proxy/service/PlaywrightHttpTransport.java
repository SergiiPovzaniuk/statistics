package com.client.proxy.service;

import com.client.proxy.config.CursorWebProperties;
import com.client.proxy.config.PlaywrightProperties;
import com.client.proxy.dto.HttpResult;
import com.client.proxy.exception.ProxyAutomationException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import java.util.HashMap;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class PlaywrightHttpTransport {

    private final PlaywrightBrowserManager browserManager;
    private final PlaywrightProperties playwrightProperties;
    private final CursorWebProperties cursorWebProperties;
    private final ObjectMapper objectMapper;

    public PlaywrightHttpTransport(
            PlaywrightBrowserManager browserManager,
            PlaywrightProperties playwrightProperties,
            CursorWebProperties cursorWebProperties,
            ObjectMapper objectMapper) {
        this.browserManager = browserManager;
        this.playwrightProperties = playwrightProperties;
        this.cursorWebProperties = cursorWebProperties;
        this.objectMapper = objectMapper;
    }

    public HttpResult executeCursor(
            String operation, String path, boolean dir, Object body, boolean stream) {
        Browser browser = browserManager.getBrowser();
        try (BrowserContext context = browser.newContext();
                var page = context.newPage()) {
            page.navigate(
                    playwrightProperties.getProxyUi().getUrl(),
                    new com.microsoft.playwright.Page.NavigateOptions()
                            .setTimeout(playwrightProperties.getTimeout().getNavigationMs())
                            .setWaitUntil(com.microsoft.playwright.options.WaitUntilState.DOMCONTENTLOADED));

            page.locator("[data-testid='tab-cursor']").click();
            page.locator("[data-testid='cursor-user']").fill(cursorWebProperties.getUsername());
            page.locator("[data-testid='cursor-pass']").fill(cursorWebProperties.getPassword());
            page.locator("[data-testid='cursor-op']").selectOption(operation);
            page.evaluate("document.getElementById('cursor-op').dispatchEvent(new Event('change'))");

            if (path != null && !path.isBlank()) {
                page.locator("[data-testid='cursor-path']").fill(path);
            }
            if (dir) {
                page.locator("[data-testid='cursor-dir']").check();
            }
            if (body != null) {
                page.locator("[data-testid='cursor-body']").waitFor();
                page.locator("[data-testid='cursor-body']").fill(toJson(body));
            }

            String initialOutput = page.locator("[data-testid='response-output']").innerText();
            page.locator("[data-testid='cursor-submit']").click();
            waitForResponse(page, initialOutput, stream);

            String statusText = page.locator("[data-testid='response-status']").innerText().trim();
            String outputText = page.locator("[data-testid='response-output']").innerText().trim();

            if (statusText.startsWith("err") || outputText.contains("\"error\"")) {
                throw new ProxyAutomationException(extractError(outputText, statusText));
            }

            if (stream) {
                return new HttpResult(200, Map.of(), null, outputText, true);
            }

            JsonNode parsed = objectMapper.readTree(outputText);
            return new HttpResult(200, Map.of(), parsed, outputText, true);
        } catch (ProxyAutomationException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ProxyAutomationException("Failed to automate Cursor UI", ex);
        }
    }

    private void waitForResponse(com.microsoft.playwright.Page page, String initialOutput, boolean stream) {
        int timeoutMs = playwrightProperties.getTimeout().getResponseMs();
        long deadline = System.currentTimeMillis() + timeoutMs;
        String lastOutput = initialOutput;
        int stableCount = 0;

        while (System.currentTimeMillis() < deadline) {
            String status = page.locator("[data-testid='response-status']").innerText().trim();
            String output = page.locator("[data-testid='response-output']").innerText().trim();

            if (stream) {
                if (status.startsWith("err")) {
                    return;
                }
                if (status.contains("stream") && hasStreamContent(output) && !output.equals(initialOutput)) {
                    if (output.equals(lastOutput)) {
                        stableCount++;
                        if (stableCount >= 30) {
                            return;
                        }
                    } else {
                        stableCount = 0;
                        lastOutput = output;
                    }
                }
            } else if (!"...".equals(status) && !output.equals(initialOutput)) {
                return;
            }

            page.waitForTimeout(200);
        }

        if (stream && !lastOutput.equals(initialOutput)) {
            return;
        }

        throw new ProxyAutomationException("Timed out waiting for Cursor UI response");
    }

    private boolean hasStreamContent(String output) {
        return output.contains("data:")
                || output.contains("\"v\":")
                || output.contains("\"type\":");
    }

    private String extractError(String outputText, String statusText) {
        try {
            JsonNode node = objectMapper.readTree(outputText);
            if (node.has("error")) {
                return node.get("error").asText();
            }
        } catch (Exception ignored) {
        }
        return statusText + ": " + outputText;
    }

    private String toJson(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (Exception ex) {
            throw new ProxyAutomationException("Failed to serialize JSON", ex);
        }
    }
}
