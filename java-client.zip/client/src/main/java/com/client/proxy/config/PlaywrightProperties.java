package com.client.proxy.config;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.validation.annotation.Validated;

@Validated
@ConfigurationProperties(prefix = "playwright")
public class PlaywrightProperties {

    @Valid
    @NotNull
    private Chrome chrome = new Chrome();

    private boolean headless = true;

    @Valid
    @NotNull
    private ProxyUi proxyUi = new ProxyUi();

    @Valid
    @NotNull
    private Timeout timeout = new Timeout();

    public Chrome getChrome() {
        return chrome;
    }

    public void setChrome(Chrome chrome) {
        this.chrome = chrome;
    }

    public boolean isHeadless() {
        return headless;
    }

    public void setHeadless(boolean headless) {
        this.headless = headless;
    }

    public ProxyUi getProxyUi() {
        return proxyUi;
    }

    public void setProxyUi(ProxyUi proxyUi) {
        this.proxyUi = proxyUi;
    }

    public Timeout getTimeout() {
        return timeout;
    }

    public void setTimeout(Timeout timeout) {
        this.timeout = timeout;
    }

    public static class Chrome {

        @NotBlank
        private String executablePath = "C:/Program Files/Google/Chrome/Application/chrome.exe";

        public String getExecutablePath() {
            return executablePath;
        }

        public void setExecutablePath(String executablePath) {
            this.executablePath = executablePath;
        }
    }

    public static class ProxyUi {

        @NotBlank
        private String url = "http://46.174.75.130:5554/";

        public String getUrl() {
            return url;
        }

        public void setUrl(String url) {
            this.url = url;
        }
    }

    public static class Timeout {

        private int navigationMs = 30000;
        private int responseMs = 60000;

        public int getNavigationMs() {
            return navigationMs;
        }

        public void setNavigationMs(int navigationMs) {
            this.navigationMs = navigationMs;
        }

        public int getResponseMs() {
            return responseMs;
        }

        public void setResponseMs(int responseMs) {
            this.responseMs = responseMs;
        }
    }
}
