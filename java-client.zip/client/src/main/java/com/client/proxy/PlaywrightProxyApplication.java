package com.client.proxy;

import com.client.proxy.config.CursorWebProperties;
import com.client.proxy.config.PlaywrightProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
@EnableConfigurationProperties({PlaywrightProperties.class, CursorWebProperties.class})
public class PlaywrightProxyApplication {

    public static void main(String[] args) {
        SpringApplication.run(PlaywrightProxyApplication.class, args);
    }
}
