package com.client.proxy.exception;

import com.client.proxy.dto.ProxyResponseDto;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ProxyResponseDto> handleValidation(MethodArgumentNotValidException ex) {
        FieldError fieldError = ex.getBindingResult().getFieldError();
        String message = fieldError != null ? fieldError.getDefaultMessage() : "Invalid request";
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(new ProxyResponseDto(null, null, null, null, null, null, false, message));
    }

    @ExceptionHandler(BrowserNotReadyException.class)
    public ResponseEntity<ProxyResponseDto> handleBrowserNotReady(BrowserNotReadyException ex) {
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                .body(new ProxyResponseDto(null, null, null, null, null, null, false, ex.getMessage()));
    }

    @ExceptionHandler(ProxyAutomationException.class)
    public ResponseEntity<ProxyResponseDto> handleProxyAutomation(ProxyAutomationException ex) {
        return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                .body(new ProxyResponseDto(null, null, null, null, null, null, false, ex.getMessage()));
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, Object>> handleIllegalArgument(IllegalArgumentException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                .body(Map.of("ok", false, "error", ex.getMessage() != null ? ex.getMessage() : "Invalid request"));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGeneric(Exception ex) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                .body(Map.of("ok", false, "error", ex.getMessage() != null ? ex.getMessage() : "Unexpected error"));
    }
}
