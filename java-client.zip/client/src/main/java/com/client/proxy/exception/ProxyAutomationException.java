package com.client.proxy.exception;

public class ProxyAutomationException extends RuntimeException {

    public ProxyAutomationException(String message) {
        super(message);
    }

    public ProxyAutomationException(String message, Throwable cause) {
        super(message, cause);
    }
}
