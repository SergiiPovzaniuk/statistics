package com.client.proxy.service;

import com.client.proxy.crypto.TransportCryptoService;
import com.client.proxy.dto.ChatStreamResult;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@Tag("integration")
@EnabledIfSystemProperty(named = "integration.tests", matches = "true")
class ModelChatValidationTest {

    @Autowired
    private CursorWebService cursorWebService;

    @Autowired
    private TransportCryptoService cryptoService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void chatWithComposerModelThroughClient() {
        JsonNode session = cursorWebService.getSession();
        String key = session.get("encryptionKey").asText();

        ObjectNode request = objectMapper.createObjectNode();
        request.put("model", "composer-2.5");
        request.put("mode", "ask");
        request.put("context", "");
        request.put("prompt", "Reply with exactly one word: validated");

        JsonNode body = objectMapper.valueToTree(cryptoService.encryptJson(key, request));
        ChatStreamResult result = cursorWebService.chat(body);

        assertTrue(result.encrypted());
        assertNotNull(result.encryptedSse());
        assertFalse(result.encryptedSse().isBlank());
        assertTrue(result.encryptedSse().contains("data:"));

        String decrypted = decryptEvents(key, result.encryptedSse());
        System.out.println("composer-2.5 response: " + decrypted);
        assertTrue(decrypted.contains("validated") || decrypted.contains("Validated") || decrypted.length() > 3);
    }

    private String decryptEvents(String key, String sse) {
        StringBuilder text = new StringBuilder();
        for (String line : sse.split("\n")) {
            if (!line.startsWith("data:")) continue;
            try {
                JsonNode payload = objectMapper.readTree(line.substring(5).trim());
                JsonNode event = objectMapper.valueToTree(
                        cryptoService.decryptJson(key, objectMapper.convertValue(payload, com.client.proxy.dto.EncryptedPayload.class), JsonNode.class));
                if (event.has("content")) text.append(event.get("content").asText());
                if ("done".equals(event.path("type").asText())) break;
                if ("error".equals(event.path("type").asText())) throw new AssertionError(event.get("message").asText());
            } catch (AssertionError ex) {
                throw ex;
            } catch (Exception ignored) {
            }
        }
        return text.toString();
    }
}
