package com.client.proxy.service;

import com.client.proxy.crypto.TransportCryptoService;
import com.client.proxy.dto.ChatStreamResult;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledIfSystemProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

@SpringBootTest
@Tag("integration")
@EnabledIfSystemProperty(named = "integration.tests", matches = "true")
class CursorWebIntegrationTest {

    @Autowired
    private CursorWebService cursorWebService;

    @Autowired
    private TransportCryptoService cryptoService;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    void loadsSessionAndModels() {
        JsonNode session = cursorWebService.getSession();
        assertNotNull(session);
        assertTrue(session.has("encryptionKey"));

        JsonNode models = cursorWebService.getModels();
        assertNotNull(models);
        assertTrue(models.has("models"));
    }

    @Test
    void encryptedChatPassthrough() {
        JsonNode session = cursorWebService.getSession();
        String key = session.get("encryptionKey").asText();

        ObjectNode request = objectMapper.createObjectNode();
        request.put("model", "default");
        request.put("mode", "ask");
        request.put("context", "");
        request.put("prompt", "Say hi in one word");

        JsonNode body = objectMapper.valueToTree(cryptoService.encryptJson(key, request));
        ChatStreamResult result = cursorWebService.chat(body);

        assertTrue(result.encrypted());
        assertNotNull(result.encryptedSse());
        assertFalse(result.encryptedSse().isBlank());
        assertTrue(result.encryptedSse().contains("data:"));
    }
}
