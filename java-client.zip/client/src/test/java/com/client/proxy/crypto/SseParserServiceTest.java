package com.client.proxy.crypto;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class SseParserServiceTest {

    private final SseParserService parser =
            new SseParserService(new ObjectMapper(), new TransportCryptoService(new ObjectMapper()));

    @Test
    void formatEncryptedSseFromJsonLines() {
        String raw =
                """
                {"v":1,"iv":"a","ciphertext":"b","tag":"c"}
                {"v":1,"iv":"d","ciphertext":"e","tag":"f"}
                """;
        String sse = parser.formatEncryptedSse(raw);
        assertTrue(sse.contains("data: {\"v\":1,\"iv\":\"a\",\"ciphertext\":\"b\",\"tag\":\"c\"}"));
        assertTrue(sse.contains("data: {\"v\":1,\"iv\":\"d\",\"ciphertext\":\"e\",\"tag\":\"f\"}"));
    }

    @Test
    void extractEncryptedLinesIgnoresPlaintext() {
        String raw =
                """
                {"type":"token","content":"hi"}
                {"v":1,"iv":"a","ciphertext":"b","tag":"c"}
                """;
        assertEquals(1, parser.extractEncryptedLines(raw).size());
    }
}
