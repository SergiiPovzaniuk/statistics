package com.client.proxy.controller;

import com.client.proxy.dto.ChatStreamResult;
import com.client.proxy.exception.GlobalExceptionHandler;
import com.client.proxy.service.CursorWebService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Import;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(controllers = CursorWebController.class)
@Import(GlobalExceptionHandler.class)
class CursorWebControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private CursorWebService cursorWebService;

    @Test
    void sessionReturnsEncryptionKey() throws Exception {
        ObjectNode body = objectMapper.createObjectNode();
        body.put("encryptionKey", "abc=");
        body.put("workspacePath", "C:\\project");
        when(cursorWebService.getSession()).thenReturn(body);

        mockMvc.perform(get("/api/session"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.encryptionKey").value("abc="));
    }

    @Test
    void chatRejectsMissingPrompt() throws Exception {
        when(cursorWebService.chat(any())).thenThrow(new IllegalArgumentException("prompt is required"));

        mockMvc.perform(post("/api/chat")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "model": "default",
                                  "mode": "ask",
                                  "context": ""
                                }
                                """))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.ok").value(false));
    }

    @Test
    void chatStreamsEncryptedSse() throws Exception {
        when(cursorWebService.chat(any()))
                .thenReturn(new ChatStreamResult(true, "data: {\"v\":1,\"iv\":\"a\",\"ciphertext\":\"b\",\"tag\":\"c\"}\n\n", null));

        mockMvc.perform(post("/api/chat")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("""
                                {
                                  "v": 1,
                                  "iv": "a",
                                  "ciphertext": "b",
                                  "tag": "c"
                                }
                                """))
                .andExpect(status().isOk())
                .andExpect(content().string("data: {\"v\":1,\"iv\":\"a\",\"ciphertext\":\"b\",\"tag\":\"c\"}\n\n"));
    }

    @Test
    void modelsReturnsList() throws Exception {
        ObjectNode body = objectMapper.createObjectNode();
        ArrayNode models = body.putArray("models");
        ObjectNode model = models.addObject();
        model.put("id", "default");
        model.put("label", "Auto");
        when(cursorWebService.getModels()).thenReturn(body);

        mockMvc.perform(get("/api/models"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.models[0].id").value("default"));
    }
}
