package com.client.proxy.crypto;

import com.client.proxy.dto.EncryptedPayload;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

class TransportCryptoServiceTest {

    @Test
    void roundTripChatRequest() throws Exception {
        TransportCryptoService crypto = new TransportCryptoService(new ObjectMapper());
        String key = "Bo6yeObKlxPLzm/GV41ZAhHfittXvVYz1D84NtHE61A=";
        ObjectNode request = new ObjectMapper().createObjectNode();
        request.put("model", "default");
        request.put("mode", "ask");
        request.put("context", "");
        request.put("prompt", "OK");

        EncryptedPayload encrypted = crypto.encryptJson(key, request);
        ObjectNode decrypted = crypto.decryptJson(key, encrypted, ObjectNode.class);
        assertTrue(decrypted.get("prompt").asText().equals("OK"));
    }
}
