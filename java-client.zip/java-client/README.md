# Copilot Desktop

Standalone JavaFX client with local filesystem access. Front-end of the four-service stack.

## Architecture

```
java-client  →  client :8080  →  http_manager :5554  →  cursor_api :3000
```

Agent mode applies `file_op` SSE events to your **local** workspace folder.

## Requirements

- JDK 21+
- Maven 3.9+
- **client** service running on `:8080` (see [client/STACK.md](../client/STACK.md))

## Run

```bash
mvn javafx:run
```

## Connect

Defaults: `http://localhost:8080`, user `cursor`, pass `web123`.

1. Start **client** service first (`mvn spring-boot:run` in `client/`)
2. **Connect** — defaults work out of the box
3. **Open Folder** — pick local workspace
4. Use **Agent** / **Ask** modes; `file_op` events apply to local disk

## API

Uses `HttpProxyApiClient` — encrypted chat per [CURSOR_WEB_API.md](../client/CURSOR_WEB_API.md):

- `GET /api/session`
- `GET /api/models`
- `POST /api/chat` (encrypted body + encrypted SSE)
