package com.copilot.desktop.ui.editor;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.fxmisc.richtext.model.StyleSpans;
import org.junit.jupiter.api.Test;

class SyntaxHighlighterTest {
  @Test
  void highlightsJavaKeywords() {
    StyleSpans<?> spans = SyntaxHighlighter.highlight("public class App { }", EditorLanguage.JAVA);
    assertNotNull(spans);
  }

  @Test
  void highlightsJavaScriptKeywords() {
    StyleSpans<?> spans = SyntaxHighlighter.highlight("const x = () => null;", EditorLanguage.JAVASCRIPT);
    assertNotNull(spans);
  }
}
