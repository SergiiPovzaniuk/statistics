package com.copilot.desktop.ui.icons;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class FileKindTest {
  @Test
  void detectsJavaAndJs() {
    assertEquals(FileKind.JAVA, FileKind.from("src/App.java", false));
    assertEquals(FileKind.JAVASCRIPT, FileKind.from("index.js", false));
    assertEquals(FileKind.FOLDER, FileKind.from("src/", true));
    assertEquals(FileKind.MAVEN, FileKind.from("pom.xml", false));
  }
}
