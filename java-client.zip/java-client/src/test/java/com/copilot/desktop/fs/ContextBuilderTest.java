package com.copilot.desktop.fs;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import org.junit.jupiter.api.Test;

class ContextBuilderTest {
  @Test
  void includesAttachmentsAndMentions() {
    var ctx =
        ContextBuilder.build(
            "demo",
            List.of("a.txt", "b.txt"),
            null,
            null,
            List.of(new ContextBuilder.MentionFile("a.txt", "mention-content")),
            List.of(new ContextBuilder.AttachmentFile("b.txt", "attached-content")),
            "");
    assertTrue(ctx.contains("Attached files (user-selected):"));
    assertTrue(ctx.contains("attached-content"));
    assertTrue(ctx.contains("mention-content"));
  }
}
