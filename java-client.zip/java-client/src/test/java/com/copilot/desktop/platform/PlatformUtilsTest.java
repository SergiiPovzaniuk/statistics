package com.copilot.desktop.platform;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.OS;

class PlatformUtilsTest {
  @Test
  @EnabledOnOs(OS.WINDOWS)
  void windowsPathCompareIsCaseInsensitive() {
    var root = Path.of("C:\\Workspace");
    assertTrue(PlatformUtils.isSameOrChildPath(root, Path.of("C:\\Workspace\\src\\App.java")));
    assertTrue(PlatformUtils.isSameOrChildPath(root, Path.of("c:\\workspace\\src\\App.java")));
    assertFalse(PlatformUtils.isSameOrChildPath(root, Path.of("C:\\Other\\file.txt")));
  }
}
