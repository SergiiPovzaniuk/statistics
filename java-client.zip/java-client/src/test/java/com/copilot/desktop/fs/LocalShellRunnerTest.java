package com.copilot.desktop.fs;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

class LocalShellRunnerTest {
  @Test
  void echoCommand(@TempDir Path dir) throws Exception {
    var workspace = new LocalWorkspace();
    workspace.open(dir);
    var runner = new LocalShellRunner();
    var result =
        runner.run(
            workspace,
            System.getProperty("os.name").toLowerCase().contains("win") ? "echo hello" : "echo hello",
            null);
    assertEquals(0, result.exitCode());
    assertTrue(result.output().contains("hello"));
  }
}
