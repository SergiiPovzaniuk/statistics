package com.copilot.desktop.fs;

import com.copilot.desktop.platform.PlatformUtils;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

public final class LocalWorkspace {
  private static final Set<String> SKIP =
      Set.of(
          "node_modules",
          ".git",
          ".next",
          "dist",
          "build",
          "target",
          ".turbo",
          "coverage",
          "$RECYCLE.BIN",
          "System Volume Information",
          "Thumbs.db",
          "desktop.ini");

  private Path root;

  public void open(Path folder) throws IOException {
    if (!Files.isDirectory(folder)) {
      throw new IOException("Not a directory: " + folder);
    }
    root = folder.toAbsolutePath().normalize();
  }

  public boolean isOpen() {
    return root != null;
  }

  public Path getRoot() {
    return root;
  }

  public String folderName() {
    return root == null ? null : root.getFileName().toString();
  }

  public List<String> listPaths() throws IOException {
    if (root == null) return List.of();
    var paths = new ArrayList<String>();
    Files.walkFileTree(
        root,
        new SimpleFileVisitor<>() {
          @Override
          public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) {
            if (!dir.equals(root) && shouldSkip(dir.getFileName().toString())) {
              return FileVisitResult.SKIP_SUBTREE;
            }
            if (!dir.equals(root)) {
              paths.add(root.relativize(dir).toString().replace('\\', '/') + "/");
            }
            return FileVisitResult.CONTINUE;
          }

          @Override
          public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
            paths.add(root.relativize(file).toString().replace('\\', '/'));
            return FileVisitResult.CONTINUE;
          }
        });
    paths.sort(Comparator.naturalOrder());
    return paths;
  }

  public String readFile(String relPath) throws IOException {
    return Files.readString(resolve(relPath), StandardCharsets.UTF_8);
  }

  public void writeFile(String relPath, String content) throws IOException {
    var target = resolve(relPath);
    var parent = target.getParent();
    if (parent != null) {
      Files.createDirectories(parent);
    }
    Files.writeString(target, content, StandardCharsets.UTF_8);
  }

  public void deleteEntry(String relPath, boolean isDir) throws IOException {
    var target = resolve(relPath);
    if (isDir) {
      deleteDir(target);
    } else {
      Files.deleteIfExists(target);
    }
  }

  public void applyFileOp(String operation, String relPath, String content) throws IOException {
    switch (operation) {
      case "create", "update" -> writeFile(relPath, content == null ? "" : content);
      case "delete" -> deleteEntry(relPath, relPath.endsWith("/"));
      default -> throw new IOException("Unknown operation: " + operation);
    }
  }

  private Path resolve(String relPath) throws IOException {
    if (root == null) throw new IOException("No workspace open");
    var cleaned = relPath.replace('\\', '/').replaceAll("^/+", "").replaceAll("/+$", "");
    var resolved = root.resolve(cleaned).normalize();
    if (!PlatformUtils.isSameOrChildPath(root, resolved)) {
      throw new IOException("Path outside workspace");
    }
    return resolved;
  }

  private static boolean shouldSkip(String name) {
    if (name == null || name.isBlank()) return false;
    for (var s : SKIP) {
      if (s.equalsIgnoreCase(name)) return true;
    }
    return false;
  }

  private void deleteDir(Path dir) throws IOException {
    if (!Files.exists(dir)) return;
    Files.walk(dir)
        .sorted(Comparator.reverseOrder())
        .forEach(
            path -> {
              try {
                Files.deleteIfExists(path);
              } catch (IOException e) {
                throw new RuntimeException(e);
              }
            });
  }
}
