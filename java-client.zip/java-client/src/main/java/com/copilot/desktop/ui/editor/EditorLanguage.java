package com.copilot.desktop.ui.editor;

public enum EditorLanguage {
  JAVA,
  JAVASCRIPT,
  PLAIN;

  public static EditorLanguage fromPath(String path) {
    if (path == null) return PLAIN;
    var lower = path.toLowerCase();
    if (lower.endsWith(".java")) return JAVA;
    if (lower.endsWith(".js")
        || lower.endsWith(".jsx")
        || lower.endsWith(".mjs")
        || lower.endsWith(".cjs")) return JAVASCRIPT;
    return PLAIN;
  }
}
