package com.copilot.desktop;

import com.copilot.desktop.platform.PlatformUtils;
import javafx.application.Application;

public final class Main {
  public static void main(String[] args) {
    PlatformUtils.configureRuntime();
    Application.launch(CopilotApp.class, args);
  }
}
