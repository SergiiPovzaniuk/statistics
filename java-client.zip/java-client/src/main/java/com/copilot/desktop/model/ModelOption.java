package com.copilot.desktop.model;

public record ModelOption(String id, String label, Integer contextLimit) {}
