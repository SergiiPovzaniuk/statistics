package com.copilot.desktop.model;

public record EncryptedPayload(int v, String iv, String ciphertext, String tag) {}
