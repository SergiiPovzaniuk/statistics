package com.copilot.desktop.fs;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public final class ContextBuilder {
  private static final Pattern MENTION = Pattern.compile("@([\\w./\\\\-]+)");
  private static final int MAX_PATHS = 50;
  private static final int MAX_FILE_CHARS = 12000;

  private ContextBuilder() {}

  public static List<String> parseMentions(String prompt) {
    var matcher = MENTION.matcher(prompt);
    var paths = new ArrayList<String>();
    while (matcher.find()) {
      paths.add(matcher.group(1));
    }
    return paths;
  }

  public static String build(
      String folderName,
      List<String> paths,
      String activePath,
      String activeContent,
      List<MentionFile> mentions,
      List<AttachmentFile> attachments,
      String extraContext) {
    var parts = new ArrayList<String>();
    if (folderName != null && !folderName.isBlank()) {
      parts.add("Local workspace folder: " + folderName);
    }
    if (attachments != null && !attachments.isEmpty()) {
      parts.add("Attached files (user-selected):");
      for (var file : attachments) {
        parts.add("## " + file.path() + "\n```\n" + truncate(file.content()) + "\n```");
      }
    }
    if (paths != null && !paths.isEmpty()) {
      var listed = paths.stream().limit(MAX_PATHS).toList();
      var suffix = paths.size() > MAX_PATHS ? "\n... and " + (paths.size() - MAX_PATHS) + " more files" : "";
      parts.add("File paths (" + paths.size() + " total):\n" + String.join("\n", listed) + suffix);
    }
    if (activePath != null && activeContent != null) {
      parts.add("Active file: " + activePath + "\n```\n" + truncate(activeContent) + "\n```");
    }
    for (var file : mentions) {
      parts.add("## " + file.path() + "\n```\n" + truncate(file.content()) + "\n```");
    }
    if (extraContext != null && !extraContext.isBlank()) {
      parts.add(extraContext.trim());
    }
    return String.join("\n\n", parts);
  }

  private static String truncate(String content) {
    if (content.length() <= MAX_FILE_CHARS) return content;
    return content.substring(0, MAX_FILE_CHARS) + "\n... [truncated]";
  }

  public record MentionFile(String path, String content) {}

  public record AttachmentFile(String path, String content) {}
}
