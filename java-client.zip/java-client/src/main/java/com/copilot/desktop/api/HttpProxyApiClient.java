package com.copilot.desktop.api;

import com.copilot.desktop.config.AppSettings;
import com.copilot.desktop.model.ChatRequest;
import com.copilot.desktop.model.EncryptedPayload;
import com.copilot.desktop.model.ModelOption;
import com.copilot.desktop.model.SessionInfo;
import com.copilot.desktop.model.SseEvent;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.Base64;
import java.util.List;
import java.util.function.Consumer;

public final class HttpProxyApiClient implements ProxyApiClient {
  private static final Gson GSON = new Gson();
  private static final Duration TIMEOUT = Duration.ofSeconds(120);
  private static final Duration CHAT_TIMEOUT = Duration.ofMinutes(5);

  private final HttpClient http = HttpClient.newBuilder().connectTimeout(TIMEOUT).build();
  private AppSettings settings = AppSettings.defaults();
  private String encryptionKey;

  @Override
  public void configure(AppSettings settings) {
    this.settings = settings;
    this.encryptionKey = null;
  }

  @Override
  public SessionInfo getSession() throws Exception {
    var body = getJson("/api/session");
    if (body.has("error")) {
      throw new IllegalStateException(body.get("error").getAsString());
    }
    var session = GSON.fromJson(body, SessionInfo.class);
    encryptionKey = session.encryptionKey();
    return session;
  }

  @Override
  public List<ModelOption> getModels() throws Exception {
    var body = getJson("/api/models");
    if (body.has("error")) {
      throw new IllegalStateException(body.get("error").getAsString());
    }
    var models = body.getAsJsonArray("models");
    return GSON.fromJson(models, new TypeToken<List<ModelOption>>() {}.getType());
  }

  @Override
  public void streamChat(ChatRequest request, Consumer<SseEvent> onEvent) throws Exception {
    if (encryptionKey == null || encryptionKey.isBlank()) {
      getSession();
    }
    var encrypted = TransportCrypto.encrypt(encryptionKey, request);
    var req =
        HttpRequest.newBuilder()
            .uri(URI.create(settings.normalizedBaseUrl() + "/api/chat"))
            .timeout(CHAT_TIMEOUT)
            .header("Authorization", basicAuth())
            .header("Content-Type", "application/json")
            .header("Accept", "text/event-stream")
            .POST(HttpRequest.BodyPublishers.ofString(GSON.toJson(encrypted)))
            .build();

    var response = http.send(req, HttpResponse.BodyHandlers.ofInputStream());
    if (response.statusCode() >= 400) {
      var err = new String(response.body().readAllBytes(), StandardCharsets.UTF_8);
      throw new IllegalStateException("Chat failed (" + response.statusCode() + "): " + err);
    }

    try (var reader = new BufferedReader(new InputStreamReader(response.body(), StandardCharsets.UTF_8))) {
      String line;
      while ((line = reader.readLine()) != null) {
        if (!line.startsWith("data:")) continue;
        var data = line.substring(5).trim();
        if (data.isEmpty()) continue;
        var payload = GSON.fromJson(data, EncryptedPayload.class);
        var event = TransportCrypto.decrypt(encryptionKey, payload, SseEvent.class);
        onEvent.accept(event);
        if ("done".equals(event.type()) || "error".equals(event.type())) break;
      }
    }
  }

  private JsonObject getJson(String path) throws Exception {
    var req =
        HttpRequest.newBuilder()
            .uri(URI.create(settings.normalizedBaseUrl() + path))
            .timeout(TIMEOUT)
            .header("Authorization", basicAuth())
            .GET()
            .build();
    var response = http.send(req, HttpResponse.BodyHandlers.ofString());
    if (response.statusCode() == 401) {
      throw new IllegalStateException("Invalid credentials");
    }
    if (response.statusCode() >= 400) {
      throw new IllegalStateException("Request failed (" + response.statusCode() + ")");
    }
    return GSON.fromJson(response.body(), JsonObject.class);
  }

  private String basicAuth() {
    var token =
        Base64.getEncoder()
            .encodeToString(
                (settings.username() + ":" + settings.password()).getBytes(StandardCharsets.UTF_8));
    return "Basic " + token;
  }
}
