package com.copilot.desktop.ui;

import com.copilot.desktop.config.AppSettings;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Window;

public final class ConnectDialog {
  private final Window owner;
  private final AppSettings initial;

  public ConnectDialog(Window owner, AppSettings initial) {
    this.owner = owner;
    this.initial = initial;
  }

  public java.util.Optional<AppSettings> showAndWait() {
    var dialog = new Dialog<AppSettings>();
    dialog.setTitle("Connect to API Proxy");
    dialog.setHeaderText("Enter proxy URL and credentials");
    dialog.initOwner(owner);
    dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);

    var proxy = new TextField(initial.normalizedBaseUrl());
    var user = new TextField(initial.username());
    var pass = new PasswordField();
    pass.setText(initial.password());

    var grid = new GridPane();
    grid.setHgap(10);
    grid.setVgap(10);
    grid.setPadding(new Insets(16));
    grid.add(new Label("Proxy URL"), 0, 0);
    grid.add(proxy, 1, 0);
    grid.add(new Label("Username"), 0, 1);
    grid.add(user, 1, 1);
    grid.add(new Label("Password"), 0, 2);
    grid.add(pass, 1, 2);
    dialog.getDialogPane().setContent(grid);

    var ok = (Button) dialog.getDialogPane().lookupButton(ButtonType.OK);
    ok.setDefaultButton(true);
    ok.addEventFilter(
        javafx.event.ActionEvent.ACTION,
        e -> {
          if (proxy.getText().isBlank() || user.getText().isBlank()) {
            e.consume();
          }
        });

    dialog.setResultConverter(
        button -> {
          if (button != ButtonType.OK) return null;
          return new AppSettings(proxy.getText().trim(), user.getText().trim(), pass.getText());
        });

    return dialog.showAndWait();
  }
}
