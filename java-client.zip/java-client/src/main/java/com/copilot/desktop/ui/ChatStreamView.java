package com.copilot.desktop.ui;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TitledPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

public final class ChatStreamView {
  private final VBox messages = new VBox(10);
  private final ScrollPane scroll = new ScrollPane(messages);
  private TextFlow assistantFlow;
  private VBox assistantBox;
  private TitledPane thinkingPane;
  private Text thinkingText;
  private final java.util.Map<String, ToolBlock> toolBlocks = new java.util.HashMap<>();

  public ChatStreamView() {
    messages.getStyleClass().add("chat-messages");
    messages.setFillWidth(true);
    scroll.setFitToWidth(true);
    scroll.getStyleClass().add("chat-scroll");
    scroll.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
  }

  public ScrollPane getNode() {
    return scroll;
  }

  public void clear() {
    messages.getChildren().clear();
    assistantFlow = null;
    assistantBox = null;
    thinkingPane = null;
    thinkingText = null;
    toolBlocks.clear();
  }

  public void addUserMessage(String text) {
    finishAssistantTurn();
    var bubble = new VBox(new Label(text));
    bubble.getStyleClass().add("chat-user");
    bubble.setMaxWidth(Double.MAX_VALUE);
    messages.getChildren().add(bubble);
    scrollToBottom();
  }

  public void beginAssistantTurn() {
    finishAssistantTurn();
    ensureAssistantBox();
  }

  public void appendToken(String token) {
    if (token == null || token.isEmpty()) return;
    ensureAssistantBox();
    assistantFlow.getChildren().add(new Text(token));
    scrollToBottom();
  }

  public void appendThinking(String chunk) {
    if (chunk == null || chunk.isEmpty()) return;
    if (thinkingPane == null) {
      thinkingText = new Text();
      thinkingText.getStyleClass().add("chat-thinking-text");
      var body = new VBox(thinkingText);
      body.getStyleClass().add("chat-thinking-body");
      thinkingPane = new TitledPane("Thinking", body);
      thinkingPane.getStyleClass().add("chat-thinking");
      thinkingPane.setExpanded(true);
      thinkingPane.setMaxWidth(Double.MAX_VALUE);
      messages.getChildren().add(messages.getChildren().size() - (assistantBox == null ? 0 : 1), thinkingPane);
    }
    thinkingText.setText(thinkingText.getText() + chunk);
    scrollToBottom();
  }

  public void updateTool(String name, String status, String summary) {
    if (name == null || name.isBlank()) return;
    var block = toolBlocks.get(name);
    if (block == null) {
      block = new ToolBlock(name);
      toolBlocks.put(name, block);
      var insertAt = messages.getChildren().size() - (assistantBox == null ? 0 : 1);
      if (insertAt < 0) insertAt = 0;
      messages.getChildren().add(insertAt, block.root);
    }
    block.update(status, summary);
    scrollToBottom();
  }

  public void showFileOp(String operation, String path) {
    var label = switch (operation) {
      case "create" -> "Create";
      case "update" -> "Edit";
      case "delete" -> "Delete";
      default -> operation;
    };
    updateTool(label + " " + path, "done", path);
  }

  public void showReadOp(String path, String status, String summary) {
    updateTool("Read " + path, status, summary);
  }

  public void showShellOp(String command, String status, String summary) {
    updateTool("Shell " + command, status, summary);
  }

  public void collapseThinking() {
    if (thinkingPane != null) thinkingPane.setExpanded(false);
  }

  private void ensureAssistantBox() {
    if (assistantFlow != null) return;
    assistantFlow = new TextFlow();
    assistantFlow.getStyleClass().add("chat-assistant-text");
    assistantBox = new VBox(assistantFlow);
    assistantBox.getStyleClass().add("chat-assistant");
    assistantBox.setMaxWidth(Double.MAX_VALUE);
    messages.getChildren().add(assistantBox);
  }

  private void finishAssistantTurn() {
    collapseThinking();
    assistantFlow = null;
    assistantBox = null;
    thinkingPane = null;
    thinkingText = null;
    toolBlocks.clear();
  }

  private void scrollToBottom() {
    scroll.layout();
    scroll.setVvalue(1.0);
  }

  private static final class ToolBlock {
    private final VBox root;
    private final Label title;
    private final Label status;
    private final Label summary;

    private ToolBlock(String name) {
      title = new Label(name);
      title.getStyleClass().add("chat-tool-name");
      status = new Label();
      status.getStyleClass().add("chat-tool-status");
      summary = new Label();
      summary.getStyleClass().add("chat-tool-summary");
      summary.setWrapText(true);
      summary.setMaxWidth(Double.MAX_VALUE);
      var header = new HBox(8, icon("⚙"), title, spacer(), status);
      header.setAlignment(Pos.CENTER_LEFT);
      root = new VBox(4, header, summary);
      root.getStyleClass().add("chat-tool");
      VBox.setMargin(root, new Insets(0, 0, 0, 0));
    }

    private void update(String st, String sum) {
      if (st != null && !st.isBlank()) {
        status.setText(st);
        status.getStyleClass().removeAll("running", "done", "error");
        status.getStyleClass().add(mapStatus(st));
      }
      if (sum != null && !sum.isBlank()) summary.setText(sum);
    }

    private static String mapStatus(String st) {
      var s = st.toLowerCase();
      if (s.contains("run") || s.contains("start") || s.contains("progress")) return "running";
      if (s.contains("fail") || s.contains("err")) return "error";
      return "done";
    }

    private static Label icon(String glyph) {
      var l = new Label(glyph);
      l.getStyleClass().add("chat-tool-icon");
      return l;
    }

    private static HBox spacer() {
      var box = new HBox();
      HBox.setHgrow(box, Priority.ALWAYS);
      return box;
    }
  }
}
