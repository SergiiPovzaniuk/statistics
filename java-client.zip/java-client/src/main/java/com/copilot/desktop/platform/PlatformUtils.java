package com.copilot.desktop.platform;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.Locale;

public final class PlatformUtils {
  private static final boolean WINDOWS =
      System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");

  private PlatformUtils() {}

  public static boolean isWindows() {
    return WINDOWS;
  }

  public static void configureRuntime() {
    if (!WINDOWS) return;
    System.setProperty("java.net.useSystemProxies", "true");
    System.setProperty("prism.allowhidpi", "true");
    System.setProperty("prism.order", "d3d,sw");
    System.setProperty("java.awt.headless", "false");
  }

  public static String comSpec() {
    var comspec = System.getenv("COMSPEC");
    return comspec == null || comspec.isBlank() ? "cmd.exe" : comspec;
  }

  public static Charset consoleCharset() {
    if (!WINDOWS) return StandardCharsets.UTF_8;
    var name = System.getProperty("sun.stdout.encoding");
    if (name != null && !name.isBlank()) {
      try {
        return Charset.forName(name);
      } catch (Exception ignored) {
      }
    }
    return Charset.defaultCharset();
  }

  public static boolean isSameOrChildPath(Path root, Path candidate) {
    var r = root.toAbsolutePath().normalize();
    var c = candidate.toAbsolutePath().normalize();
    if (WINDOWS) {
      var rs = r.toString().toLowerCase(Locale.ROOT);
      var cs = c.toString().toLowerCase(Locale.ROOT);
      return cs.equals(rs) || cs.startsWith(rs + "\\");
    }
    return c.startsWith(r);
  }
}
