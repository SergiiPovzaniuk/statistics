package com.copilot.desktop.api;

import com.copilot.desktop.config.AppSettings;
import com.copilot.desktop.model.ChatRequest;
import com.copilot.desktop.model.ModelOption;
import com.copilot.desktop.model.SessionInfo;
import com.copilot.desktop.model.SseEvent;
import java.util.List;
import java.util.function.Consumer;

public interface ProxyApiClient {
  void configure(AppSettings settings);

  SessionInfo getSession() throws Exception;

  List<ModelOption> getModels() throws Exception;

  void streamChat(ChatRequest request, Consumer<SseEvent> onEvent) throws Exception;
}
