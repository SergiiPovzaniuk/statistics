package com.copilot.desktop.ui.icons;

import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.SVGPath;

public final class FileIcons {
  private FileIcons() {}

  public static Node forPath(String path, boolean directory) {
    var kind = FileKind.from(path, directory);
    if (kind == FileKind.FOLDER) {
      return folderIcon();
    }
    return badgeIcon(kind);
  }

  public static String displayName(String path) {
    if (path == null || path.isBlank()) return "";
    var clean = path.endsWith("/") ? path.substring(0, path.length() - 1) : path;
    var idx = Math.max(clean.lastIndexOf('/'), clean.lastIndexOf('\\'));
    return idx >= 0 ? clean.substring(idx + 1) : clean;
  }

  private static Node folderIcon() {
    var path = new SVGPath();
    path.setContent("M2 3.5h5.5L9 5.5H14v7.5H2V3.5z");
    path.getStyleClass().add("file-icon-folder-shape");
    var wrap = new StackPane(path);
    wrap.getStyleClass().addAll("file-icon", FileKind.FOLDER.cssClass());
    wrap.setMinSize(16, 16);
    wrap.setMaxSize(16, 16);
    return wrap;
  }

  private static Node badgeIcon(FileKind kind) {
    var wrap = new StackPane();
    wrap.getStyleClass().addAll("file-icon", kind.cssClass());
    wrap.setMinSize(16, 16);
    wrap.setMaxSize(16, 16);
    if (kind.badge() != null) {
      var label = new Label(kind.badge());
      label.getStyleClass().add("file-icon-badge");
      label.setAlignment(Pos.CENTER);
      wrap.getChildren().add(label);
    }
    return wrap;
  }
}
