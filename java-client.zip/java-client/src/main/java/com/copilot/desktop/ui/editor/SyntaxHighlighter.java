package com.copilot.desktop.ui.editor;

import java.util.Collection;
import java.util.Collections;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.fxmisc.richtext.model.StyleSpans;
import org.fxmisc.richtext.model.StyleSpansBuilder;

public final class SyntaxHighlighter {
  private static final Pattern JAVA =
      Pattern.compile(
          "(?<KEYWORD>\\b(?:abstract|assert|boolean|break|byte|case|catch|char|class|continue|default|do|double|else|enum|extends|final|finally|float|for|if|implements|import|instanceof|int|interface|long|native|new|package|private|protected|public|record|return|sealed|short|static|strictfp|super|switch|synchronized|this|throw|throws|transient|try|void|volatile|while|var|yield|permits|non-sealed|when|true|false|null)\\b)"
              + "|(?<TYPE>\\b[A-Z][\\w]*\\b)"
              + "|(?<ANNOTATION>@\\w+(?:\\.\\w+)*)"
              + "|(?<STRING>\"(?:[^\"\\\\]|\\\\.)*\")"
              + "|(?<CHAR>'(?:[^'\\\\]|\\\\.)*')"
              + "|(?<COMMENTLINE>//[^\n]*)"
              + "|(?<COMMENTBLOCK>/\\*(?:[^*]|\\*[^/])*\\*/)"
              + "|(?<NUMBER>\\b\\d+(?:_\\d+)*(?:\\.\\d+(?:_\\d+)*)?(?:[dDfFlL])?\\b)"
              + "|(?<PAREN>[()])"
              + "|(?<BRACE>[{}])"
              + "|(?<BRACKET>[\\[\\]])"
              + "|(?<SEMICOLON>[;,])");

  private static final Pattern JAVASCRIPT =
      Pattern.compile(
          "(?<KEYWORD>\\b(?:async|await|break|case|catch|class|const|continue|debugger|default|delete|do|else|export|extends|false|finally|for|from|function|if|import|in|instanceof|let|new|null|of|return|static|super|switch|this|throw|true|try|typeof|undefined|var|void|while|yield)\\b)"
              + "|(?<STRING>\"(?:[^\"\\\\]|\\\\.)*\"|'(?:[^'\\\\]|\\\\.)*'|`(?:[^`\\\\]|\\\\.)*`)"
              + "|(?<COMMENTLINE>//[^\n]*)"
              + "|(?<COMMENTBLOCK>/\\*(?:[^*]|\\*[^/])*\\*/)"
              + "|(?<NUMBER>\\b\\d+(?:_\\d+)*(?:\\.\\d+(?:_\\d+)*)?(?:[eE][+-]?\\d+)?\\b)"
              + "|(?<PAREN>[()])"
              + "|(?<BRACE>[{}])"
              + "|(?<BRACKET>[\\[\\]])"
              + "|(?<SEMICOLON>[;,])");

  private SyntaxHighlighter() {}

  public static StyleSpans<Collection<String>> highlight(String text, EditorLanguage language) {
    if (language == EditorLanguage.PLAIN || text == null || text.isEmpty()) {
      return StyleSpans.singleton(Collections.emptyList(), Math.max(text == null ? 0 : text.length(), 1));
    }
    var pattern = language == EditorLanguage.JAVA ? JAVA : JAVASCRIPT;
    var matcher = pattern.matcher(text);
    var spans = new StyleSpansBuilder<Collection<String>>();
    var last = 0;
    while (matcher.find()) {
      var style = styleFor(matcher);
      if (matcher.start() > last) {
        spans.add(Collections.emptyList(), matcher.start() - last);
      }
      spans.add(Collections.singleton(style), matcher.end() - matcher.start());
      last = matcher.end();
    }
    if (last < text.length()) {
      spans.add(Collections.emptyList(), text.length() - last);
    }
    return spans.create();
  }

  private static String styleFor(Matcher matcher) {
    if (group(matcher, "KEYWORD") != null) return "syn-keyword";
    if (group(matcher, "TYPE") != null) return "syn-type";
    if (group(matcher, "ANNOTATION") != null) return "syn-annotation";
    if (group(matcher, "STRING") != null || group(matcher, "CHAR") != null) return "syn-string";
    if (group(matcher, "COMMENTLINE") != null || group(matcher, "COMMENTBLOCK") != null) return "syn-comment";
    if (group(matcher, "NUMBER") != null) return "syn-number";
    if (group(matcher, "PAREN") != null || group(matcher, "BRACE") != null || group(matcher, "BRACKET") != null) {
      return "syn-bracket";
    }
    if (group(matcher, "SEMICOLON") != null) return "syn-punctuation";
    return "syn-text";
  }

  private static String group(Matcher matcher, String name) {
    try {
      return matcher.group(name);
    } catch (IllegalArgumentException ignored) {
      return null;
    }
  }
}
