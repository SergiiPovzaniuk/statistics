package com.copilot.desktop.model;

public record ChatRequest(String model, String mode, String context, String prompt, String sessionId) {}
