package com.copilot.desktop.model;

public record ContextAttachment(String path, String content) {
  public String label() {
    var p = path == null ? "" : path;
    var idx = Math.max(p.lastIndexOf('/'), p.lastIndexOf('\\'));
    return idx >= 0 ? p.substring(idx + 1) : p;
  }
}
