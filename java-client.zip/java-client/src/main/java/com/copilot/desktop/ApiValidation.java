package com.copilot.desktop;

import com.copilot.desktop.api.HttpProxyApiClient;
import com.copilot.desktop.config.AppSettings;
import com.copilot.desktop.model.ChatRequest;
import com.copilot.desktop.model.ModelOption;
import com.copilot.desktop.model.SseEvent;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

public final class ApiValidation {
  public static void main(String[] args) throws Exception {
    var api = new HttpProxyApiClient();
    api.configure(new AppSettings("http://localhost:8080", "cursor", "web123"));

    var session = api.getSession();
    System.out.println("session ok, key=" + (session.encryptionKey() != null ? "present" : "missing"));

    List<ModelOption> models = api.getModels();
    String requested = args.length > 0 ? args[0] : "claude-sonnet-5";
    String chosen =
        models.stream().anyMatch(m -> m.id().equals(requested))
            ? requested
            : models.stream()
                .map(ModelOption::id)
                .filter(id -> !"default".equals(id))
                .findFirst()
                .orElse("default");
    System.out.println("using model: " + chosen);

    var tokens = new StringBuilder();
    var done = new AtomicReference<SseEvent>();
    api.streamChat(
        new ChatRequest(chosen, "ask", "", "Reply with exactly one word: validated", null),
        event -> {
          System.out.println("event: " + event.type() + " " + (event.content() != null ? event.content() : event.message()));
          switch (event.type()) {
            case "token" -> tokens.append(event.content());
            case "done" -> done.set(event);
            case "error" -> throw new RuntimeException(event.message());
            default -> {}
          }
        });

    System.out.println("response: " + tokens);
    System.out.println("done sessionId: " + (done.get() != null ? done.get().sessionId() : null));
  }
}
