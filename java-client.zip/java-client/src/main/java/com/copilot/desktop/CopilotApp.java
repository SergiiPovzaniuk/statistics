package com.copilot.desktop;

import com.copilot.desktop.agent.AgentLoop;
import com.copilot.desktop.api.HttpProxyApiClient;
import com.copilot.desktop.api.ProxyApiClient;
import com.copilot.desktop.config.AppSettings;
import com.copilot.desktop.fs.ContextBuilder;
import com.copilot.desktop.fs.LocalWorkspace;
import com.copilot.desktop.model.ContextAttachment;
import com.copilot.desktop.ui.ConnectDialog;
import com.copilot.desktop.ui.MainView;
import java.util.ArrayList;
import java.util.List;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;

public final class CopilotApp extends Application {
  private final ProxyApiClient api = new HttpProxyApiClient();
  private final LocalWorkspace workspace = new LocalWorkspace();
  private final AgentLoop agentLoop = new AgentLoop(api, workspace);
  private AppSettings settings = AppSettings.defaults();
  private String sessionId = java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 12);
  private String mode = "agent";
  private String model = "default";
  private MainView view;

  @Override
  public void start(Stage stage) {
    view = new MainView();
    view.setOnConnect(this::handleConnect);
    view.setOnOpenFolder(this::handleOpenFolder);
    view.setOnRefreshTree(this::refreshTree);
    view.setOnOpenFile(this::handleOpenFile);
    view.setOnSend(this::handleSend);
    view.setOnStop(agentLoop::stop);
    view.setOnNewChat(this::handleNewChat);
    view.setOnModeChange(m -> mode = m);
    view.setOnAddToContext(this::handleAddToContext);
    view.setOnPickFiles(this::handlePickFiles);

    var scene = new Scene(view.getRoot(), 1400, 900);
    scene.getStylesheets().add(getClass().getResource("/styles.css").toExternalForm());
    stage.setTitle("Cursor");
    stage.setScene(scene);
    stage.show();
    Platform.runLater(this::connectWithDefaults);
  }

  private void connectWithDefaults() {
    api.configure(settings);
    view.setStatus("Connecting…");
    new Thread(
            () -> {
              try {
                api.getSession();
                var models = api.getModels();
                Platform.runLater(
                    () -> {
                      view.setModels(models);
                      view.setConnected(settings.normalizedBaseUrl());
                    });
              } catch (Exception e) {
                Platform.runLater(
                    () -> view.setStatus("Connect failed: " + e.getMessage() + " — click Connect"));
              }
            })
        .start();
  }

  private void handleConnect() {
    var dialog = new ConnectDialog(view.getRoot().getScene().getWindow(), settings);
    var result = dialog.showAndWait();
    if (result.isEmpty()) return;
    settings = result.get();
    api.configure(settings);
    view.setStatus("Connecting…");
    new Thread(
            () -> {
              try {
                api.getSession();
                var models = api.getModels();
                Platform.runLater(
                    () -> {
                      view.setModels(models);
                      view.setConnected(settings.normalizedBaseUrl());
                    });
              } catch (Exception e) {
                Platform.runLater(() -> view.setStatus("Connect failed: " + e.getMessage()));
              }
            })
        .start();
  }

  private void handleOpenFolder() {
    var chooser = new DirectoryChooser();
    chooser.setTitle("Open workspace folder");
    var selected = chooser.showDialog(view.getRoot().getScene().getWindow());
    if (selected == null) return;
    try {
      workspace.open(selected.toPath());
      refreshTree();
      view.setWorkspaceName(workspace.folderName());
      view.setStatus("Workspace: " + workspace.folderName());
    } catch (Exception e) {
      view.setStatus("Open failed: " + e.getMessage());
    }
  }

  private void refreshTree() {
    try {
      if (!workspace.isOpen()) {
        view.setFileTree(List.of());
        view.setWorkspaceName(null);
        return;
      }
      view.setFileTree(workspace.listPaths());
      view.setWorkspaceName(workspace.folderName());
    } catch (Exception e) {
      view.setStatus("Tree refresh failed: " + e.getMessage());
    }
  }

  private void handleOpenFile(String path) {
    try {
      var content = workspace.readFile(path);
      view.openEditorTab(path, content);
    } catch (Exception e) {
      view.setStatus("Read failed: " + e.getMessage());
    }
  }

  private void handleAddToContext(String path) {
    try {
      var content = workspace.readFile(path);
      view.addAttachment(new ContextAttachment(path, content));
    } catch (Exception e) {
      view.setStatus("Add context failed: " + e.getMessage());
    }
  }

  private void handlePickFiles(List<String> paths) {
    if (paths == null || paths.isEmpty()) return;
    var list = new ListView<String>();
    list.getItems().addAll(paths);
    list.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    var dlg = new Stage();
    dlg.initModality(Modality.WINDOW_MODAL);
    dlg.initOwner(view.getRoot().getScene().getWindow());
    dlg.setTitle("Add context");
    var add = new Button("Add");
    add.setOnAction(
        e -> {
          for (var path : list.getSelectionModel().getSelectedItems()) {
            handleAddToContext(path);
          }
          dlg.close();
        });
    var box = new VBox(10, list, new HBox(8, add));
    box.setPadding(new Insets(10));
    dlg.setScene(new Scene(box, 420, 360));
    dlg.showAndWait();
  }

  private void handleNewChat() {
    sessionId = java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 12);
    view.clearChat();
    view.setStatus("New chat");
  }

  private void handleSend(String prompt) {
    if (prompt == null || prompt.isBlank()) return;
    model = view.getSelectedModelId();
    var attachments = new ArrayList<>(view.getAttachments());
    for (var i = 0; i < attachments.size(); i++) {
      var att = attachments.get(i);
      if (att.content() == null) {
        try {
          attachments.set(i, new ContextAttachment(att.path(), workspace.readFile(att.path())));
        } catch (Exception ignored) {
        }
      }
    }
    view.appendUserMessage(prompt);
    view.beginAssistantTurn();
    var attachmentFiles =
        attachments.stream()
            .filter(a -> a.content() != null)
            .map(a -> new ContextBuilder.AttachmentFile(a.path(), a.content()))
            .toList();
    new Thread(
            () -> {
              try {
                agentLoop.run(
                    prompt,
                    attachmentFiles,
                    mode,
                    model,
                    sessionId,
                    sid -> sessionId = sid,
                    new AgentLoop.Callbacks() {
                      @Override
                      public String activePath() {
                        var active = view.getActiveFile();
                        return active == null ? null : active.path();
                      }

                      @Override
                      public String activeContent() {
                        var active = view.getActiveFile();
                        return active == null ? null : active.content();
                      }

                      @Override
                      public void onToken(String token) {
                        Platform.runLater(() -> view.appendToken(token));
                      }

                      @Override
                      public void onThinking(String chunk) {
                        Platform.runLater(() -> view.appendThinking(chunk));
                      }

                      @Override
                      public void onTool(String name, String status, String summary) {
                        Platform.runLater(() -> view.updateTool(name, status, summary));
                      }

                      @Override
                      public void onReadOp(String path, String status, String summary) {
                        Platform.runLater(() -> view.showReadOp(path, status, summary));
                      }

                      @Override
                      public void onShellOp(String command, String status, String summary) {
                        Platform.runLater(() -> view.showShellOp(command, status, summary));
                      }

                      @Override
                      public void onFileOp(String operation, String path) {
                        Platform.runLater(() -> view.showFileOp(operation, path));
                      }

                      @Override
                      public void onTerminalAppend(String text) {
                        Platform.runLater(() -> view.appendTerminal(text));
                      }

                      @Override
                      public void onOpenFile(String path) {
                        Platform.runLater(() -> handleOpenFile(path));
                      }

                      @Override
                      public void onTreeRefresh() {
                        Platform.runLater(CopilotApp.this::refreshTree);
                      }

                      @Override
                      public void onStatus(String text) {
                        Platform.runLater(() -> view.setStatus(text));
                      }

                      @Override
                      public void onSending(boolean value) {
                        Platform.runLater(() -> view.setSending(value));
                      }

                      @Override
                      public void beginAssistantTurn() {
                        Platform.runLater(view::beginAssistantTurn);
                      }
                    });
              } catch (Exception e) {
                Platform.runLater(
                    () -> {
                      view.setSending(false);
                      view.setStatus("Send failed: " + e.getMessage());
                    });
              }
            })
        .start();
  }
}
