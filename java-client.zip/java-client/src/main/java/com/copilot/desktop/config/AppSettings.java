package com.copilot.desktop.config;

public record AppSettings(String proxyBaseUrl, String username, String password) {
  public static AppSettings defaults() {
    return new AppSettings("http://localhost:8080", "cursor", "web123");
  }

  public String normalizedBaseUrl() {
    return proxyBaseUrl == null ? "" : proxyBaseUrl.replaceAll("/+$", "");
  }
}
