package com.copilot.desktop.ui;

import com.copilot.desktop.model.ContextAttachment;
import com.copilot.desktop.model.ModelOption;
import java.util.HashMap;
import java.util.List;
import java.util.function.Consumer;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SplitPane;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.scene.control.TextArea;
import com.copilot.desktop.ui.editor.CodeEditorPane;
import com.copilot.desktop.ui.icons.FileIcons;
import com.copilot.desktop.ui.icons.FileTreeCell;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;

public final class MainView {
  private final BorderPane root = new BorderPane();
  private final Label status = new Label("Not connected");
  private final TreeView<String> fileTree = new TreeView<>();
  private final TabPane editorTabs = new TabPane();
  private final TextArea terminal = new TextArea();
  private final ComposerPanel composer = new ComposerPanel();
  private final Label workspaceLabel = new Label("No folder");

  private Consumer<String> onSend;
  private Runnable onStop;
  private Consumer<String> onOpenFile;
  private Runnable onConnect;
  private Runnable onOpenFolder;
  private Runnable onRefreshTree;
  private Runnable onNewChat;
  private Consumer<String> onModeChange;
  private Consumer<String> onAddToContext;
  private Consumer<List<String>> onPickFiles;

  public MainView() {
    root.getStyleClass().add("root");
    root.setTop(buildTopBar());
    root.setCenter(buildBody());
    root.setBottom(buildStatusBar());

    fileTree.getStyleClass().add("file-tree");
    fileTree.setShowRoot(false);
    fileTree.setCellFactory(tv -> new FileTreeCell());
    fileTree.setOnMouseClicked(
        e -> {
          if (e.getClickCount() == 2 && onOpenFile != null) {
            var item = fileTree.getSelectionModel().getSelectedItem();
            if (item != null && item.getValue() != null && !item.getValue().endsWith("/")) {
              onOpenFile.accept(item.getValue());
            }
          }
        });
    var ctx = new ContextMenu();
    var addCtx = new MenuItem("Add to context");
    addCtx.setOnAction(
        e -> {
          var item = fileTree.getSelectionModel().getSelectedItem();
          if (item != null && item.getValue() != null && !item.getValue().endsWith("/") && onAddToContext != null) {
            onAddToContext.accept(item.getValue());
          }
        });
    ctx.getItems().add(addCtx);
    fileTree.setContextMenu(ctx);

    editorTabs.getStyleClass().add("editor-tabs");
    editorTabs.setTabClosingPolicy(TabPane.TabClosingPolicy.ALL_TABS);

    terminal.setEditable(false);
    terminal.setWrapText(false);
    terminal.getStyleClass().add("terminal-pane");
  }

  public BorderPane getRoot() {
    return root;
  }

  public ComposerPanel getComposer() {
    return composer;
  }

  public void setOnConnect(Runnable handler) {
    onConnect = handler;
  }

  public void setOnOpenFolder(Runnable handler) {
    onOpenFolder = handler;
  }

  public void setOnRefreshTree(Runnable handler) {
    onRefreshTree = handler;
  }

  public void setOnOpenFile(Consumer<String> handler) {
    onOpenFile = handler;
  }

  public void setOnSend(Consumer<String> handler) {
    onSend = handler;
    composer.setOnSend(handler);
  }

  public void setOnStop(Runnable handler) {
    onStop = handler;
    composer.setOnStop(handler);
  }

  public void setOnNewChat(Runnable handler) {
    onNewChat = handler;
  }

  public void setOnModeChange(Consumer<String> handler) {
    onModeChange = handler;
    composer.setOnModeChange(handler);
  }

  public void setOnAddToContext(Consumer<String> handler) {
    onAddToContext = handler;
  }

  public void setOnPickFiles(Consumer<List<String>> handler) {
    onPickFiles = handler;
    composer.setOnPickFiles(handler);
  }

  public void setStatus(String text) {
    status.setText(text);
  }

  public void setConnected(String proxyUrl) {
    setStatus("Connected · " + proxyUrl);
  }

  public void setWorkspaceName(String name) {
    workspaceLabel.setText(name == null || name.isBlank() ? "No folder" : name);
  }

  public void setModels(List<ModelOption> items) {
    composer.setModels(items);
  }

  public String getSelectedModelId() {
    return composer.getSelectedModelId();
  }

  public void setFileTree(List<String> paths) {
    fileTree.setRoot(buildTree(paths));
    composer.setWorkspacePaths(paths);
  }

  public void openEditorTab(String path, String content) {
    for (var tab : editorTabs.getTabs()) {
      if (path.equals(tab.getUserData()) && tab.getContent() instanceof CodeEditorPane editor) {
        editor.setText(content);
        editorTabs.getSelectionModel().select(tab);
        return;
      }
    }
    var editor = new CodeEditorPane(path, content);
    var tab = new Tab(FileIcons.displayName(path), editor);
    tab.setUserData(path);
    tab.setGraphic(FileIcons.forPath(path, false));
    tab.getStyleClass().add("editor-tab");
    tab.setClosable(true);
    editorTabs.getTabs().add(tab);
    editorTabs.getSelectionModel().select(tab);
  }

  public void appendTerminal(String text) {
    terminal.appendText(text);
    if (!text.endsWith("\n")) terminal.appendText("\n");
    selectTerminalTab();
  }

  public ActiveFile getActiveFile() {
    var tab = editorTabs.getSelectionModel().getSelectedItem();
    if (tab == null || tab.getContent() == null) return null;
    if (tab.getContent() instanceof CodeEditorPane editor) {
      var path = tab.getUserData() == null ? tab.getText() : String.valueOf(tab.getUserData());
      return new ActiveFile(path, editor.getText());
    }
    return null;
  }

  public void appendUserMessage(String text) {
    composer.appendUserMessage(text);
  }

  public void beginAssistantTurn() {
    composer.beginAssistantTurn();
  }

  public void appendToken(String token) {
    composer.appendToken(token);
  }

  public void appendThinking(String chunk) {
    composer.appendThinking(chunk);
  }

  public void updateTool(String name, String status, String summary) {
    composer.updateTool(name, status, summary);
  }

  public void showFileOp(String operation, String path) {
    composer.showFileOp(operation, path);
  }

  public void showReadOp(String path, String status, String summary) {
    composer.showReadOp(path, status, summary);
  }

  public void showShellOp(String command, String status, String summary) {
    composer.showShellOp(command, status, summary);
  }

  public void addAttachment(ContextAttachment attachment) {
    composer.addAttachment(attachment);
  }

  public List<ContextAttachment> getAttachments() {
    return composer.getAttachments();
  }

  public void clearChat() {
    composer.clearChat();
    composer.clearAttachments();
  }

  public void setSending(boolean value) {
    composer.setSending(value);
  }

  private HBox buildTopBar() {
    var brand = new Label("Cursor");
    brand.getStyleClass().add("brand");
    var connect = actionBtn("Connect", () -> onConnect);
    var open = actionBtn("Open Folder", () -> onOpenFolder);
    var refresh = actionBtn("Refresh", () -> onRefreshTree);
    var newChat = actionBtn("New Chat", () -> onNewChat);
    var left = new HBox(12, brand);
    left.setAlignment(Pos.CENTER_LEFT);
    var right = new HBox(8, connect, open, refresh, newChat);
    right.setAlignment(Pos.CENTER_RIGHT);
    var spacer = new Region();
    HBox.setHgrow(spacer, Priority.ALWAYS);
    var bar = new HBox(16, left, spacer, right);
    bar.setAlignment(Pos.CENTER_LEFT);
    bar.setPadding(new Insets(8, 14, 8, 14));
    bar.getStyleClass().add("top-bar");
    return bar;
  }

  private BorderPane buildBody() {
    var activity = new VBox(8, activityBtn("Files"));
    activity.getStyleClass().add("activity-bar");
    activity.setPadding(new Insets(10, 0, 10, 0));
    activity.setPrefWidth(48);

    workspaceLabel.getStyleClass().add("sidebar-title");
    var sidebarHeader = new HBox(workspaceLabel);
    sidebarHeader.setPadding(new Insets(10, 12, 4, 12));
    var sidebar = new VBox(sidebarHeader, fileTree);
    sidebar.getStyleClass().add("sidebar");
    VBox.setVgrow(fileTree, Priority.ALWAYS);

    var terminalTab = new Tab("Terminal", terminal);
    terminalTab.setClosable(false);
    editorTabs.getTabs().add(terminalTab);

    var editorWrap = new StackPane(editorTabs);
    editorWrap.getStyleClass().add("editor-wrap");

    var mainSplit = new SplitPane();
    mainSplit.setOrientation(Orientation.HORIZONTAL);
    mainSplit.getItems().addAll(sidebar, editorWrap, composer.getNode());
    mainSplit.setDividerPositions(0.18, 0.58);
    mainSplit.getStyleClass().add("main-split");

    var body = new BorderPane();
    body.setLeft(activity);
    body.setCenter(mainSplit);
    body.getStyleClass().add("body");
    return body;
  }

  private void selectTerminalTab() {
    for (var tab : editorTabs.getTabs()) {
      if ("Terminal".equals(tab.getText())) {
        editorTabs.getSelectionModel().select(tab);
        return;
      }
    }
  }

  private HBox buildStatusBar() {
    status.getStyleClass().add("status");
    var bar = new HBox(status);
    bar.setPadding(new Insets(4, 12, 4, 12));
    bar.getStyleClass().add("status-bar");
    return bar;
  }

  private Button actionBtn(String text, java.util.function.Supplier<Runnable> action) {
    var btn = new Button(text);
    btn.getStyleClass().add("tool-btn");
    btn.setOnAction(
        e -> {
          var handler = action.get();
          if (handler != null) handler.run();
        });
    return btn;
  }

  private Button activityBtn(String text) {
    var btn = new Button(text.substring(0, 1));
    btn.getStyleClass().add("activity-btn");
    btn.setMaxWidth(Double.MAX_VALUE);
    return btn;
  }

  private TreeItem<String> buildTree(List<String> paths) {
    var root = new TreeItem<>("");
    var index = new HashMap<String, TreeItem<String>>();
    index.put("", root);
    for (var raw : paths.stream().sorted().toList()) {
      var isDir = raw.endsWith("/");
      var clean = isDir ? raw.substring(0, raw.length() - 1) : raw;
      if (clean.isBlank()) continue;
      var parts = clean.split("/");
      var parentKey = "";
      var parent = root;
      for (var i = 0; i < parts.length; i++) {
        var part = parts[i];
        if (part.isBlank()) continue;
        var key = parentKey.isEmpty() ? part : parentKey + "/" + part;
        var leaf = i == parts.length - 1;
        var nodeKey = leaf && isDir ? key + "/" : key;
        var node = index.get(nodeKey);
        if (node == null) {
          node = new TreeItem<>(nodeKey);
          parent.getChildren().add(node);
          index.put(nodeKey, node);
        }
        parentKey = key;
        parent = node;
      }
    }
    return root;
  }

  public record ActiveFile(String path, String content) {}
}
