package com.copilot.desktop.ui.icons;

import javafx.scene.control.TreeCell;

public final class FileTreeCell extends TreeCell<String> {
  @Override
  protected void updateItem(String path, boolean empty) {
    super.updateItem(path, empty);
    if (empty || path == null || path.isBlank()) {
      setText(null);
      setGraphic(null);
      return;
    }
    var directory = path.endsWith("/");
    setGraphic(FileIcons.forPath(path, directory));
    setText(FileIcons.displayName(path));
  }
}
