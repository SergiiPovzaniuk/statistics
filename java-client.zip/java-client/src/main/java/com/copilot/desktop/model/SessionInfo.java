package com.copilot.desktop.model;

import java.util.List;

public record SessionInfo(String encryptionKey, String workspacePath, String workspaceName, List<String> workspacePaths) {}
