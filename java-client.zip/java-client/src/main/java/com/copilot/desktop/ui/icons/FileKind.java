package com.copilot.desktop.ui.icons;

public enum FileKind {
  FOLDER("file-icon-folder", null),
  JAVA("file-icon-java", "J"),
  JAVASCRIPT("file-icon-js", "JS"),
  TYPESCRIPT("file-icon-ts", "TS"),
  JSON("file-icon-json", "{ }"),
  XML("file-icon-xml", "<>"),
  HTML("file-icon-html", "<>"),
  CSS("file-icon-css", "#"),
  MARKDOWN("file-icon-md", "M"),
  PROPERTIES("file-icon-props", "P"),
  GRADLE("file-icon-gradle", "G"),
  MAVEN("file-icon-maven", "M"),
  YAML("file-icon-yaml", "Y"),
  SHELL("file-icon-sh", "$"),
  IMAGE("file-icon-img", "I"),
  TEXT("file-icon-txt", "T"),
  UNKNOWN("file-icon-unknown", null);

  private final String cssClass;
  private final String badge;

  FileKind(String cssClass, String badge) {
    this.cssClass = cssClass;
    this.badge = badge;
  }

  public String cssClass() {
    return cssClass;
  }

  public String badge() {
    return badge;
  }

  public static FileKind from(String path, boolean directory) {
    if (directory) return FOLDER;
    if (path == null) return UNKNOWN;
    var name = path;
    var slash = Math.max(name.lastIndexOf('/'), name.lastIndexOf('\\'));
    if (slash >= 0) name = name.substring(slash + 1);
    var dot = name.lastIndexOf('.');
    if (dot < 0 || dot == name.length() - 1) return UNKNOWN;
    var ext = name.substring(dot + 1).toLowerCase();
    return switch (ext) {
      case "java" -> JAVA;
      case "js", "jsx", "mjs", "cjs" -> JAVASCRIPT;
      case "ts", "tsx" -> TYPESCRIPT;
      case "json" -> JSON;
      case "xml", "xsd", "xsl" -> "pom.xml".equalsIgnoreCase(name) ? MAVEN : XML;
      case "svg" -> IMAGE;
      case "html", "htm" -> HTML;
      case "css", "scss", "sass", "less" -> CSS;
      case "md", "markdown" -> MARKDOWN;
      case "properties", "env" -> PROPERTIES;
      case "gradle" -> GRADLE;
      case "kts" -> name.toLowerCase().contains("gradle") ? GRADLE : UNKNOWN;
      case "yaml", "yml" -> YAML;
      case "sh", "bash", "zsh", "ps1", "bat", "cmd" -> SHELL;
      case "png", "jpg", "jpeg", "gif", "webp", "ico", "bmp" -> IMAGE;
      case "txt", "log" -> TEXT;
      default -> UNKNOWN;
    };
  }
}
