package com.copilot.desktop.fs;

import com.copilot.desktop.platform.PlatformUtils;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

public final class LocalShellRunner {
  private static final long TIMEOUT_SEC = 60;
  private static final List<Pattern> BLOCKED =
      List.of(
          Pattern.compile("rm\\s+-rf\\s+[/\\\\]", Pattern.CASE_INSENSITIVE),
          Pattern.compile("format\\s+[a-z]:", Pattern.CASE_INSENSITIVE),
          Pattern.compile("del\\s+/[fq]", Pattern.CASE_INSENSITIVE),
          Pattern.compile("rd\\s+/s\\s+/q", Pattern.CASE_INSENSITIVE),
          Pattern.compile("mkfs\\.", Pattern.CASE_INSENSITIVE),
          Pattern.compile("remove-item\\s+.*-recurse", Pattern.CASE_INSENSITIVE),
          Pattern.compile("rmdir\\s+/s\\s+/q", Pattern.CASE_INSENSITIVE));

  public record Result(int exitCode, String output, String error) {}

  public Result run(LocalWorkspace workspace, String command, String cwdRel) throws IOException {
    if (command == null || command.isBlank()) {
      return new Result(1, "", "Empty command");
    }
    for (var p : BLOCKED) {
      if (p.matcher(command).find()) {
        return new Result(1, "", "Blocked destructive command");
      }
    }
    if (command.contains(":(){")) {
      return new Result(1, "", "Blocked destructive command");
    }
    if (workspace == null || !workspace.isOpen()) {
      return new Result(1, "", "No workspace open");
    }
    var cwd = resolveCwd(workspace, cwdRel);
    var pb = new ProcessBuilder(shellCommand(command));
    pb.directory(cwd.toFile());
    pb.redirectErrorStream(true);
    if (PlatformUtils.isWindows()) {
      pb.environment().putIfAbsent("SystemRoot", System.getenv("SystemRoot"));
    }
    var proc = pb.start();
    try {
      if (!proc.waitFor(TIMEOUT_SEC, TimeUnit.SECONDS)) {
        proc.destroyForcibly();
        return new Result(124, "", "Command timed out after " + TIMEOUT_SEC + "s");
      }
      var charset = PlatformUtils.consoleCharset();
      var out = new StringBuilder();
      try (var reader = new InputStreamReader(proc.getInputStream(), charset)) {
        var buf = new char[4096];
        int n;
        while ((n = reader.read(buf)) >= 0) {
          out.append(buf, 0, n);
        }
      }
      return new Result(
          proc.exitValue(), out.toString(), proc.exitValue() == 0 ? null : "Exit " + proc.exitValue());
    } catch (InterruptedException e) {
      Thread.currentThread().interrupt();
      proc.destroyForcibly();
      return new Result(1, "", "Interrupted");
    }
  }

  private static Path resolveCwd(LocalWorkspace workspace, String cwdRel) throws IOException {
    var root = workspace.getRoot();
    if (cwdRel == null || cwdRel.isBlank()) return root;
    var cleaned = cwdRel.replace('\\', '/').replaceAll("^/+", "").replaceAll("/+$", "");
    var resolved = root.resolve(cleaned).normalize();
    if (!PlatformUtils.isSameOrChildPath(root, resolved) || !Files.isDirectory(resolved)) {
      throw new IOException("Invalid cwd: " + cwdRel);
    }
    return resolved;
  }

  private static List<String> shellCommand(String command) {
    if (PlatformUtils.isWindows()) {
      return List.of(PlatformUtils.comSpec(), "/c", "chcp 65001>nul & " + command);
    }
    return List.of("/bin/sh", "-c", command);
  }
}
