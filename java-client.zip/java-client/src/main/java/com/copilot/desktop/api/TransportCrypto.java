package com.copilot.desktop.api;

import com.copilot.desktop.model.EncryptedPayload;
import com.google.gson.Gson;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public final class TransportCrypto {
  private static final Gson GSON = new Gson();
  private static final int TAG_BITS = 128;
  private static final int IV_BYTES = 12;
  private static final SecureRandom RANDOM = new SecureRandom();

  private TransportCrypto() {}

  public static EncryptedPayload encrypt(String keyBase64, Object data) throws Exception {
    var key = Base64.getDecoder().decode(keyBase64);
    var iv = new byte[IV_BYTES];
    RANDOM.nextBytes(iv);
    var cipher = Cipher.getInstance("AES/GCM/NoPadding");
    cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(TAG_BITS, iv));
    var plaintext = GSON.toJson(data).getBytes(StandardCharsets.UTF_8);
    var sealed = cipher.doFinal(plaintext);
    var tagLen = TAG_BITS / 8;
    var ciphertext = new byte[sealed.length - tagLen];
    var tag = new byte[tagLen];
    System.arraycopy(sealed, 0, ciphertext, 0, ciphertext.length);
    System.arraycopy(sealed, ciphertext.length, tag, 0, tagLen);
    return new EncryptedPayload(1, Base64.getEncoder().encodeToString(iv), Base64.getEncoder().encodeToString(ciphertext), Base64.getEncoder().encodeToString(tag));
  }

  public static <T> T decrypt(String keyBase64, EncryptedPayload payload, Class<T> type) throws Exception {
    var key = Base64.getDecoder().decode(keyBase64);
    var iv = Base64.getDecoder().decode(payload.iv());
    var ciphertext = Base64.getDecoder().decode(payload.ciphertext());
    var tag = Base64.getDecoder().decode(payload.tag());
    var combined = new byte[ciphertext.length + tag.length];
    System.arraycopy(ciphertext, 0, combined, 0, ciphertext.length);
    System.arraycopy(tag, 0, combined, ciphertext.length, tag.length);
    var cipher = Cipher.getInstance("AES/GCM/NoPadding");
    cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(TAG_BITS, iv));
    var decrypted = cipher.doFinal(combined);
    return GSON.fromJson(new String(decrypted, StandardCharsets.UTF_8), type);
  }
}
