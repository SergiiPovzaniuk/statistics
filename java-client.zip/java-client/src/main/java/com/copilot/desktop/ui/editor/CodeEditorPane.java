package com.copilot.desktop.ui.editor;

import javafx.animation.PauseTransition;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import javafx.util.Duration;
import org.fxmisc.richtext.CodeArea;
import org.fxmisc.richtext.LineNumberFactory;

public final class CodeEditorPane extends VBox {
  private final CodeArea codeArea;
  private final EditorLanguage language;
  private final PauseTransition highlightDelay = new PauseTransition(Duration.millis(80));

  public CodeEditorPane(String path, String content) {
    language = EditorLanguage.fromPath(path);
    codeArea = new CodeArea();
    codeArea.getStyleClass().add("code-editor");
    codeArea.setWrapText(false);
    codeArea.setParagraphGraphicFactory(LineNumberFactory.get(codeArea));
    VBox.setVgrow(codeArea, Priority.ALWAYS);

    highlightDelay.setOnFinished(e -> applyHighlight());
    codeArea
        .multiPlainChanges()
        .subscribe(
            changes -> {
              highlightDelay.stop();
              highlightDelay.playFromStart();
            });

    getStyleClass().add("code-editor-wrap");
    getChildren().add(codeArea);
    setText(content == null ? "" : content);
  }

  public CodeArea getCodeArea() {
    return codeArea;
  }

  public String getText() {
    return codeArea.getText();
  }

  public void setText(String content) {
    codeArea.replaceText(content == null ? "" : content);
    applyHighlight();
  }

  private void applyHighlight() {
    if (language == EditorLanguage.PLAIN) return;
    var text = codeArea.getText();
    codeArea.setStyleSpans(0, SyntaxHighlighter.highlight(text, language));
  }
}
