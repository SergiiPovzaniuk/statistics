package com.copilot.desktop.model;

public record SseEvent(
    String type,
    String content,
    String name,
    String status,
    String summary,
    String operation,
    String path,
    String command,
    String cwd,
    String sessionId,
    String agentId,
    String message,
    String model,
    Integer inputTokens,
    Integer outputTokens,
    Integer contextLimit,
    Integer chars,
    Integer estimatedTokens) {}
