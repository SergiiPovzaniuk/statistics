package com.copilot.desktop.ui;

import com.copilot.desktop.model.ContextAttachment;
import com.copilot.desktop.ui.icons.FileIcons;
import com.copilot.desktop.model.ModelOption;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ContextMenu;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextArea;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;

public final class ComposerPanel {
  private final VBox root = new VBox();
  private final ChatStreamView chatStream = new ChatStreamView();
  private final FlowPane chips = new FlowPane(6, 6);
  private final TextArea prompt = new TextArea();
  private final Button send = new Button("↑");
  private final Button stop = new Button("■");
  private final Button addContext = new Button("@");
  private final ComboBox<ModelOption> models = new ComboBox<>();
  private final ToggleGroup modeGroup = new ToggleGroup();
  private final ToggleButton agent = modePill("Agent", true);
  private final ToggleButton ask = modePill("Ask", false);
  private final List<ContextAttachment> attachments = new ArrayList<>();
  private List<String> workspacePaths = List.of();
  private ContextMenu mentionMenu = new ContextMenu();

  private Consumer<String> onSend;
  private Runnable onStop;
  private Consumer<String> onModeChange;
  private Consumer<List<String>> onPickFiles;

  public ComposerPanel() {
    agent.setToggleGroup(modeGroup);
    ask.setToggleGroup(modeGroup);
    modeGroup.selectedToggleProperty()
        .addListener(
            (obs, old, neu) -> {
              if (onModeChange != null && neu != null) {
                onModeChange.accept(agent.isSelected() ? "agent" : "ask");
              }
            });

    chips.getStyleClass().add("composer-chips");
    prompt.getStyleClass().add("composer-input");
    prompt.setWrapText(true);
    prompt.setPromptText("Ask, @mention files, or describe changes…");
    send.getStyleClass().addAll("send-btn", "primary");
    stop.getStyleClass().addAll("stop-btn");
    addContext.getStyleClass().add("tool-btn");
    stop.setVisible(false);
    stop.setManaged(false);

    send.setOnAction(e -> handleSend());
    stop.setOnAction(e -> {
      if (onStop != null) onStop.run();
    });
    addContext.setOnAction(e -> showAddContextDialog());

    prompt.addEventFilter(KeyEvent.KEY_PRESSED, this::handlePromptKey);
    prompt.textProperty().addListener((obs, old, neu) -> updateMentionMenu(neu));

    models.getStyleClass().add("model-picker");
    models.setPrefWidth(180);

    var header = new HBox(8, agent, ask, spacer(), models);
    header.setAlignment(Pos.CENTER_LEFT);
    header.setPadding(new Insets(10, 12, 4, 12));
    header.getStyleClass().add("composer-header");

    var chipWrap = new VBox(chips);
    chipWrap.setPadding(new Insets(0, 12, 0, 12));

    var actions = new HBox(8, addContext, spacer(), stop, send);
    actions.setAlignment(Pos.CENTER_RIGHT);
    send.setMinWidth(36);
    stop.setMinWidth(36);
    prompt.setPrefRowCount(3);
    var inputBox = new VBox(6, chipWrap, prompt, actions);
    inputBox.setPadding(new Insets(8, 10, 10, 10));
    inputBox.getStyleClass().add("composer-dock");

    root.getChildren().addAll(header, chatStream.getNode(), inputBox);
    root.getStyleClass().add("composer-panel");
    VBox.setVgrow(chatStream.getNode(), Priority.ALWAYS);
  }

  public VBox getNode() {
    return root;
  }

  public ChatStreamView getChatStream() {
    return chatStream;
  }

  public void setOnSend(Consumer<String> handler) {
    onSend = handler;
  }

  public void setOnStop(Runnable handler) {
    onStop = handler;
  }

  public void setOnModeChange(Consumer<String> handler) {
    onModeChange = handler;
  }

  public void setOnPickFiles(Consumer<List<String>> handler) {
    onPickFiles = handler;
  }

  public void setWorkspacePaths(List<String> paths) {
    workspacePaths = paths == null ? List.of() : paths.stream().filter(p -> !p.endsWith("/")).sorted().toList();
  }

  public void setModels(List<ModelOption> items) {
    models.getItems().setAll(items);
    models.setCellFactory(
        lv ->
            new javafx.scene.control.ListCell<>() {
              @Override
              protected void updateItem(ModelOption item, boolean empty) {
                super.updateItem(item, empty);
                setText(empty || item == null ? null : item.label());
              }
            });
    models.setButtonCell(
        new javafx.scene.control.ListCell<>() {
          @Override
          protected void updateItem(ModelOption item, boolean empty) {
            super.updateItem(item, empty);
            setText(empty || item == null ? null : item.label());
          }
        });
    if (!items.isEmpty()) models.getSelectionModel().select(0);
  }

  public String getSelectedModelId() {
    var selected = models.getSelectionModel().getSelectedItem();
    return selected == null ? "default" : selected.id();
  }

  public List<ContextAttachment> getAttachments() {
    return List.copyOf(attachments);
  }

  public void addAttachment(ContextAttachment attachment) {
    if (attachment == null || attachment.path() == null) return;
    attachments.removeIf(a -> a.path().equals(attachment.path()));
    attachments.add(attachment);
    renderChips();
  }

  public void removeAttachment(String path) {
    attachments.removeIf(a -> a.path().equals(path));
    renderChips();
  }

  public void clearAttachments() {
    attachments.clear();
    renderChips();
  }

  public void appendUserMessage(String text) {
    chatStream.addUserMessage(text);
    prompt.clear();
  }

  public void beginAssistantTurn() {
    chatStream.beginAssistantTurn();
  }

  public void appendToken(String token) {
    chatStream.appendToken(token);
  }

  public void appendThinking(String chunk) {
    chatStream.appendThinking(chunk);
  }

  public void updateTool(String name, String status, String summary) {
    chatStream.updateTool(name, status, summary);
  }

  public void showFileOp(String operation, String path) {
    chatStream.showFileOp(operation, path);
  }

  public void showReadOp(String path, String status, String summary) {
    chatStream.showReadOp(path, status, summary);
  }

  public void showShellOp(String command, String status, String summary) {
    chatStream.showShellOp(command, status, summary);
  }

  public void clearChat() {
    chatStream.clear();
  }

  public void setSending(boolean value) {
    send.setDisable(value);
    prompt.setDisable(value);
    addContext.setDisable(value);
    stop.setVisible(value);
    stop.setManaged(value);
    send.setVisible(!value);
    send.setManaged(!value);
  }

  private void handleSend() {
    var text = prompt.getText();
    if (text == null || text.isBlank()) return;
    if (onSend != null) onSend.accept(text);
  }

  private void handlePromptKey(KeyEvent e) {
    if (e.getCode() == KeyCode.ENTER && !e.isShiftDown()) {
      e.consume();
      handleSend();
      return;
    }
    if (e.getCode() == KeyCode.ESCAPE) {
      mentionMenu.hide();
    }
  }

  private void updateMentionMenu(String text) {
    if (text == null || workspacePaths.isEmpty()) {
      mentionMenu.hide();
      return;
    }
    var caret = prompt.getCaretPosition();
    var prefix = text.substring(0, Math.min(caret, text.length()));
    var at = prefix.lastIndexOf('@');
    if (at < 0) {
      mentionMenu.hide();
      return;
    }
    if (at > 0 && !Character.isWhitespace(prefix.charAt(at - 1))) {
      mentionMenu.hide();
      return;
    }
    var query = prefix.substring(at + 1).toLowerCase();
    if (query.contains(" ")) {
      mentionMenu.hide();
      return;
    }
    mentionMenu.getItems().clear();
    var matches =
        workspacePaths.stream()
            .filter(p -> query.isEmpty() || p.toLowerCase().contains(query))
            .limit(12)
            .toList();
    if (matches.isEmpty()) {
      mentionMenu.hide();
      return;
    }
    for (var path : matches) {
      var item = new MenuItem(path);
      item.setOnAction(
          ev -> {
            var before = text.substring(0, at);
            var after = caret < text.length() ? text.substring(caret) : "";
            prompt.setText(before + "@" + path + " " + after);
            prompt.positionCaret(before.length() + path.length() + 2);
            mentionMenu.hide();
          });
      mentionMenu.getItems().add(item);
    }
    if (!mentionMenu.isShowing()) {
      mentionMenu.show(prompt, javafx.geometry.Side.BOTTOM, 0, 0);
    }
  }

  private void showAddContextDialog() {
    if (onPickFiles != null) {
      onPickFiles.accept(workspacePaths);
      return;
    }
    if (workspacePaths.isEmpty()) return;
    var list = new ListView<String>();
    list.getItems().addAll(workspacePaths);
    list.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    var dlg = new javafx.stage.Stage();
    dlg.initModality(Modality.APPLICATION_MODAL);
    dlg.setTitle("Add context");
    var add =
        new Button("Add");
    add.setOnAction(
        e -> {
          for (var path : list.getSelectionModel().getSelectedItems()) {
            addAttachment(new ContextAttachment(path, null));
          }
          dlg.close();
        });
    var box = new VBox(10, list, new HBox(8, add));
    box.setPadding(new Insets(10));
    dlg.setScene(new javafx.scene.Scene(box, 420, 360));
    dlg.showAndWait();
  }

  private void renderChips() {
    chips.getChildren().clear();
    for (var att : attachments) {
      var label = new Label(att.label());
      label.getStyleClass().add("composer-chip-label");
      var remove = new Button("×");
      remove.getStyleClass().add("composer-chip-remove");
      remove.setOnAction(e -> removeAttachment(att.path()));
      var chip = new HBox(6, FileIcons.forPath(att.path(), false), label, remove);
      chip.getStyleClass().add("composer-chip");
      chip.setAlignment(Pos.CENTER_LEFT);
      chips.getChildren().add(chip);
    }
  }

  private static ToggleButton modePill(String text, boolean selected) {
    var btn = new ToggleButton(text);
    btn.getStyleClass().add("mode-pill");
    btn.setSelected(selected);
    return btn;
  }

  private static Region spacer() {
    var r = new Region();
    HBox.setHgrow(r, Priority.ALWAYS);
    return r;
  }
}
