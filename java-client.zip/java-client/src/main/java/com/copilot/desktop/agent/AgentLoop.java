package com.copilot.desktop.agent;

import com.copilot.desktop.api.ProxyApiClient;
import com.copilot.desktop.fs.ContextBuilder;
import com.copilot.desktop.fs.LocalShellRunner;
import com.copilot.desktop.fs.LocalWorkspace;
import com.copilot.desktop.model.ChatRequest;
import com.copilot.desktop.model.SseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.function.Consumer;

public final class AgentLoop {
  private static final int MAX_ITERATIONS = 8;

  private final ProxyApiClient api;
  private final LocalWorkspace workspace;
  private final LocalShellRunner shellRunner = new LocalShellRunner();
  private final AtomicBoolean cancelled = new AtomicBoolean(false);

  public AgentLoop(ProxyApiClient api, LocalWorkspace workspace) {
    this.api = api;
    this.workspace = workspace;
  }

  public void stop() {
    cancelled.set(true);
  }

  public void run(
      String prompt,
      List<ContextBuilder.AttachmentFile> attachments,
      String mode,
      String model,
      String sessionId,
      Consumer<String> onSessionId,
      Callbacks cb)
      throws Exception {
    cancelled.set(false);
    var mentions = new ArrayList<ContextBuilder.MentionFile>();
    for (var mention : ContextBuilder.parseMentions(prompt)) {
      try {
        mentions.add(new ContextBuilder.MentionFile(mention, workspace.readFile(mention)));
      } catch (Exception ignored) {
      }
    }
    var userPrompt = prompt;
    var sid = sessionId;
    var currentAttachments = attachments == null ? List.<ContextBuilder.AttachmentFile>of() : attachments;
    for (var i = 0; i < MAX_ITERATIONS && !cancelled.get(); i++) {
      if (i > 0) cb.beginAssistantTurn();
      var pending = new ArrayList<String>();
      var context =
          ContextBuilder.build(
              workspace.folderName(),
              workspace.isOpen() ? workspace.listPaths() : List.of(),
              cb.activePath(),
              cb.activeContent(),
              mentions,
              currentAttachments,
              "");
      var request = new ChatRequest(model, mode, context, userPrompt, sid);
      cb.onSending(true);
      var gotTerminal = new AtomicBoolean(false);
      api.streamChat(
          request,
          event -> handleEvent(event, pending, cb, gotTerminal, onSessionId));
      cb.onSending(false);
      if (cancelled.get()) break;
      if (!gotTerminal.get()) {
        cb.onStatus("Stream ended without completion");
        break;
      }
      if (pending.isEmpty()) break;
      userPrompt = "Tool results:\n\n" + String.join("\n\n", pending);
      mentions.clear();
      currentAttachments = List.of();
    }
  }

  private void handleEvent(
      SseEvent event,
      List<String> pending,
      Callbacks cb,
      AtomicBoolean gotTerminal,
      Consumer<String> onSessionId) {
    switch (event.type()) {
      case "token" -> {
        if (event.content() != null) cb.onToken(event.content());
      }
      case "thinking" -> {
        if (event.content() != null) cb.onThinking(event.content());
      }
      case "tool" -> cb.onTool(event.name(), event.status(), event.summary());
      case "read_op" -> {
        var path = event.path();
        cb.onReadOp(path, "running", null);
        try {
          var content = workspace.readFile(path);
          pending.add("read " + path + ":\n```\n" + content + "\n```");
          cb.onReadOp(path, "done", truncate(content, 200));
        } catch (Exception e) {
          pending.add("read " + path + ": ERROR " + e.getMessage());
          cb.onReadOp(path, "error", e.getMessage());
        }
      }
      case "shell_op" -> {
        var cmd = event.command();
        cb.onShellOp(cmd, "running", null);
        try {
          var result = shellRunner.run(workspace, cmd, event.cwd());
          var out = result.output() == null ? "" : result.output();
          pending.add("shell " + cmd + ":\n```\n" + out + "\n```");
          cb.onTerminalAppend("$ " + cmd + "\n" + out);
          cb.onShellOp(cmd, result.exitCode() == 0 ? "done" : "error", truncate(out, 400));
        } catch (Exception e) {
          pending.add("shell " + cmd + ": ERROR " + e.getMessage());
          cb.onShellOp(cmd, "error", e.getMessage());
        }
      }
      case "file_op" -> {
        cb.onFileOp(event.operation(), event.path());
        try {
          workspace.applyFileOp(event.operation(), event.path(), event.content());
          pending.add("file_op " + event.operation() + " " + event.path() + ": ok");
          cb.onTreeRefresh();
          if ("create".equals(event.operation()) || "update".equals(event.operation())) {
            cb.onOpenFile(event.path());
          }
        } catch (Exception e) {
          pending.add("file_op " + event.operation() + " " + event.path() + ": ERROR " + e.getMessage());
          cb.onStatus("File op failed: " + e.getMessage());
        }
      }
      case "context" ->
          cb.onStatus(
              "Context ~"
                  + event.estimatedTokens()
                  + " tok / "
                  + event.contextLimit());
      case "usage" ->
          cb.onStatus(
              "Tokens in "
                  + event.inputTokens()
                  + " · out "
                  + event.outputTokens());
      case "done" -> {
        if (event.sessionId() != null) onSessionId.accept(event.sessionId());
        gotTerminal.set(true);
        cb.onStatus("Done");
      }
      case "error" -> {
        gotTerminal.set(true);
        cb.onStatus(event.message() == null ? "Error" : event.message());
      }
      default -> {}
    }
  }

  private static String truncate(String s, int max) {
    if (s == null) return null;
    if (s.length() <= max) return s;
    return s.substring(0, max) + "…";
  }

  public interface Callbacks {
    String activePath();

    String activeContent();

    void onToken(String token);

    void onThinking(String chunk);

    void onTool(String name, String status, String summary);

    void onReadOp(String path, String status, String summary);

    void onShellOp(String command, String status, String summary);

    void onFileOp(String operation, String path);

    void onTerminalAppend(String text);

    void onOpenFile(String path);

    void onTreeRefresh();

    void onStatus(String text);

    void onSending(boolean value);

    void beginAssistantTurn();
  }
}
