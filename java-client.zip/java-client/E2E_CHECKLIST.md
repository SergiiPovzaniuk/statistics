# Composer E2E checklist

Stack: `cursor_api :3000` → `http_manager :5554` → `client :8080` → `mvn javafx:run`

1. Open folder in java-client; verify file tree loads.
2. Attach 2 files via **@** button or tree **Add to context**; verify chips appear.
3. Agent mode + `composer-2.5`: ask to read a file not in context; verify **Read** tool card.
4. Ask to run `echo test` or `npm test`; verify **Shell** card + **Terminal** tab output.
5. Ask for a small file edit; verify **Edit/Create** card, tree refresh, editor tab opens.
6. Click **Stop** during streaming; verify loop stops.
7. Multi-step task (read + shell + edit) completes via auto follow-up without manual send.
