package com.client.proxy.service;

import com.client.proxy.config.CursorWebProperties;
import com.client.proxy.config.PlaywrightProperties;
import com.client.proxy.crypto.SseParserService;
import com.client.proxy.crypto.TransportCryptoService;
import com.client.proxy.dto.ChatRequestDto;
import com.client.proxy.dto.ChatStreamResult;
import com.client.proxy.dto.EncryptedPayload;
import com.client.proxy.dto.HttpResult;
import com.client.proxy.dto.WorkspaceFileWriteRequest;
import com.client.proxy.dto.WorkspaceMkdirRequest;
import com.client.proxy.exception.ProxyAutomationException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.List;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class CursorWebService {

    private final PlaywrightHttpTransport transport;
    private final CursorWebProperties properties;
    private final TransportCryptoService cryptoService;
    private final SseParserService sseParserService;
    private final ObjectMapper objectMapper;
    private final PlaywrightBrowserManager browserManager;
    private final PlaywrightBrowserSession browserSession;

    private volatile String encryptionKey;

    public CursorWebService(
            PlaywrightHttpTransport transport,
            PlaywrightProperties playwrightProperties,
            CursorWebProperties properties,
            TransportCryptoService cryptoService,
            SseParserService sseParserService,
            ObjectMapper objectMapper,
            PlaywrightBrowserManager browserManager,
            PlaywrightBrowserSession browserSession) {
        this.transport = transport;
        this.properties = properties;
        this.cryptoService = cryptoService;
        this.sseParserService = sseParserService;
        this.objectMapper = objectMapper;
        this.browserManager = browserManager;
        this.browserSession = browserSession;
    }

    public synchronized JsonNode getSession() {
        return run(() -> {
            HttpResult result = transport.executeCursor("session", null, false, null, false);
            encryptionKey = result.body().path("encryptionKey").asText(null);
            return result.body();
        });
    }

    public synchronized JsonNode getModels() {
        return run(() -> transport.executeCursor("models", null, false, null, false).body());
    }

    public synchronized JsonNode getWorkspace() {
        return run(() -> transport.executeCursor("workspace", null, false, null, false).body());
    }

    public synchronized JsonNode getWorkspaceFile(String path) {
        return run(() -> transport.executeCursor("file-get", path, false, null, false).body());
    }

    public synchronized JsonNode putWorkspaceFile(WorkspaceFileWriteRequest request) {
        return run(() -> transport.executeCursor(
                        "file-put",
                        null,
                        false,
                        Map.of("path", request.path(), "content", request.content() != null ? request.content() : ""),
                        false)
                .body());
    }

    public synchronized JsonNode deleteWorkspaceFile(String path, boolean dir) {
        return run(() -> transport.executeCursor("file-delete", path, dir, null, false).body());
    }

    public synchronized JsonNode mkdirWorkspace(WorkspaceMkdirRequest request) {
        return run(() -> transport.executeCursor("mkdir", null, false, Map.of("path", request.path()), false).body());
    }

    public synchronized ChatStreamResult chat(JsonNode body) {
        if (sseParserService.isEncrypted(body)) {
            return chatPassthrough(body);
        }
        if (!properties.isAllowPlaintext()) {
            throw new IllegalArgumentException("Encrypted payload required when plaintext is disabled");
        }
        ChatRequestDto request = objectMapper.convertValue(body, ChatRequestDto.class);
        if (request.prompt() == null || request.prompt().isBlank()) {
            throw new IllegalArgumentException("prompt is required");
        }
        return new ChatStreamResult(false, null, chatPlaintext(request));
    }

    private ChatStreamResult chatPassthrough(JsonNode body) {
        return run(() -> {
            EncryptedPayload payload = objectMapper.convertValue(body, EncryptedPayload.class);
            HttpResult result = transport.executeCursor("chat", null, false, payload, true);
            return new ChatStreamResult(true, sseParserService.formatEncryptedSse(result.raw()), null);
        });
    }

    public synchronized List<JsonNode> chatPlaintext(ChatRequestDto request) {
        return run(() -> {
            ensureEncryptionKey();
            ObjectNode payload = objectMapper.createObjectNode();
            payload.put("model", request.model());
            payload.put("mode", request.mode());
            payload.put("context", request.context() != null ? request.context() : "");
            payload.put("prompt", request.prompt());
            if (request.sessionId() != null && !request.sessionId().isBlank()) {
                payload.put("sessionId", request.sessionId());
            }

            Object body = properties.isAllowPlaintext()
                    ? payload
                    : cryptoService.encryptJson(encryptionKey, payload);

            HttpResult result = transport.executeCursor("chat", null, false, body, true);
            return sseParserService.parseEvents(result.raw(), encryptionKey, properties.isAllowPlaintext());
        });
    }

    private void ensureEncryptionKey() {
        if (encryptionKey == null || encryptionKey.isBlank()) {
            getSession();
        }
        if (encryptionKey == null || encryptionKey.isBlank()) {
            throw new ProxyAutomationException("Missing encryption key from session");
        }
    }

    private <T> T run(java.util.function.Supplier<T> supplier) {
        try {
            return supplier.get();
        } catch (ProxyAutomationException ex) {
            browserSession.reopenAfterFailure();
            if (!browserManager.isBrowserConnected()) {
                browserManager.relaunchBrowser();
                browserSession.reopenAfterFailure();
            }
            return supplier.get();
        }
    }
}
