package com.client.proxy.config;

import com.client.proxy.exception.BrowserNotReadyException;
import jakarta.annotation.PostConstruct;
import java.nio.file.Files;
import java.nio.file.Path;
import org.springframework.context.annotation.Configuration;

@Configuration
public class PlaywrightConfig {

    private final PlaywrightProperties properties;

    public PlaywrightConfig(PlaywrightProperties properties) {
        this.properties = properties;
    }

    @PostConstruct
    void validateChromePath() {
        var configured = properties.getChrome().getExecutablePath();
        if (configured == null || configured.isBlank()) {
            return;
        }
        System.setProperty("PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD", "1");
        Path chromePath = Path.of(configured);
        if (!Files.isRegularFile(chromePath)) {
            throw new BrowserNotReadyException("Chrome executable not found: " + chromePath);
        }
    }
}
