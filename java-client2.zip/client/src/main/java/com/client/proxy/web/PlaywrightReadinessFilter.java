package com.client.proxy.web;

import com.client.proxy.service.PlaywrightBrowserSession;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class PlaywrightReadinessFilter extends OncePerRequestFilter {

    private final PlaywrightBrowserSession browserSession;

    public PlaywrightReadinessFilter(PlaywrightBrowserSession browserSession) {
        this.browserSession = browserSession;
    }

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        if (!browserSession.isReady() && !request.getRequestURI().startsWith("/actuator")) {
            response.sendError(HttpServletResponse.SC_SERVICE_UNAVAILABLE, "Playwright session is starting");
            return;
        }
        filterChain.doFilter(request, response);
    }
}
