package com.client.proxy.service;

import com.client.proxy.config.CursorWebProperties;
import com.client.proxy.config.PlaywrightProperties;
import com.client.proxy.exception.BrowserNotReadyException;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserContext;
import com.microsoft.playwright.Page;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class PlaywrightBrowserSession {

    private static final Logger log = LoggerFactory.getLogger(PlaywrightBrowserSession.class);

    private final PlaywrightBrowserManager browserManager;
    private final PlaywrightProperties playwrightProperties;
    private final CursorWebProperties cursorWebProperties;
    private final Object lock = new Object();

    private BrowserContext context;
    private Page page;
    private boolean uiReady;
    private volatile boolean ready;

    public PlaywrightBrowserSession(
            PlaywrightBrowserManager browserManager,
            PlaywrightProperties playwrightProperties,
            CursorWebProperties cursorWebProperties) {
        this.browserManager = browserManager;
        this.playwrightProperties = playwrightProperties;
        this.cursorWebProperties = cursorWebProperties;
    }

    @PostConstruct
    void warmUp() {
        synchronized (lock) {
            openIfNeeded();
            log.info("Playwright browser open on {}", playwrightProperties.getProxyUi().getUrl());
        }
    }

    public boolean isReady() {
        return ready;
    }

    public void markReady() {
        ready = true;
        log.info("Playwright session ready for commands");
    }

    public Page page() {
        synchronized (lock) {
            openIfNeeded();
            return page;
        }
    }

    @PreDestroy
    void shutdown() {
        reset();
    }

    public void reset() {
        synchronized (lock) {
            closeContext();
            uiReady = false;
            ready = false;
        }
    }

    void reopenAfterFailure() {
        synchronized (lock) {
            closeContext();
            uiReady = false;
            openIfNeeded();
            ready = true;
        }
    }

    private void openIfNeeded() {
        if (context != null && page != null && !page.isClosed()) {
            if (!uiReady) {
                prepareUi(page);
                uiReady = true;
            }
            return;
        }
        closeContext();
        Browser browser = browserManager.getBrowser();
        context = browser.newContext();
        page = context.newPage();
        uiReady = false;
        prepareUi(page);
        uiReady = true;
    }

    private void prepareUi(Page activePage) {
        try {
            activePage.navigate(
                    playwrightProperties.getProxyUi().getUrl(),
                    new Page.NavigateOptions()
                            .setTimeout(playwrightProperties.getTimeout().getNavigationMs())
                            .setWaitUntil(com.microsoft.playwright.options.WaitUntilState.LOAD));
            activePage.locator("[data-testid='tab-cursor']").waitFor();
            activePage.locator("[data-testid='tab-cursor']").click();
            activePage.locator("[data-testid='cursor-op']").waitFor();
            activePage.locator("[data-testid='cursor-user']").fill(cursorWebProperties.getUsername());
            activePage.locator("[data-testid='cursor-pass']").fill(cursorWebProperties.getPassword());
        } catch (Exception ex) {
            throw new BrowserNotReadyException("Failed to prepare Playwright UI", ex);
        }
    }

    private void closeContext() {
        if (context != null) {
            try {
                context.close();
            } catch (Exception ex) {
                log.warn("Failed to close Playwright context", ex);
            }
            context = null;
            page = null;
        }
    }
}
