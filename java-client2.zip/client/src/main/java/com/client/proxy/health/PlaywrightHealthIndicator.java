package com.client.proxy.health;

import com.client.proxy.service.PlaywrightBrowserManager;
import com.client.proxy.service.PlaywrightBrowserSession;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component
public class PlaywrightHealthIndicator implements HealthIndicator {

    private final PlaywrightBrowserManager browserManager;
    private final PlaywrightBrowserSession browserSession;

    public PlaywrightHealthIndicator(
            PlaywrightBrowserManager browserManager, PlaywrightBrowserSession browserSession) {
        this.browserManager = browserManager;
        this.browserSession = browserSession;
    }

    @Override
    public Health health() {
        if (!browserManager.isBrowserConnected()) {
            return Health.down().withDetail("browser", "disconnected").build();
        }
        if (!browserSession.isReady()) {
            return Health.down().withDetail("browser", "warming up").build();
        }
        return Health.up().withDetail("browser", "ready").build();
    }
}
