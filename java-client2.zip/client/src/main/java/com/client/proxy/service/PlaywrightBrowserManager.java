package com.client.proxy.service;

import com.client.proxy.config.PlaywrightProperties;
import com.client.proxy.exception.BrowserNotReadyException;
import com.client.proxy.exception.ProxyAutomationException;
import com.microsoft.playwright.Browser;
import com.microsoft.playwright.BrowserType;
import com.microsoft.playwright.Playwright;
import jakarta.annotation.PostConstruct;
import jakarta.annotation.PreDestroy;
import java.nio.file.Path;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class PlaywrightBrowserManager {

    private static final Logger log = LoggerFactory.getLogger(PlaywrightBrowserManager.class);

    private final PlaywrightProperties properties;
    private final Object lock = new Object();
    private Playwright playwright;
    private Browser browser;

    public PlaywrightBrowserManager(PlaywrightProperties properties) {
        this.properties = properties;
    }

    @PostConstruct
    void warmUp() {
        getBrowser();
    }

    public Browser getBrowser() {
        synchronized (lock) {
            if (browser != null && browser.isConnected()) {
                return browser;
            }
            return launchBrowser();
        }
    }

    public Browser relaunchBrowser() {
        synchronized (lock) {
            closeBrowser();
            return launchBrowser();
        }
    }

    public void invalidateBrowser() {
        synchronized (lock) {
            closeBrowser();
        }
    }

    private Browser launchBrowser() {
        try {
            if (playwright == null) {
                playwright = Playwright.create();
            }
            var options = new BrowserType.LaunchOptions().setHeadless(properties.isHeadless());
            var executable = properties.getChrome().getExecutablePath();
            if (executable != null && !executable.isBlank()) {
                options.setExecutablePath(Path.of(executable));
            }
            browser = playwright.chromium().launch(options);
            log.info("Playwright browser launched");
            return browser;
        } catch (Exception ex) {
            throw new BrowserNotReadyException("Failed to launch browser", ex);
        }
    }

    public void executeWithRetry(Runnable action) {
        try {
            action.run();
        } catch (Exception ex) {
            if (!isBrowserConnected()) {
                relaunchBrowser();
                action.run();
                return;
            }
            if (ex instanceof ProxyAutomationException proxyAutomationException) {
                throw proxyAutomationException;
            }
            if (ex instanceof BrowserNotReadyException browserNotReadyException) {
                throw browserNotReadyException;
            }
            throw new ProxyAutomationException("Browser operation failed", ex);
        }
    }

    public boolean isBrowserConnected() {
        synchronized (lock) {
            return browser != null && browser.isConnected();
        }
    }

    @PreDestroy
    void shutdown() {
        closeBrowser();
        if (playwright != null) {
            playwright.close();
            playwright = null;
        }
    }

    private void closeBrowser() {
        if (browser != null) {
            try {
                browser.close();
            } catch (Exception ex) {
                log.warn("Failed to close browser cleanly", ex);
            }
            browser = null;
        }
    }
}
