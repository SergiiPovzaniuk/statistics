package com.client.proxy.service;

import com.client.proxy.config.PlaywrightProperties;
import com.client.proxy.dto.HttpResult;
import com.client.proxy.exception.ProxyAutomationException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.microsoft.playwright.Page;
import java.util.Map;
import org.springframework.stereotype.Service;

@Service
public class PlaywrightHttpTransport {

    private final PlaywrightBrowserSession browserSession;
    private final PlaywrightProperties playwrightProperties;
    private final ObjectMapper objectMapper;

    public PlaywrightHttpTransport(
            PlaywrightBrowserSession browserSession,
            PlaywrightProperties playwrightProperties,
            ObjectMapper objectMapper) {
        this.browserSession = browserSession;
        this.playwrightProperties = playwrightProperties;
        this.objectMapper = objectMapper;
    }

    public HttpResult executeCursor(
            String operation, String path, boolean dir, Object body, boolean stream) {
        Page page = browserSession.page();
        try {
            resetResponseUi(page);
            page.locator("[data-testid='tab-cursor']").click();
            page.locator("[data-testid='cursor-op']").selectOption(operation);
            page.evaluate(
                    """
                    () => {
                      const op = document.getElementById('cursor-op');
                      op.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                    """);
            page.waitForTimeout(150);
            if (path != null && !path.isBlank()) {
                page.locator("[data-testid='cursor-path']").fill(path);
            } else {
                page.evaluate("() => { const el = document.getElementById('cursor-path'); if (el) el.value = ''; }");
            }
            if ("file-delete".equals(operation) && dir) {
                page.locator("[data-testid='cursor-dir']").check();
            }
            if (body != null) {
                page.locator("[data-testid='cursor-body']").waitFor();
                page.locator("[data-testid='cursor-body']").fill(toJson(body));
            } else {
                page.evaluate("() => { const el = document.getElementById('cursor-body'); if (el) el.value = ''; }");
            }

            String initialOutput = page.locator("[data-testid='response-output']").innerText();
            page.evaluate("() => document.getElementById('form-cursor')?.requestSubmit()");
            waitForResponse(page, initialOutput, stream);

            String statusText = page.locator("[data-testid='response-status']").innerText().trim();
            String outputText = page.locator("[data-testid='response-output']").innerText().trim();

            if (statusText.startsWith("err") || outputText.contains("\"error\"")) {
                throw new ProxyAutomationException(extractError(outputText, statusText));
            }

            if (stream) {
                return new HttpResult(200, Map.of(), null, outputText, true);
            }

            JsonNode parsed = objectMapper.readTree(outputText);
            return new HttpResult(200, Map.of(), parsed, outputText, true);
        } catch (ProxyAutomationException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new ProxyAutomationException("Failed to automate Cursor UI: " + ex.getMessage(), ex);
        }
    }

    private void waitForResponse(Page page, String initialOutput, boolean stream) {
        int timeoutMs = stream
                ? playwrightProperties.getTimeout().getChatResponseMs()
                : playwrightProperties.getTimeout().getResponseMs();
        long deadline = System.currentTimeMillis() + timeoutMs;
        String lastOutput = initialOutput;
        int stableCount = 0;

        while (System.currentTimeMillis() < deadline) {
            String status = page.locator("[data-testid='response-status']").innerText().trim();
            String output = page.locator("[data-testid='response-output']").innerText().trim();

            if (stream) {
                if (status.startsWith("err")) {
                    return;
                }
                if (hasStreamDone(output)) {
                    return;
                }
                if (status.contains("stream") && hasStreamContent(output) && !output.equals(initialOutput)) {
                    if (output.equals(lastOutput)) {
                        stableCount++;
                        if (stableCount >= 30) {
                            return;
                        }
                    } else {
                        stableCount = 0;
                        lastOutput = output;
                    }
                }
            } else if (!"...".equals(status) && !output.equals(initialOutput)) {
                return;
            }

            page.waitForTimeout(200);
        }

        if (stream && !lastOutput.equals(initialOutput)) {
            return;
        }

        throw new ProxyAutomationException("Timed out waiting for Cursor UI response");
    }

    private boolean hasStreamContent(String output) {
        return output.contains("data:")
                || output.contains("\"v\":")
                || output.contains("\"type\":");
    }

    private boolean hasStreamDone(String output) {
        return output.contains("\"type\":\"done\"")
                || output.contains("\"type\": \"done\"");
    }

    private void resetResponseUi(Page page) {
        page.evaluate(
                """
                () => {
                  const status = document.getElementById('response-status');
                  const output = document.getElementById('response-output');
                  if (status) status.textContent = '';
                  if (output) output.textContent = '{}';
                }
                """);
    }

    private String extractError(String outputText, String statusText) {
        try {
            JsonNode node = objectMapper.readTree(outputText);
            if (node.has("error")) {
                return node.get("error").asText();
            }
        } catch (Exception ignored) {
        }
        return statusText + ": " + outputText;
    }

    private String toJson(Object value) {
        try {
            return objectMapper.writeValueAsString(value);
        } catch (Exception ex) {
            throw new ProxyAutomationException("Failed to serialize JSON", ex);
        }
    }
}
