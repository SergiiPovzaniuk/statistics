package com.client.proxy.service;

import com.client.proxy.config.PlaywrightProperties;
import com.client.proxy.exception.BrowserNotReadyException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Component
@Order(0)
public class PlaywrightWarmupRunner implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(PlaywrightWarmupRunner.class);

    private final PlaywrightHttpTransport transport;
    private final PlaywrightBrowserSession browserSession;
    private final PlaywrightProperties properties;

    public PlaywrightWarmupRunner(
            PlaywrightHttpTransport transport,
            PlaywrightBrowserSession browserSession,
            PlaywrightProperties properties) {
        this.transport = transport;
        this.browserSession = browserSession;
        this.properties = properties;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (!properties.getWarmup().isProbeSession()) {
            browserSession.markReady();
            return;
        }
        log.info("Probing Playwright session at startup...");
        var result = transport.executeCursor("session", null, false, null, false);
        if (result.body() == null || !result.body().has("encryptionKey")) {
            throw new BrowserNotReadyException("Startup session probe failed");
        }
        browserSession.markReady();
    }
}
