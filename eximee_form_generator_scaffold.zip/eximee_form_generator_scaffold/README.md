# Eximee Form Generator

Spring Boot service that builds Eximee form XML from a compact JSON description (LLM-friendly).

## Why

Full Eximee XML is huge (namespaces, session vars, translation keys, spacer labels). LLMs should emit a short `FormSpec` JSON; this service expands it into valid source XML.

Relations and component properties were extracted from real forms (`example_1.xml`, `example_2.xml`).

## API

| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/forms/empty` | Empty 16-col template XML |
| GET | `/api/forms/catalog` | Component + relation catalog (feed to LLM) |
| POST | `/api/forms/generate` | Compact JSON → full Eximee XML |

## Relations (from example_2)

| Mechanism | JSON | Eximee XML |
|-----------|------|------------|
| Listen | `listenTo: ["OtherId"]` | `data:ListenField` |
| Value copy | `valueSourceId: "Upload$id$fileNames"` | `valueSourceId` attr |
| Slot mapping | `mappings: [{name, componentId\|constant}]` | `data:ComponentMapping` |
| Validator | `validators: [{name, serviceName\|inputs}]` | `data:ExternalValidator` |
| Data source | `dataSource: {name, type, inputs, outputs}` | `data:ExternalDataSource` |
| Conditions | `visibleCondition` / `requiredCondition` / `foldedCondition` | `js:...` attrs |

## example_2.xml parts → components

| Part | Components | Key props / relations |
|------|------------|------------------------|
| Page9 | Text, TextField, Upload | `mask`, `technicalField` + `valueSourceId=id$fileNames` + `listenTo`, `PAGE_SERVICE` |
| Page8 | Section, Custom, TextField | `foldedCondition`, `mappings[{name,componentId}]` + `listenTo` |
| Attachments | Upload, Custom | `maxFileSize`, `maxTotalFilesSize`, `validExtensionList` |
| Insurance | Section, RadioGroup, Radio, Checkbox, InlineTable, SingleSlider | section multi-`validators`, `visibleCondition=js:getValue(...)` |
| Pickers | Combobox, DatePicker | `searchable`, `options`, `dateRange` |
| Repeatable | RepeatableSection, Section, TextField, Upload, StepSlider, TextContent, PageNav | nested `components`, `visibleMask`, `maxValue`/`step`, `pageMid` |
| Summary | TextField | `enabledCondition=js:false` + `valueSourceId` |
| Page1 | Complex, Image, Statements, Text | `componentName`, `imageUrl`, `styleName`, checkbox-driven `visibleCondition` |

## Component types

| type | XML | Notes |
|------|-----|-------|
| `textField` | `GesTextField` | mask, visibleMask, expectedType, formatter, valueSourceId, enabledCondition, validators, dataSource |
| `text` | `GesText` | paragraph; styleName; visibleCondition |
| `upload` | `GesUploadFile` | maxFiles, requiredCount, maxFileSize, maxTotalFilesSize |
| `textContent` | `GesTextContent` | artifact via TextContentService |
| `complex` | `GesComplexComponent` | componentName |
| `custom` | `GesCustomComponent` | artifact + mappings / htmlContent |
| `section` | `GesSection` | nested components, foldedCondition, styleName, section validators |
| `repeatableSection` | `GesRepeatableSection` | nested components |
| `inlineTable` | `GesInlineTable` | nested 16-col table |
| `radioGroup` | `GesRadioGroup` | options: [{id, option, text}] |
| `radio` | `GesRadio` | via radioGroup options |
| `checkbox` | `GesCheckbox` | often span=3 inside section |
| `combobox` | `GesCombobox` | searchable + options |
| `datePicker` | `GesDatePicker` | dateRange PAST / FUTURE_WITHOUT_TODAY |
| `singleSlider` | `GesSingleSlider` | continuous |
| `stepSlider` | `GesStepSlider` | maxValue + step |
| `image` | `GesImage` | imageUrl |
| `pageNavigationLink` | `GesPageNavigationLink` | pageMid |
| `statements` | `GesStatements` | consents block |
| *(auto)* | `ns6:Label` | spacer padding to 16 columns |

## Example (relations)

```json
{
  "title": "Demo",
  "pages": [{
    "id": "Page1",
    "title": "Main",
    "components": [
      {
        "type": "textField",
        "id": "fileNames",
        "technicalField": true,
        "valueSourceId": "uploader$fileNames",
        "listenTo": ["uploader"]
      },
      { "type": "upload", "id": "uploader", "label": "Files", "requiredCount": 1, "maxFiles": 5 },
      {
        "type": "section",
        "id": "covers",
        "title": "Covers",
        "listenTo": ["oc", "ac"],
        "validators": [{
          "name": "wymaganyMinJedenCheckboxWalidator",
          "inputs": [
            { "localName": "oc", "serviceName": "oc" },
            { "localName": "ac", "serviceName": "ac" }
          ]
        }],
        "components": [
          { "type": "checkbox", "id": "oc", "label": "OC", "span": 3 },
          { "type": "checkbox", "id": "ac", "label": "AC", "span": 3 }
        ]
      },
      {
        "type": "custom",
        "id": "table",
        "artifact": "sme-comparison_table-*",
        "listenTo": ["data"],
        "mappings": [{ "name": "data", "componentId": "data" }]
      },
      { "type": "textField", "id": "data", "label": "Data" }
    ]
  }]
}
```

## Run

```bash
mvn spring-boot:run
mvn test
```
