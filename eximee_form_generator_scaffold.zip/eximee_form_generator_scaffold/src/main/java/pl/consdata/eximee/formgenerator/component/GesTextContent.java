package pl.consdata.eximee.formgenerator.component;

import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class GesTextContent extends AbstractGesComponent {

    private String artifact;

    public GesTextContent(String id) {
        this(id, id, GridData.fill(16));
    }

    public GesTextContent(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("ariaLabelKey", id + ".ariaLabel");
        attr("ariaDescriptionKey", id + ".ariaDescription");
    }

    public GesTextContent artifact(String artifact) {
        this.artifact = artifact;
        return this;
    }

    public GesTextContent printable(boolean printable) {
        if (printable) {
            attr("printable", "true");
        }
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesTextContent";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesTextContent.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.putEmpty(id + ".ariaLabel");
        translations.putEmpty(id + ".ariaDescription");
    }

    @Override
    protected void writeBody(XmlWriter xml, TranslationBag translations) {
        if (artifact == null || artifact.isBlank()) {
            return;
        }
        xml.open("data:ExternalDataSource",
                        "name=\"TextContentService\" type=\"SERVICE\" changesWidgetAttributes=\"false\" condition=\"\" version=\"*\" cacheable=\"false\"")
                .indent();
        xml.open("data:InputFields").indent();
        xml.empty("data:Field",
                "id=\"" + uuid() + "\" serviceName=\"artifact\" constantValue=\"" + XmlWriter.escape(artifact) + "\"");
        xml.outdent().close("data:InputFields");
        xml.open("data:OutputFields").indent();
        writeOutputField(xml, "name", "name");
        writeOutputField(xml, "version", "version");
        writeOutputField(xml, "content", "artifact");
        writeOutputField(xml, "autoTextFormat", "autoTextFormat");
        writeOutputField(xml, "markupType", "markupType");
        xml.outdent().close("data:OutputFields");
        xml.outdent().close("data:ExternalDataSource");
    }

    private void writeOutputField(XmlWriter xml, String localName, String serviceName) {
        xml.empty("data:Field",
                "id=\"" + uuid() + "\" localName=\"" + localName + "\" serviceName=\"" + serviceName + "\"");
    }
}
