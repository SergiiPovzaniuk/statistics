package pl.consdata.eximee.formgenerator.component;

import java.util.Arrays;
import java.util.Locale;
import java.util.Optional;

public enum ComponentType {
    TEXT_FIELD("textField", "p1:GesTextField", GesTextField.class),
    TEXT("text", "p1:GesText", GesText.class),
    UPLOAD("upload", "p1:GesUploadFile", GesUploadFile.class),
    TEXT_CONTENT("textContent", "p1:GesTextContent", GesTextContent.class),
    COMPLEX("complex", "p1:GesComplexComponent", GesComplexComponent.class),
    CUSTOM("custom", "p1:GesCustomComponent", GesCustomComponent.class),
    SECTION("section", "p1:GesSection", GesSection.class),
    REPEATABLE_SECTION("repeatableSection", "p1:GesRepeatableSection", GesRepeatableSection.class),
    INLINE_TABLE("inlineTable", "p1:GesInlineTable", GesInlineTable.class),
    RADIO_GROUP("radioGroup", "p1:GesRadioGroup", GesRadioGroup.class),
    RADIO("radio", "p1:GesRadio", GesRadio.class),
    CHECKBOX("checkbox", "p1:GesCheckbox", GesCheckbox.class),
    COMBOBOX("combobox", "p1:GesCombobox", GesCombobox.class),
    DATE_PICKER("datePicker", "p1:GesDatePicker", GesDatePicker.class),
    SINGLE_SLIDER("singleSlider", "p1:GesSingleSlider", GesSingleSlider.class),
    STEP_SLIDER("stepSlider", "p1:GesStepSlider", GesStepSlider.class),
    IMAGE("image", "p1:GesImage", GesImage.class),
    PAGE_NAVIGATION_LINK("pageNavigationLink", "p1:GesPageNavigationLink", GesPageNavigationLink.class),
    STATEMENTS("statements", "p1:GesStatements", GesStatements.class),
    SPACER("spacer", "ns6:Label", SpacerLabel.class);

    private final String apiType;
    private final String xmlElement;
    private final Class<? extends FormComponent> impl;

    ComponentType(String apiType, String xmlElement, Class<? extends FormComponent> impl) {
        this.apiType = apiType;
        this.xmlElement = xmlElement;
        this.impl = impl;
    }

    public String apiType() {
        return apiType;
    }

    public String xmlElement() {
        return xmlElement;
    }

    public Class<? extends FormComponent> impl() {
        return impl;
    }

    public static Optional<ComponentType> fromApi(String type) {
        if (type == null || type.isBlank()) {
            return Optional.empty();
        }
        String normalized = type.trim().toLowerCase(Locale.ROOT).replace("_", "");
        return Arrays.stream(values())
                .filter(t -> t.apiType.equalsIgnoreCase(type)
                        || t.apiType.equalsIgnoreCase(normalized)
                        || t.name().replace("_", "").equalsIgnoreCase(normalized)
                        || t.xmlElement.substring(t.xmlElement.indexOf(':') + 1)
                                .equalsIgnoreCase(type.replace("p1:", "").replace("ns6:", "")))
                .findFirst();
    }
}
