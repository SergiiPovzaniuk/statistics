package pl.consdata.eximee.formgenerator.component;

import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class GesPageNavigationLink extends AbstractGesComponent {

    private String text = "";
    private String pageMid;

    public GesPageNavigationLink(String id) {
        this(id, id, GridData.fill(16));
    }

    public GesPageNavigationLink(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("ariaLabelKey", id + ".ariaLabel");
        attr("ariaDescriptionKey", id + ".ariaDescription");
        attr("textKey", id + ".text");
    }

    public GesPageNavigationLink text(String text) {
        this.text = text == null ? "" : text;
        return this;
    }

    public GesPageNavigationLink pageMid(String pageMid) {
        this.pageMid = pageMid;
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesPageNavigationLink";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesPageNavigationLink.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.put(id + ".text", text);
        translations.putEmpty(id + ".ariaLabel");
        translations.putEmpty(id + ".ariaDescription");
    }

    @Override
    public void write(XmlWriter xml, TranslationBag translations) {
        if (pageMid != null) {
            attr("pageMid", pageMid);
        }
        super.write(xml, translations);
    }
}
