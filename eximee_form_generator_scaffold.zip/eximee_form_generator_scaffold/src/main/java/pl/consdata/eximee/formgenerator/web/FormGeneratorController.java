package pl.consdata.eximee.formgenerator.web;

import java.util.Map;
import jakarta.validation.Valid;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pl.consdata.eximee.formgenerator.catalog.ComponentCatalog;
import pl.consdata.eximee.formgenerator.dto.FormSpec;
import pl.consdata.eximee.formgenerator.service.EmptyTemplateGenerator;
import pl.consdata.eximee.formgenerator.service.FormGeneratorService;

@RestController
@RequestMapping("/api/forms")
public class FormGeneratorController {

    private final EmptyTemplateGenerator emptyTemplateGenerator;
    private final FormGeneratorService formGeneratorService;

    public FormGeneratorController(
            EmptyTemplateGenerator emptyTemplateGenerator,
            FormGeneratorService formGeneratorService) {
        this.emptyTemplateGenerator = emptyTemplateGenerator;
        this.formGeneratorService = formGeneratorService;
    }

    @GetMapping(value = "/empty", produces = MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity<String> generateEmptyTemplate() {
        return xmlAttachment(emptyTemplateGenerator.generate(), "empty_template.xml");
    }

    @PostMapping(value = "/generate", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_XML_VALUE)
    public ResponseEntity<String> generateFromSpec(@Valid @RequestBody FormSpec spec) {
        return xmlAttachment(formGeneratorService.generate(spec), "form.xml");
    }

    @GetMapping(value = "/catalog", produces = MediaType.APPLICATION_JSON_VALUE)
    public Map<String, Object> catalog() {
        return ComponentCatalog.catalog();
    }

    private ResponseEntity<String> xmlAttachment(String xml, String filename) {
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + filename + "\"")
                .contentType(MediaType.APPLICATION_XML)
                .body(xml);
    }
}
