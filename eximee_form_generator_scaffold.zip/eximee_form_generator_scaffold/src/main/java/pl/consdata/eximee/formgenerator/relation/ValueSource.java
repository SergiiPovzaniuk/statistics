package pl.consdata.eximee.formgenerator.relation;

/**
 * Binds a field value from another component property.
 * Eximee syntax: {@code componentId$property} e.g. {@code GesUploadFile3$fileNames}.
 */
public record ValueSource(String componentId, String property) {

    public static ValueSource parse(String valueSourceId) {
        if (valueSourceId == null || valueSourceId.isBlank()) {
            throw new IllegalArgumentException("valueSourceId is blank");
        }
        int sep = valueSourceId.indexOf('$');
        if (sep < 0) {
            return new ValueSource(valueSourceId, null);
        }
        return new ValueSource(valueSourceId.substring(0, sep), valueSourceId.substring(sep + 1));
    }

    public String toValueSourceId() {
        if (property == null || property.isBlank()) {
            return componentId;
        }
        return componentId + "$" + property;
    }
}
