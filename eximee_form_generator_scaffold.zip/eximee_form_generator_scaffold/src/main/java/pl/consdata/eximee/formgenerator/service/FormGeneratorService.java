package pl.consdata.eximee.formgenerator.service;

import org.springframework.stereotype.Service;
import pl.consdata.eximee.formgenerator.dto.FormSpec;

@Service
public class FormGeneratorService {

    private final FormSpecMapper mapper;
    private final FormXmlRenderer renderer;

    public FormGeneratorService(FormSpecMapper mapper, FormXmlRenderer renderer) {
        this.mapper = mapper;
        this.renderer = renderer;
    }

    public String generate(FormSpec spec) {
        return renderer.render(mapper.toDefinition(spec));
    }
}
