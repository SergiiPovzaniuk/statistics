package pl.consdata.eximee.formgenerator.component;

import pl.consdata.eximee.formgenerator.xml.TranslationBag;

public final class GesUploadFile extends AbstractGesComponent {

    private String label = "";
    private String buttonLabel = "";
    private String description = "";

    public GesUploadFile(String id) {
        this(id, id, GridData.fill(16));
    }

    public GesUploadFile(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("labelKey", id + ".label");
        attr("ariaLabelKey", id + ".ariaLabel");
        attr("ariaDescriptionKey", id + ".ariaDescription");
        attr("requiredCountErrorKey", id + ".requiredCountError");
        attr("validExtensionList", "JPG, JPEG, PNG, PDF, GIF");
        attr("showExtensionList", "true");
        attr("buttonLabelKey", id + ".buttonLabel");
        attr("numberOfUploadingFiles", "5");
        attr("descriptionKey", id + ".description");
        attr("allowedFilenameRegexp", "^.{1,50}$");
    }

    public GesUploadFile label(String label) {
        this.label = label;
        return this;
    }

    public GesUploadFile buttonLabel(String buttonLabel) {
        this.buttonLabel = buttonLabel;
        return this;
    }

    public GesUploadFile description(String description) {
        this.description = description;
        return this;
    }

    public GesUploadFile extensions(String extensions) {
        attr("validExtensionList", extensions);
        return this;
    }

    public GesUploadFile maxFiles(int maxFiles) {
        attr("numberOfUploadingFiles", Integer.toString(maxFiles));
        return this;
    }

    public GesUploadFile requiredCount(int requiredCount) {
        attr("requiredCount", Integer.toString(requiredCount));
        return this;
    }

    public GesUploadFile maxFileSize(int maxFileSizeKb) {
        attr("maxFileSize", Integer.toString(maxFileSizeKb));
        return this;
    }

    public GesUploadFile maxTotalFilesSize(int maxTotalFilesSizeKb) {
        attr("maxTotalFilesSize", Integer.toString(maxTotalFilesSizeKb));
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesUploadFile";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesUploadFile.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.put(id + ".label", label);
        translations.put(id + ".buttonLabel", buttonLabel);
        translations.put(id + ".description", description);
        translations.putEmpty(id + ".ariaLabel");
        translations.putEmpty(id + ".ariaDescription");
        translations.putEmpty(id + ".requiredCountError");
    }
}
