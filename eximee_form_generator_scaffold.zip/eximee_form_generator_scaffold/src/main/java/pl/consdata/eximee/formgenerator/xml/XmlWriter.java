package pl.consdata.eximee.formgenerator.xml;

public final class XmlWriter {

    private final StringBuilder out = new StringBuilder();
    private int indent;

    public XmlWriter indent() {
        indent++;
        return this;
    }

    public XmlWriter outdent() {
        indent = Math.max(0, indent - 1);
        return this;
    }

    public XmlWriter line(String content) {
        out.append("  ".repeat(indent)).append(content).append('\n');
        return this;
    }

    public XmlWriter open(String tag) {
        return line("<" + tag + ">");
    }

    public XmlWriter open(String tag, String attributes) {
        return line("<" + tag + " " + attributes + ">");
    }

    public XmlWriter empty(String tag) {
        return line("<" + tag + "/>");
    }

    public XmlWriter empty(String tag, String attributes) {
        return line("<" + tag + " " + attributes + "/>");
    }

    public XmlWriter close(String tag) {
        return line("</" + tag + ">");
    }

    public XmlWriter text(String tag, String value) {
        return line("<" + tag + ">" + escape(value) + "</" + tag + ">");
    }

    public static String escape(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        return value
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }

    public static String attr(String name, String value) {
        if (value == null) {
            return "";
        }
        return " " + name + "=\"" + escape(value) + "\"";
    }

    public static String attr(String name, int value) {
        return attr(name, Integer.toString(value));
    }

    @Override
    public String toString() {
        String s = out.toString();
        return s.endsWith("\n") ? s.substring(0, s.length() - 1) : s;
    }
}
