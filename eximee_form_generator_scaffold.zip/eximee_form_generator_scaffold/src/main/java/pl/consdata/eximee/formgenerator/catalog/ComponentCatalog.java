package pl.consdata.eximee.formgenerator.catalog;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ComponentCatalog {

    private ComponentCatalog() {}

    public static Map<String, Object> catalog() {
        Map<String, Object> catalog = new LinkedHashMap<>();
        catalog.put("grid", Map.of("columns", 16, "spacer", "ns6:Label auto-padded to fill row"));
        catalog.put("source", "example_1.xml + example_2.xml");
        catalog.put("example2Parts", example2Parts());
        catalog.put("relations", relations());
        catalog.put("components", components());
        catalog.put("examples", examples());
        return catalog;
    }

    /** Page-by-page decomposition of example_2.xml → component inventory. */
    private static List<Map<String, Object>> example2Parts() {
        return List.of(
                part("Page9", "upload + mask + page service", List.of(
                        "GesText span=11",
                        "GesTextField mask=name-regex",
                        "GesTextField technical + valueSourceId=Upload$fileNames + listenTo",
                        "GesUploadFile requiredCount/maxFiles",
                        "GesTextField span=12 + dataSource PAGE_SERVICE")),
                part("Page8", "section + custom slot mapping", List.of(
                        "GesSection foldedCondition=js:true",
                        "GesCustomComponent artifact + listenTo + ComponentMapping(componentId)",
                        "GesTextField mid=data (source for custom slot)")),
                part("Attachments block", "upload limits + custom list", List.of(
                        "GesTextField",
                        "GesCustomComponent sme_printout_download-*",
                        "GesUploadFile maxFileSize/maxTotalFilesSize/extensions",
                        "GesCustomComponent sme-lista_zalacznikow-*")),
                part("Insurance choices", "radio/checkbox sections + cross-field validator", List.of(
                        "GesSection > GesRadioGroup > GesRadio (defaultValue)",
                        "GesSection > GesCheckbox×4 span=3 + section listenTo + multi-input validator",
                        "GesSection > GesRadioGroup option true/false",
                        "GesInlineTable",
                        "GesSection visibleCondition=js:getValue(Radio)===true > GesSingleSlider")),
                part("Pickers", "combobox + date", List.of(
                        "GesSection > GesCombobox searchable + options",
                        "GesSection > GesDatePicker dateRange=FUTURE_WITHOUT_TODAY")),
                part("Repeatable applicant", "nested sections in repeatable", List.of(
                        "GesRepeatableSection > GesSection×N",
                        "GesTextField + PESEL ExternalValidator",
                        "GesTextField visibleMask=99-999",
                        "GesSection > GesUploadFile",
                        "GesSection > GesStepSlider maxValue/step",
                        "GesTextContent artifact",
                        "GesPageNavigationLink pageMid")),
                part("Summary", "read-only value copies", List.of(
                        "GesTextField enabledCondition=js:false + valueSourceId=mid + listenTo")),
                part("Page1 extras", "complex/image/statements/conditions", List.of(
                        "GesComplexComponent componentName",
                        "GesRepeatableSection > GesCheckbox",
                        "GesSection > GesTextField + GesImage imageUrl + GesCheckbox",
                        "GesText visibleCondition=js:getValue(Checkbox)===true + listenTo",
                        "GesSection > GesDatePicker dateRange=PAST + startViewMode + disabledInputTyping",
                        "GesSection > GesStatements",
                        "GesText styleName=ribbon-success"))
        );
    }

    private static Map<String, Object> part(String id, String focus, List<String> components) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id);
        m.put("focus", focus);
        m.put("components", components);
        return m;
    }

    private static List<Map<String, Object>> relations() {
        return List.of(
                rel("listenTo", "data:ListeningOn/data:ListenField",
                        "Re-evaluate when listed ids change. Pair with valueSourceId / mappings / validators.",
                        Map.of("listenTo", List.of("GesUploadFile3"))),
                rel("valueSourceId", "attr valueSourceId",
                        "Copy value from componentId or componentId$property.",
                        Map.of("valueSourceId", "GesUploadFile3$fileNames", "listenTo", List.of("GesUploadFile3"),
                                "technicalField", true)),
                rel("inputMapping", "data:CustomComponentInputMapping/data:ComponentMapping",
                        "Feed custom slot from componentId or constant HTML.",
                        Map.of("mappings", List.of(Map.of("name", "data", "componentId", "GesTextField11")))),
                rel("validator", "data:ExternalValidators",
                        "VALIDATION_SCRIPT. Single-field: serviceName. Multi-field: inputs[].",
                        Map.of("validators", List.of(Map.of(
                                "name", "wymaganyMinJedenCheckboxWalidator",
                                "inputs", List.of(
                                        Map.of("localName", "GesCheckbox2", "serviceName", "oc", "nullable", false),
                                        Map.of("localName", "GesCheckbox3", "serviceName", "ac", "nullable", false)))))),
                rel("dataSource", "data:ExternalDataSource",
                        "SERVICE | SCRIPT_SERVICE | PAGE_SERVICE with inputs/outputs fields.",
                        Map.of("dataSource", Map.of(
                                "name", "PageService5",
                                "type", "PAGE_SERVICE",
                                "outputs", List.of(Map.of("localName", "text", "serviceName", "validationResultMessages"))))),
                rel("conditions", "visibleCondition|requiredCondition|foldedCondition",
                        "js:true / js:false / empty string.",
                        Map.of("visibleCondition", "js:false", "requiredCondition", "js:true",
                                "foldedCondition", "js:true"))
        );
    }

    private static List<Map<String, Object>> components() {
        return List.of(
                type("textField", "p1:GesTextField",
                        List.of("id", "mid", "label", "span", "expectedType", "formatter", "mask", "visibleMask",
                                "valueSourceId", "visibleCondition", "requiredCondition", "enabledCondition",
                                "technicalField", "listenTo", "validators", "dataSource"),
                        "mask regex; visibleMask=99-999; EMAIL via expectedType; PESEL/NRB via validators; PAGE_SERVICE"),
                type("text", "p1:GesText",
                        List.of("id", "mid", "label", "text", "span", "styleName", "visibleCondition", "listenTo"),
                        "Paragraph; styleName=ribbon-success; often span 8–11 then spacers"),
                type("upload", "p1:GesUploadFile",
                        List.of("id", "mid", "label", "span", "extensions", "maxFiles", "requiredCount",
                                "maxFileSize", "maxTotalFilesSize", "buttonLabel", "description"),
                        "Expose names: valueSourceId = id$fileNames on a technical textField"),
                type("textContent", "p1:GesTextContent",
                        List.of("id", "mid", "artifact", "span", "printable"),
                        "CMS via TextContentService"),
                type("complex", "p1:GesComplexComponent",
                        List.of("id", "mid", "componentName", "span"),
                        "Reusable bundle by componentName"),
                type("custom", "p1:GesCustomComponent",
                        List.of("id", "mid", "artifact", "span", "htmlContent", "mappings", "listenTo"),
                        "Artifact widget; listenTo + mappings for live slots"),
                type("section", "p1:GesSection",
                        List.of("id", "mid", "title", "span", "foldedCondition", "visibleCondition", "styleName",
                                "components", "listenTo", "validators"),
                        "Nested 16-col container; section-level multi-input validators"),
                type("radioGroup", "p1:GesRadioGroup",
                        List.of("id", "mid", "label", "title", "span", "defaultValue", "options"),
                        "options: [{id, option, text}] → GesRadio children"),
                type("radio", "p1:GesRadio",
                        List.of("id", "mid", "option", "text", "span"),
                        "Child of radioGroup only (created via options[])"),
                type("checkbox", "p1:GesCheckbox",
                        List.of("id", "mid", "label", "text", "span", "listenTo"),
                        "Default span 3; group under section + multi validator"),
                type("combobox", "p1:GesCombobox",
                        List.of("id", "mid", "label", "description", "span", "searchable", "options"),
                        "options: [{option, text}]"),
                type("datePicker", "p1:GesDatePicker",
                        List.of("id", "mid", "label", "span", "dateRange", "startViewMode",
                                "defaultValueOnToday", "disabledInputTyping", "dataSource"),
                        "dateRange: PAST | FUTURE_WITHOUT_TODAY"),
                type("singleSlider", "p1:GesSingleSlider",
                        List.of("id", "mid", "label", "span"),
                        "Continuous value slider"),
                type("stepSlider", "p1:GesStepSlider",
                        List.of("id", "mid", "label", "description", "span", "maxValue", "step"),
                        "Stepped slider e.g. maxValue=100 step=10"),
                type("image", "p1:GesImage",
                        List.of("id", "mid", "imageUrl", "span"),
                        "Static image by URL"),
                type("pageNavigationLink", "p1:GesPageNavigationLink",
                        List.of("id", "mid", "text", "pageMid", "span"),
                        "Jump to pageMid"),
                type("statements", "p1:GesStatements",
                        List.of("id", "mid", "label", "span"),
                        "Consent / statements master checkbox block"),
                type("repeatableSection", "p1:GesRepeatableSection",
                        List.of("id", "mid", "label", "toolTipText", "printable", "span", "components"),
                        "Repeatable nested container (often holds sections)"),
                type("inlineTable", "p1:GesInlineTable",
                        List.of("id", "mid", "title", "span", "components"),
                        "Inline table container with 16-col layout"),
                type("spacer", "ns6:Label",
                        List.of(),
                        "Auto-inserted to pad rows to 16 columns")
        );
    }

    private static List<Map<String, Object>> examples() {
        return List.of(
                Map.of(
                        "id", "upload_to_technical_field",
                        "from", "example_2 Page9",
                        "spec", Map.of(
                                "type", "textField",
                                "id", "GesTextField14",
                                "mid", "fileNamesPT",
                                "technicalField", true,
                                "valueSourceId", "GesUploadFile3$fileNames",
                                "listenTo", List.of("GesUploadFile3"))),
                Map.of(
                        "id", "custom_slot_from_field",
                        "from", "example_2 Page8 GesCustomComponent7",
                        "spec", Map.of(
                                "type", "custom",
                                "id", "GesCustomComponent7",
                                "artifact", "sme-comparison_table-*",
                                "listenTo", List.of("GesTextField11"),
                                "mappings", List.of(Map.of("name", "data", "componentId", "GesTextField11")))),
                Map.of(
                        "id", "section_min_one_checkbox",
                        "from", "example_2 GesSection5",
                        "spec", Map.of(
                                "type", "section",
                                "id", "GesSection5",
                                "title", "Covers",
                                "foldedCondition", "js:true",
                                "listenTo", List.of("GesCheckbox2", "GesCheckbox3", "GesCheckbox4", "GesCheckbox5"),
                                "validators", List.of(Map.of(
                                        "name", "wymaganyMinJedenCheckboxWalidator",
                                        "inputs", List.of(
                                                Map.of("localName", "GesCheckbox2", "serviceName", "oc"),
                                                Map.of("localName", "GesCheckbox3", "serviceName", "ac"),
                                                Map.of("localName", "GesCheckbox4", "serviceName", "nnw"),
                                                Map.of("localName", "GesCheckbox5", "serviceName", "assistance")))),
                                "components", List.of(
                                        Map.of("type", "checkbox", "id", "GesCheckbox2", "mid", "oc", "label", "OC", "span", 3),
                                        Map.of("type", "checkbox", "id", "GesCheckbox3", "mid", "ac", "label", "AC", "span", 3),
                                        Map.of("type", "checkbox", "id", "GesCheckbox4", "mid", "nnw", "label", "NNW", "span", 3),
                                        Map.of("type", "checkbox", "id", "GesCheckbox5", "mid", "assistance", "label", "Assistance", "span", 3)))),
                Map.of(
                        "id", "page_service_field",
                        "from", "example_2 GesTextField15",
                        "spec", Map.of(
                                "type", "textField",
                                "id", "GesTextField15",
                                "span", 12,
                                "dataSource", Map.of(
                                        "name", "PageService5",
                                        "type", "PAGE_SERVICE",
                                        "outputs", List.of(Map.of(
                                                "localName", "text",
                                                "serviceName", "validationResultMessages"))))),
                Map.of(
                        "id", "masked_name",
                        "from", "example_2 GesTextField16",
                        "spec", Map.of(
                                "type", "textField",
                                "id", "GesTextField16",
                                "mask", "^[a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ']([a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ' -]*[a-zA-ZąćęłńóśźżĄĆĘŁŃÓŚŹŻ'])?$")),
                Map.of(
                        "id", "radio_in_section",
                        "from", "example_2 GesSection4",
                        "spec", Map.of(
                                "type", "radioGroup",
                                "id", "GesRadioGroup1",
                                "defaultValue", "1",
                                "options", List.of(
                                        Map.of("id", "GesRadio1", "option", "1", "text", "Yes"),
                                        Map.of("id", "GesRadio2", "option", "2", "text", "No")))),
                Map.of(
                        "id", "conditional_section_on_radio",
                        "from", "example_2 GesSection16",
                        "spec", Map.of(
                                "type", "section",
                                "id", "GesSection16",
                                "visibleCondition", "js:getValue(\"GesRadioGroup2\")===\"true\"",
                                "foldedCondition", "js:true",
                                "components", List.of(Map.of("type", "singleSlider", "id", "GesSingleSlider1")))),
                Map.of(
                        "id", "summary_readonly_copy",
                        "from", "example_2 summaryPesel",
                        "spec", Map.of(
                                "type", "textField",
                                "id", "GesTextField6",
                                "mid", "summaryPesel",
                                "enabledCondition", "js:false",
                                "valueSourceId", "pesel",
                                "listenTo", List.of("pesel"))),
                Map.of(
                        "id", "repeatable_with_nested_sections",
                        "from", "example_2 GesRepeatableSection1",
                        "spec", Map.of(
                                "type", "repeatableSection",
                                "id", "GesRepeatableSection1",
                                "components", List.of(
                                        Map.of("type", "section", "id", "GesSection10", "styleName", "ribbon-success",
                                                "components", List.of(
                                                        Map.of("type", "text", "id", "GesText5", "text", "Header"),
                                                        Map.of("type", "textField", "id", "GesTextField2", "label", "Name")))))),
                Map.of(
                        "id", "date_past_picker",
                        "from", "example_2 GesDatePicker1",
                        "spec", Map.of(
                                "type", "datePicker",
                                "id", "GesDatePicker1",
                                "dateRange", "PAST",
                                "startViewMode", "MULTI-YEAR",
                                "disabledInputTyping", true,
                                "defaultValueOnToday", false))
        );
    }

    private static Map<String, Object> rel(String id, String xml, String desc, Map<String, Object> example) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", id);
        m.put("xml", xml);
        m.put("desc", desc);
        m.put("example", example);
        return m;
    }

    private static Map<String, Object> type(String type, String xml, List<String> props, String desc) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("type", type);
        m.put("xml", xml);
        m.put("props", props);
        m.put("desc", desc);
        return m;
    }
}
