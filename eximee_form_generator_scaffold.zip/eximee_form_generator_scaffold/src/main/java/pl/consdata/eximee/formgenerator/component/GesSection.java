package pl.consdata.eximee.formgenerator.component;

import java.util.ArrayList;
import java.util.List;
import pl.consdata.eximee.formgenerator.model.FormPage;
import pl.consdata.eximee.formgenerator.relation.ValidatorBinding;
import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class GesSection extends AbstractGesComponent {

    private final List<FormComponent> children = new ArrayList<>();
    private final List<ValidatorBinding> validators = new ArrayList<>();
    private String title = "";
    private String foldLabel = "";
    private String unfoldLabel = "";
    private String foldedCondition = "js:true";

    public GesSection(String id) {
        this(id, id, GridData.fill(16));
    }

    public GesSection(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("ariaLabelKey", id + ".ariaLabel");
        attr("ariaDescriptionKey", id + ".ariaDescription");
        attr("inheritLayout", "true");
        attr("titleKey", id + ".title");
        attr("foldLabelKey", id + ".foldLabel");
        attr("unfoldLabelKey", id + ".unfoldLabel");
    }

    public GesSection title(String title) {
        this.title = title == null ? "" : title;
        return this;
    }

    public GesSection foldedCondition(String foldedCondition) {
        this.foldedCondition = foldedCondition;
        return this;
    }

    @Override
    public GesSection visibleCondition(String visibleCondition) {
        super.visibleCondition(visibleCondition);
        return this;
    }

    @Override
    public GesSection styleName(String styleName) {
        super.styleName(styleName);
        return this;
    }

    public GesSection foldLabels(String fold, String unfold) {
        this.foldLabel = fold == null ? "" : fold;
        this.unfoldLabel = unfold == null ? "" : unfold;
        return this;
    }

    public GesSection add(FormComponent child) {
        children.add(child);
        return this;
    }

    public GesSection validator(ValidatorBinding validator) {
        validators.add(validator);
        return this;
    }

    @Override
    public GesSection listenTo(String fieldId) {
        super.listenTo(fieldId);
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesSection";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesSection.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.put(id + ".title", title);
        translations.put(id + ".foldLabel", foldLabel);
        translations.put(id + ".unfoldLabel", unfoldLabel);
        translations.putEmpty(id + ".ariaLabel");
        translations.putEmpty(id + ".ariaDescription");
    }

    @Override
    public void write(XmlWriter xml, TranslationBag translations) {
        if (foldedCondition != null) {
            attr("foldedCondition", foldedCondition);
        }
        registerTranslations(translations);
        StringBuilder attrs = new StringBuilder();
        attrs.append(XmlWriter.attr("id", id));
        attrs.append(XmlWriter.attr("mid", mid));
        attributes.forEach((k, v) -> attrs.append(XmlWriter.attr(k, v)));
        xml.open(elementName(), attrs.toString().trim()).indent();

        int usedInRow = 0;
        for (FormComponent child : children) {
            child.write(xml, translations);
            usedInRow += child.horizontalSpan();
            if (usedInRow >= FormPage.COLUMNS) {
                usedInRow = 0;
            }
        }
        int remaining = usedInRow == 0 ? 0 : FormPage.COLUMNS - usedInRow;
        for (int i = 0; i < remaining; i++) {
            new SpacerLabel().write(xml, translations);
        }

        writeListeningOn(xml);
        xml.empty("data:ClearOn");
        ValidatorBinding.writeAll(xml, validators);
        layout.write(xml, layoutDataTag());
        xml.open("p1:GesSection.layout").indent();
        xml.empty("ns6:GridLayout", "makeColumnsEqualWidth=\"true\" numColumns=\"" + FormPage.COLUMNS + "\"");
        xml.outdent().close("p1:GesSection.layout");
        xml.empty("data:SectionDynamicTitles");
        xml.outdent().close(elementName());
    }
}
