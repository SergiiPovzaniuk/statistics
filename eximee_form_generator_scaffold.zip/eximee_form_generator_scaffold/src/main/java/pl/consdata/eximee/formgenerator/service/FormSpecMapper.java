package pl.consdata.eximee.formgenerator.service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Consumer;
import org.springframework.stereotype.Service;
import pl.consdata.eximee.formgenerator.component.FormComponent;
import pl.consdata.eximee.formgenerator.component.GesCheckbox;
import pl.consdata.eximee.formgenerator.component.GesCombobox;
import pl.consdata.eximee.formgenerator.component.GesComplexComponent;
import pl.consdata.eximee.formgenerator.component.GesCustomComponent;
import pl.consdata.eximee.formgenerator.component.GesDatePicker;
import pl.consdata.eximee.formgenerator.component.GesImage;
import pl.consdata.eximee.formgenerator.component.GesInlineTable;
import pl.consdata.eximee.formgenerator.component.GesPageNavigationLink;
import pl.consdata.eximee.formgenerator.component.GesRadioGroup;
import pl.consdata.eximee.formgenerator.component.GesRepeatableSection;
import pl.consdata.eximee.formgenerator.component.GesSection;
import pl.consdata.eximee.formgenerator.component.GesSingleSlider;
import pl.consdata.eximee.formgenerator.component.GesStatements;
import pl.consdata.eximee.formgenerator.component.GesStepSlider;
import pl.consdata.eximee.formgenerator.component.GesText;
import pl.consdata.eximee.formgenerator.component.GesTextContent;
import pl.consdata.eximee.formgenerator.component.GesTextField;
import pl.consdata.eximee.formgenerator.component.GesUploadFile;
import pl.consdata.eximee.formgenerator.component.GridData;
import pl.consdata.eximee.formgenerator.dto.FormSpec;
import pl.consdata.eximee.formgenerator.dto.FormSpec.ComponentSpec;
import pl.consdata.eximee.formgenerator.dto.FormSpec.DataFieldSpec;
import pl.consdata.eximee.formgenerator.dto.FormSpec.DataSourceSpec;
import pl.consdata.eximee.formgenerator.dto.FormSpec.MappingSpec;
import pl.consdata.eximee.formgenerator.dto.FormSpec.OptionSpec;
import pl.consdata.eximee.formgenerator.dto.FormSpec.PageSpec;
import pl.consdata.eximee.formgenerator.dto.FormSpec.ValidatorInputSpec;
import pl.consdata.eximee.formgenerator.dto.FormSpec.ValidatorSpec;
import pl.consdata.eximee.formgenerator.model.FormDefinition;
import pl.consdata.eximee.formgenerator.model.FormPage;
import pl.consdata.eximee.formgenerator.relation.DataSourceBinding;
import pl.consdata.eximee.formgenerator.relation.InputMapping;
import pl.consdata.eximee.formgenerator.relation.ValidatorBinding;

@Service
public class FormSpecMapper {

    public FormDefinition toDefinition(FormSpec spec) {
        AtomicInteger seq = new AtomicInteger();
        FormDefinition form = new FormDefinition().title(spec.title());
        for (PageSpec pageSpec : spec.pages()) {
            FormPage page = new FormPage(pageSpec.id(), pageSpec.title(), pageSpec.nextButton());
            for (ComponentSpec componentSpec : pageSpec.components()) {
                page.add(toComponent(componentSpec, seq));
            }
            form.addPage(page);
        }
        return form;
    }

    private FormComponent toComponent(ComponentSpec spec, AtomicInteger seq) {
        String type = spec.type().trim().toLowerCase();
        String id = spec.id() != null && !spec.id().isBlank() ? spec.id() : type + seq.incrementAndGet();
        String mid = spec.mid() != null && !spec.mid().isBlank() ? spec.mid() : id;
        int span = spec.span() == null ? 16 : spec.span();
        GridData layout = GridData.fill(span);

        return switch (type) {
            case "textfield", "gestextfield", "ges_text_field" -> textField(id, mid, layout, spec);
            case "text", "gestext", "ges_text" -> text(id, mid, layout, spec);
            case "upload", "uploadfile", "gesuploadfile" -> upload(id, mid, layout, spec);
            case "textcontent", "gestextcontent" -> textContent(id, mid, layout, spec);
            case "complex", "gescomplexcomponent" -> complex(id, mid, layout, spec);
            case "custom", "gescustomcomponent" -> custom(id, mid, layout, spec);
            case "section", "gessection" -> section(id, mid, layout, spec, seq);
            case "repeatablesection", "gesrepeatablesection" -> repeatableSection(id, mid, layout, spec, seq);
            case "inlinetable", "gesinlinetable" -> inlineTable(id, mid, layout, spec, seq);
            case "radiogroup", "gesradiogroup" -> radioGroup(id, mid, layout, spec);
            case "checkbox", "gescheckbox" -> checkbox(id, mid, layout, spec);
            case "combobox", "gescombobox" -> combobox(id, mid, layout, spec);
            case "datepicker", "gesdatepicker" -> datePicker(id, mid, layout, spec);
            case "singleslider", "gessingleslider" -> singleSlider(id, mid, layout, spec);
            case "stepslider", "gesstepslider" -> stepSlider(id, mid, layout, spec);
            case "image", "gesimage" -> image(id, mid, layout, spec);
            case "pagenavigationlink", "gespagenavigationlink" -> pageNav(id, mid, layout, spec);
            case "statements", "gesstatements" -> statements(id, mid, layout, spec);
            default -> throw new IllegalArgumentException("Unknown component type: " + spec.type());
        };
    }

    private FormComponent textField(String id, String mid, GridData layout, ComponentSpec spec) {
        GesTextField field = new GesTextField(id, mid, layout).label(nullToEmpty(spec.label()));
        if (spec.expectedType() != null) {
            field.expectedType(spec.expectedType());
        }
        if (spec.formatter() != null) {
            field.formatter(spec.formatter());
        }
        if (spec.mask() != null) {
            field.mask(spec.mask());
        }
        if (spec.valueSourceId() != null) {
            field.valueSourceId(spec.valueSourceId());
        }
        if (spec.visibleCondition() != null) {
            field.visibleCondition(spec.visibleCondition());
        }
        if (spec.requiredCondition() != null) {
            field.requiredCondition(spec.requiredCondition());
        }
        if (spec.enabledCondition() != null) {
            field.enabledCondition(spec.enabledCondition());
        }
        if (spec.visibleMask() != null) {
            field.visibleMask(spec.visibleMask());
        }
        if (Boolean.TRUE.equals(spec.technicalField())) {
            field.technicalField(true);
        }
        forEachListen(spec, field::listenTo);
        if (spec.validators() != null) {
            for (ValidatorSpec validator : spec.validators()) {
                String serviceName = validator.serviceName() != null ? validator.serviceName() : "value";
                field.validator(validator.name(), serviceName);
            }
        }
        if (spec.dataSource() != null) {
            field.dataSource(toDataSource(spec.dataSource()));
        }
        return field;
    }

    private FormComponent text(String id, String mid, GridData layout, ComponentSpec spec) {
        GesText text = new GesText(id, mid, layout)
                .label(nullToEmpty(spec.label()))
                .text(nullToEmpty(spec.text()));
        if (spec.visibleCondition() != null) {
            text.visibleCondition(spec.visibleCondition());
        }
        if (spec.styleName() != null) {
            text.styleName(spec.styleName());
        }
        forEachListen(spec, text::listenTo);
        return text;
    }

    private FormComponent upload(String id, String mid, GridData layout, ComponentSpec spec) {
        GesUploadFile upload = new GesUploadFile(id, mid, layout)
                .label(nullToEmpty(spec.label()))
                .buttonLabel(nullToEmpty(spec.buttonLabel()))
                .description(nullToEmpty(spec.description()));
        if (spec.extensions() != null) {
            upload.extensions(spec.extensions());
        }
        if (spec.maxFiles() != null) {
            upload.maxFiles(spec.maxFiles());
        }
        if (spec.requiredCount() != null) {
            upload.requiredCount(spec.requiredCount());
        }
        if (spec.maxFileSize() != null) {
            upload.maxFileSize(spec.maxFileSize());
        }
        if (spec.maxTotalFilesSize() != null) {
            upload.maxTotalFilesSize(spec.maxTotalFilesSize());
        }
        return upload;
    }

    private FormComponent textContent(String id, String mid, GridData layout, ComponentSpec spec) {
        GesTextContent content = new GesTextContent(id, mid, layout).artifact(spec.artifact());
        if (Boolean.TRUE.equals(spec.printable())) {
            content.printable(true);
        }
        return content;
    }

    private FormComponent complex(String id, String mid, GridData layout, ComponentSpec spec) {
        if (spec.componentName() == null || spec.componentName().isBlank()) {
            throw new IllegalArgumentException("complex requires componentName");
        }
        return new GesComplexComponent(id, mid, spec.componentName(), GridData.spanOnly(layout.horizontalSpan()));
    }

    private FormComponent custom(String id, String mid, GridData layout, ComponentSpec spec) {
        if (spec.artifact() == null || spec.artifact().isBlank()) {
            throw new IllegalArgumentException("custom requires artifact");
        }
        GesCustomComponent custom = new GesCustomComponent(id, mid, spec.artifact(), layout);
        if (spec.htmlContent() != null) {
            custom.htmlContent(spec.htmlContent());
        }
        forEachListen(spec, custom::listenTo);
        if (spec.mappings() != null) {
            for (MappingSpec mapping : spec.mappings()) {
                if (mapping.componentId() != null && !mapping.componentId().isBlank()) {
                    custom.mapping(InputMapping.fromComponent(mapping.name(), mapping.componentId()));
                } else {
                    custom.mapping(InputMapping.fromConstant(mapping.name(), mapping.constant()));
                }
            }
        }
        return custom;
    }

    private FormComponent section(String id, String mid, GridData layout, ComponentSpec spec, AtomicInteger seq) {
        GesSection section = new GesSection(id, mid, layout).title(nullToEmpty(spec.title()));
        if (spec.foldedCondition() != null) {
            section.foldedCondition(spec.foldedCondition());
        }
        if (spec.visibleCondition() != null) {
            section.visibleCondition(spec.visibleCondition());
        }
        if (spec.styleName() != null) {
            section.styleName(spec.styleName());
        }
        forEachListen(spec, section::listenTo);
        if (spec.validators() != null) {
            for (ValidatorSpec validator : spec.validators()) {
                section.validator(toValidator(validator, id));
            }
        }
        if (spec.components() != null) {
            for (ComponentSpec child : spec.components()) {
                section.add(toComponent(child, seq));
            }
        }
        return section;
    }

    private FormComponent radioGroup(String id, String mid, GridData layout, ComponentSpec spec) {
        GesRadioGroup group = new GesRadioGroup(id, mid, layout)
                .label(nullToEmpty(spec.label()))
                .title(nullToEmpty(spec.title()));
        if (spec.defaultValue() != null) {
            group.defaultValue(spec.defaultValue());
        }
        if (spec.options() != null) {
            int i = 0;
            for (OptionSpec option : spec.options()) {
                String radioId = option.id() != null && !option.id().isBlank()
                        ? option.id()
                        : id + "_opt" + (++i);
                group.option(radioId, option.option(), nullToEmpty(option.text()));
            }
        }
        return group;
    }

    private FormComponent checkbox(String id, String mid, GridData layout, ComponentSpec spec) {
        GesCheckbox checkbox = new GesCheckbox(id, mid, layout)
                .label(nullToEmpty(spec.label()))
                .text(nullToEmpty(spec.text() != null ? spec.text() : spec.label()));
        forEachListen(spec, checkbox::listenTo);
        return checkbox;
    }

    private FormComponent repeatableSection(
            String id, String mid, GridData layout, ComponentSpec spec, AtomicInteger seq) {
        GesRepeatableSection section = new GesRepeatableSection(id, mid, layout)
                .label(nullToEmpty(spec.label()))
                .toolTipText(nullToEmpty(spec.toolTipText()));
        if (spec.printable() != null) {
            section.printable(spec.printable());
        }
        if (spec.components() != null) {
            for (ComponentSpec child : spec.components()) {
                section.add(toComponent(child, seq));
            }
        }
        return section;
    }

    private FormComponent inlineTable(
            String id, String mid, GridData layout, ComponentSpec spec, AtomicInteger seq) {
        GesInlineTable table = new GesInlineTable(id, mid, layout).title(nullToEmpty(spec.title()));
        if (spec.components() != null) {
            for (ComponentSpec child : spec.components()) {
                table.add(toComponent(child, seq));
            }
        }
        return table;
    }

    private FormComponent combobox(String id, String mid, GridData layout, ComponentSpec spec) {
        GesCombobox combobox = new GesCombobox(id, mid, layout)
                .label(nullToEmpty(spec.label()))
                .description(nullToEmpty(spec.description()));
        if (spec.searchable() != null) {
            combobox.searchable(spec.searchable());
        }
        if (spec.options() != null) {
            for (OptionSpec option : spec.options()) {
                combobox.option(option.option(), nullToEmpty(option.text()));
            }
        }
        return combobox;
    }

    private FormComponent datePicker(String id, String mid, GridData layout, ComponentSpec spec) {
        GesDatePicker picker = new GesDatePicker(id, mid, layout).label(nullToEmpty(spec.label()));
        if (spec.dateRange() != null) {
            picker.dateRange(spec.dateRange());
        }
        if (spec.startViewMode() != null) {
            picker.startViewMode(spec.startViewMode());
        }
        if (spec.defaultValueOnToday() != null) {
            picker.defaultValueOnToday(spec.defaultValueOnToday());
        }
        if (spec.disabledInputTyping() != null) {
            picker.disabledInputTyping(spec.disabledInputTyping());
        }
        if (spec.dataSource() != null) {
            picker.dataSource(toDataSource(spec.dataSource()));
        }
        return picker;
    }

    private FormComponent singleSlider(String id, String mid, GridData layout, ComponentSpec spec) {
        return new GesSingleSlider(id, mid, layout).label(nullToEmpty(spec.label()));
    }

    private FormComponent stepSlider(String id, String mid, GridData layout, ComponentSpec spec) {
        GesStepSlider slider = new GesStepSlider(id, mid, layout)
                .label(nullToEmpty(spec.label()))
                .description(nullToEmpty(spec.description()));
        if (spec.maxValue() != null) {
            slider.maxValue(spec.maxValue());
        }
        if (spec.step() != null) {
            slider.step(spec.step());
        }
        return slider;
    }

    private FormComponent image(String id, String mid, GridData layout, ComponentSpec spec) {
        return new GesImage(id, mid, layout).imageUrl(nullToEmpty(spec.imageUrl()));
    }

    private FormComponent pageNav(String id, String mid, GridData layout, ComponentSpec spec) {
        GesPageNavigationLink link = new GesPageNavigationLink(id, mid, layout)
                .text(nullToEmpty(spec.text()));
        if (spec.pageMid() != null) {
            link.pageMid(spec.pageMid());
        }
        return link;
    }

    private FormComponent statements(String id, String mid, GridData layout, ComponentSpec spec) {
        return new GesStatements(id, mid, layout).label(nullToEmpty(spec.label()));
    }

    private void forEachListen(ComponentSpec spec, Consumer<String> listener) {
        if (spec.listenTo() != null) {
            spec.listenTo().forEach(listener);
        }
    }

    private ValidatorBinding toValidator(ValidatorSpec spec, String fallbackLocal) {
        if (spec.inputs() != null && !spec.inputs().isEmpty()) {
            List<ValidatorBinding.InputField> inputs = new ArrayList<>();
            for (ValidatorInputSpec input : spec.inputs()) {
                boolean nullable = Boolean.TRUE.equals(input.nullable());
                inputs.add(new ValidatorBinding.InputField(input.localName(), input.serviceName(), nullable));
            }
            return new ValidatorBinding(spec.name(), inputs);
        }
        String service = spec.serviceName() != null ? spec.serviceName() : "value";
        return ValidatorBinding.simple(spec.name(), fallbackLocal, service);
    }

    private DataSourceBinding toDataSource(DataSourceSpec spec) {
        return new DataSourceBinding(spec.name(), spec.type(), mapFields(spec.inputs()), mapFields(spec.outputs()));
    }

    private List<DataSourceBinding.FieldBinding> mapFields(List<DataFieldSpec> fields) {
        if (fields == null) {
            return List.of();
        }
        List<DataSourceBinding.FieldBinding> result = new ArrayList<>();
        for (DataFieldSpec field : fields) {
            result.add(new DataSourceBinding.FieldBinding(
                    field.localName(), field.serviceName(), field.constantValue()));
        }
        return result;
    }

    private static String nullToEmpty(String value) {
        return value == null ? "" : value;
    }
}
