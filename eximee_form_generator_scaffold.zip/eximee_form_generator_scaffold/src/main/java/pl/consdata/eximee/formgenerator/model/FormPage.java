package pl.consdata.eximee.formgenerator.model;

import java.util.ArrayList;
import java.util.List;
import pl.consdata.eximee.formgenerator.component.FormComponent;
import pl.consdata.eximee.formgenerator.component.SpacerLabel;
import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class FormPage {

    public static final int COLUMNS = 16;

    private final String id;
    private final String title;
    private final String nextButton;
    private final List<FormComponent> components = new ArrayList<>();

    public FormPage(String id) {
        this(id, "", "");
    }

    public FormPage(String id, String title, String nextButton) {
        this.id = id;
        this.title = title == null ? "" : title;
        this.nextButton = nextButton == null ? "" : nextButton;
    }

    public String id() {
        return id;
    }

    public FormPage add(FormComponent component) {
        components.add(component);
        return this;
    }

    public void write(XmlWriter xml, TranslationBag translations, int pageNumber) {
        translations.put(id + ".title", title);
        translations.put(id + ".nextButton", nextButton);
        xml.open("system:Page",
                        "id=\"" + id + "\" mid=\"" + id + "\" page=\"" + pageNumber + "\""
                                + " titleKey=\"" + id + ".title\""
                                + " labelForNextOrSubmitButtonKey=\"" + id + ".nextButton\""
                                + " roleForm=\"true\" fixedColumns=\"true\"")
                .indent();
        int usedInRow = 0;
        for (FormComponent component : components) {
            component.write(xml, translations);
            usedInRow += component.horizontalSpan();
            if (usedInRow >= COLUMNS) {
                usedInRow = 0;
            }
        }
        int remaining = usedInRow == 0 ? COLUMNS : COLUMNS - usedInRow;
        for (int i = 0; i < remaining; i++) {
            new SpacerLabel().write(xml, translations);
        }
        xml.empty("data:ListeningOn");
        xml.empty("data:ClearOn");
        xml.open("system:Page.layout").indent();
        xml.empty("ns6:GridLayout", "makeColumnsEqualWidth=\"true\" numColumns=\"" + COLUMNS + "\"");
        xml.outdent().close("system:Page.layout");
        xml.empty("data:Curtains");
        xml.outdent().close("system:Page");
    }
}
