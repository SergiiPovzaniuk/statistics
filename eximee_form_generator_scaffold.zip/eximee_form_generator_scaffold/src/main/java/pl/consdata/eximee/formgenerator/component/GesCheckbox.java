package pl.consdata.eximee.formgenerator.component;

import pl.consdata.eximee.formgenerator.xml.TranslationBag;

public final class GesCheckbox extends AbstractGesComponent {

    private String label = "";
    private String text = "";

    public GesCheckbox(String id) {
        this(id, id, GridData.fill(3));
    }

    public GesCheckbox(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("defaultValueKey", id + ".defaultValue");
        attr("labelKey", id + ".label");
        attr("ariaLabelKey", id + ".ariaLabel");
        attr("ariaDescriptionKey", id + ".ariaDescription");
        attr("additionalDescriptionKey", id + ".additionalDescription");
        attr("textKey", id + ".text");
        attr("descriptionKey", id + ".description");
        attr("moreInfoLabelKey", id + ".moreInfoLabel");
    }

    public GesCheckbox label(String label) {
        this.label = label == null ? "" : label;
        return this;
    }

    public GesCheckbox text(String text) {
        this.text = text == null ? "" : text;
        return this;
    }

    @Override
    public GesCheckbox listenTo(String fieldId) {
        super.listenTo(fieldId);
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesCheckbox";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesCheckbox.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.put(id + ".label", label);
        translations.put(id + ".text", text);
        translations.putEmpty(id + ".defaultValue");
        translations.putEmpty(id + ".ariaLabel");
        translations.putEmpty(id + ".ariaDescription");
        translations.putEmpty(id + ".additionalDescription");
        translations.putEmpty(id + ".description");
        translations.putEmpty(id + ".moreInfoLabel");
    }
}
