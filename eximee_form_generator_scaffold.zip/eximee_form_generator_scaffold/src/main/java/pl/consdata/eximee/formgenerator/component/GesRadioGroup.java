package pl.consdata.eximee.formgenerator.component;

import java.util.ArrayList;
import java.util.List;
import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class GesRadioGroup extends AbstractGesComponent {

    private final List<GesRadio> options = new ArrayList<>();
    private String label = "";
    private String title = "";
    private String defaultValue;

    public GesRadioGroup(String id) {
        this(id, id, GridData.fill(16));
    }

    public GesRadioGroup(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("labelKey", id + ".label");
        attr("ariaLabelKey", id + ".ariaLabelKey");
        attr("ariaDescriptionKey", id + ".ariaDescription");
        attr("inheritLayout", "false");
        attr("titleKey", id + ".title");
    }

    public GesRadioGroup label(String label) {
        this.label = label == null ? "" : label;
        return this;
    }

    public GesRadioGroup title(String title) {
        this.title = title == null ? "" : title;
        return this;
    }

    public GesRadioGroup defaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
        return this;
    }

    public GesRadioGroup option(String radioId, String optionValue, String text) {
        options.add(new GesRadio(radioId, optionValue, text));
        return this;
    }

    public GesRadioGroup add(GesRadio radio) {
        options.add(radio);
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesRadioGroup";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesRadioGroup.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.put(id + ".label", label);
        translations.put(id + ".title", title);
        translations.putEmpty(id + ".ariaLabelKey");
        translations.putEmpty(id + ".ariaDescription");
    }

    @Override
    public void write(XmlWriter xml, TranslationBag translations) {
        if (defaultValue != null) {
            attr("defaultValue", defaultValue);
        }
        registerTranslations(translations);
        StringBuilder attrs = new StringBuilder();
        attrs.append(XmlWriter.attr("id", id));
        attrs.append(XmlWriter.attr("mid", mid));
        attributes.forEach((k, v) -> attrs.append(XmlWriter.attr(k, v)));
        xml.open(elementName(), attrs.toString().trim()).indent();
        for (GesRadio option : options) {
            option.write(xml, translations);
        }
        writeListeningOn(xml);
        xml.empty("data:ClearOn");
        layout.write(xml, layoutDataTag());
        xml.open("p1:GesRadioGroup.layout").indent();
        xml.empty("ns6:GridLayout", "makeColumnsEqualWidth=\"true\" numColumns=\"2\"");
        xml.outdent().close("p1:GesRadioGroup.layout");
        xml.outdent().close(elementName());
    }
}
