package pl.consdata.eximee.formgenerator.component;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public abstract class AbstractGesComponent implements FormComponent {

    protected final String id;
    protected final String mid;
    protected final GridData layout;
    protected final List<String> listenTo = new ArrayList<>();
    protected final Map<String, String> attributes = new LinkedHashMap<>();

    protected AbstractGesComponent(String id, String mid, GridData layout) {
        this.id = id;
        this.mid = mid == null || mid.isBlank() ? id : mid;
        this.layout = layout == null ? GridData.fill(16) : layout;
    }

    protected abstract String elementName();

    protected abstract String layoutDataTag();

    protected void registerTranslations(TranslationBag translations) {}

    protected void writeBody(XmlWriter xml, TranslationBag translations) {}

    protected void writeBetweenClearAndLayout(XmlWriter xml, TranslationBag translations) {}

    protected void writeAfterLayout(XmlWriter xml, TranslationBag translations) {}

    public AbstractGesComponent attr(String name, String value) {
        if (value != null) {
            attributes.put(name, value);
        }
        return this;
    }

    public AbstractGesComponent listenTo(String fieldId) {
        listenTo.add(fieldId);
        return this;
    }

    public AbstractGesComponent visibleCondition(String visibleCondition) {
        return attr("visibleCondition", visibleCondition);
    }

    public AbstractGesComponent enabledCondition(String enabledCondition) {
        return attr("enabledCondition", enabledCondition);
    }

    public AbstractGesComponent styleName(String styleName) {
        return attr("styleName", styleName);
    }

    @Override
    public int horizontalSpan() {
        return layout.horizontalSpan();
    }

    @Override
    public void write(XmlWriter xml, TranslationBag translations) {
        registerTranslations(translations);
        StringBuilder attrs = new StringBuilder();
        attrs.append(XmlWriter.attr("id", id));
        attrs.append(XmlWriter.attr("mid", mid));
        attributes.forEach((k, v) -> attrs.append(XmlWriter.attr(k, v)));
        xml.open(elementName(), attrs.toString().trim()).indent();
        writeBody(xml, translations);
        writeListeningOn(xml);
        xml.empty("data:ClearOn");
        writeBetweenClearAndLayout(xml, translations);
        layout.write(xml, layoutDataTag());
        writeAfterLayout(xml, translations);
        xml.outdent().close(elementName());
    }

    protected void writeListeningOn(XmlWriter xml) {
        if (listenTo.isEmpty()) {
            xml.empty("data:ListeningOn");
            return;
        }
        xml.open("data:ListeningOn").indent();
        for (String fieldId : listenTo) {
            xml.empty("data:ListenField", "id=\"" + XmlWriter.escape(fieldId) + "\"");
        }
        xml.outdent().close("data:ListeningOn");
    }

    protected static String uuid() {
        return UUID.randomUUID().toString();
    }
}
