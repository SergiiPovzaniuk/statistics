package pl.consdata.eximee.formgenerator.component;

import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public interface FormComponent {

    int horizontalSpan();

    void write(XmlWriter xml, TranslationBag translations);
}
