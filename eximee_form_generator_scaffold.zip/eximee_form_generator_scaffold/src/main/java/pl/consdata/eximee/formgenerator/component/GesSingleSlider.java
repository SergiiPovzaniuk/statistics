package pl.consdata.eximee.formgenerator.component;

import pl.consdata.eximee.formgenerator.xml.TranslationBag;

public final class GesSingleSlider extends AbstractGesComponent {

    private String label = "";

    public GesSingleSlider(String id) {
        this(id, id, GridData.fill(16));
    }

    public GesSingleSlider(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("defaultValueKey", id + ".defaultValue");
        attr("labelKey", id + ".label");
        attr("ariaLabelKey", id + ".ariaLabel");
        attr("ariaDescriptionKey", id + ".ariaDescription");
        attr("legendSuffixKey", id + ".legendSuffix");
        attr("descriptionPopupTextKey", id + ".descriptionPopupText");
        attr("textInputSuffixKey", id + ".textInputSuffix");
        attr("maxValueSuggestKey", id + ".maxValueSuggest");
        attr("minValueSuggestKey", id + ".minValueSuggest");
    }

    public GesSingleSlider label(String label) {
        this.label = label == null ? "" : label;
        return this;
    }

    public GesSingleSlider model(String model) {
        attr("model", model == null ? "" : model);
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesSingleSlider";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesSingleSlider.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.put(id + ".label", label);
        translations.putEmpty(id + ".defaultValue");
        translations.putEmpty(id + ".ariaLabel");
        translations.putEmpty(id + ".ariaDescription");
        translations.putEmpty(id + ".legendSuffix");
        translations.putEmpty(id + ".descriptionPopupText");
        translations.putEmpty(id + ".textInputSuffix");
        translations.putEmpty(id + ".maxValueSuggest");
        translations.putEmpty(id + ".minValueSuggest");
    }
}
