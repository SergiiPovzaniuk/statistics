package pl.consdata.eximee.formgenerator.component;

import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class GesComplexComponent extends AbstractGesComponent {

    public GesComplexComponent(String id, String componentName) {
        this(id, id, componentName, GridData.spanOnly(16));
    }

    public GesComplexComponent(String id, String mid, String componentName, GridData layout) {
        super(id, mid, layout);
        attr("inheritLayout", "false");
        attr("componentName", componentName);
        attr("componentVersion", "*");
        attr("version", "*");
    }

    @Override
    protected String elementName() {
        return "p1:GesComplexComponent";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesComplexComponent.layoutData";
    }

    @Override
    protected void writeAfterLayout(XmlWriter xml, TranslationBag translations) {
        xml.empty("data:ComponentInputMapping");
    }
}
