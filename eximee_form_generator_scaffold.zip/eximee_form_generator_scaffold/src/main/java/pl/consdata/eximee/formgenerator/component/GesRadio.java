package pl.consdata.eximee.formgenerator.component;

import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class GesRadio extends AbstractGesComponent {

    private String option;
    private String text = "";

    public GesRadio(String id, String option) {
        this(id, id, option, GridData.fill(1));
    }

    public GesRadio(String id, String option, String text) {
        this(id, id, option, GridData.fill(1));
        this.text = text == null ? "" : text;
    }

    public GesRadio(String id, String mid, String option, GridData layout) {
        super(id, mid, layout);
        this.option = option == null ? "" : option;
        attr("ariaLabelKey", id + ".ariaLabel");
        attr("ariaDescriptionKey", id + ".ariaDescription");
        attr("descriptionKey", id + ".description");
        attr("textKey", id + ".text");
    }

    public GesRadio text(String text) {
        this.text = text == null ? "" : text;
        return this;
    }

    public GesRadio option(String option) {
        this.option = option == null ? "" : option;
        return this;
    }

    public String option() {
        return option;
    }

    @Override
    protected String elementName() {
        return "p1:GesRadio";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesRadio.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.put(id + ".text", text);
        translations.putEmpty(id + ".ariaLabel");
        translations.putEmpty(id + ".ariaDescription");
        translations.putEmpty(id + ".description");
    }

    @Override
    public void write(XmlWriter xml, TranslationBag translations) {
        attr("option", option);
        super.write(xml, translations);
    }
}
