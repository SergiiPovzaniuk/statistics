package pl.consdata.eximee.formgenerator.relation;

/**
 * Maps a source into a custom/complex component input slot
 * ({@code data:ComponentMapping}).
 */
public record InputMapping(String name, String componentId, String constant) {

    public static InputMapping fromComponent(String name, String componentId) {
        return new InputMapping(name, componentId, null);
    }

    public static InputMapping fromConstant(String name, String constant) {
        return new InputMapping(name, null, constant);
    }

    public boolean isComponentBound() {
        return componentId != null && !componentId.isBlank();
    }
}
