package pl.consdata.eximee.formgenerator.relation;

import java.util.List;
import java.util.UUID;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

/**
 * {@code data:ExternalDataSource} — SERVICE / SCRIPT_SERVICE / PAGE_SERVICE.
 */
public record DataSourceBinding(
        String name,
        String type,
        List<FieldBinding> inputs,
        List<FieldBinding> outputs
) {
    public record FieldBinding(String localName, String serviceName, String constantValue) {}

    public static DataSourceBinding textContent(String artifact) {
        return new DataSourceBinding(
                "TextContentService",
                "SERVICE",
                List.of(new FieldBinding(null, "artifact", artifact)),
                List.of(
                        new FieldBinding("name", "name", null),
                        new FieldBinding("version", "version", null),
                        new FieldBinding("content", "artifact", null),
                        new FieldBinding("autoTextFormat", "autoTextFormat", null),
                        new FieldBinding("markupType", "markupType", null)
                ));
    }

    public static DataSourceBinding echoScript() {
        return new DataSourceBinding("EchoServiceScript", "SCRIPT_SERVICE", List.of(), List.of());
    }

    public static DataSourceBinding pageService(String name, String outputLocal, String outputService) {
        return new DataSourceBinding(
                name,
                "PAGE_SERVICE",
                List.of(),
                List.of(new FieldBinding(outputLocal, outputService, null)));
    }

    public void write(XmlWriter xml) {
        xml.open("data:ExternalDataSource",
                        "name=\"" + XmlWriter.escape(name) + "\""
                                + " type=\"" + XmlWriter.escape(type) + "\""
                                + " changesWidgetAttributes=\"false\" condition=\"\" version=\"*\" cacheable=\"false\"")
                .indent();
        writeFields(xml, "data:InputFields", inputs);
        writeFields(xml, "data:OutputFields", outputs);
        xml.outdent().close("data:ExternalDataSource");
    }

    private static void writeFields(XmlWriter xml, String tag, List<FieldBinding> fields) {
        if (fields == null || fields.isEmpty()) {
            xml.empty(tag);
            return;
        }
        xml.open(tag).indent();
        for (FieldBinding field : fields) {
            StringBuilder attrs = new StringBuilder("id=\"" + UUID.randomUUID() + "\"");
            if (field.localName() != null) {
                attrs.append(XmlWriter.attr("localName", field.localName()));
            }
            if (field.serviceName() != null) {
                attrs.append(XmlWriter.attr("serviceName", field.serviceName()));
            }
            if (field.constantValue() != null) {
                attrs.append(XmlWriter.attr("constantValue", field.constantValue()));
            }
            xml.empty("data:Field", attrs.toString());
        }
        xml.outdent().close(tag);
    }
}
