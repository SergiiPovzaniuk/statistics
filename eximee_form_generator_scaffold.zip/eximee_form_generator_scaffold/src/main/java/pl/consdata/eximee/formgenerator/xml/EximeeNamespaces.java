package pl.consdata.eximee.formgenerator.xml;

public final class EximeeNamespaces {

    public static final String FORM =
            "xmlns:system=\"clr-namespace:pl.consdata.iew.ges.components.system\" "
                    + "xmlns:ns6=\"http://www.eclipse.org/xwt/presentation\" "
                    + "xmlns:p1=\"clr-namespace:pl.consdata.iew.ges.components\" "
                    + "xmlns:p2=\"clr-namespace:pl.consdata.iew.ges.additional.components\" "
                    + "xmlns:ns7=\"http://www.eclipse.org/xwt\" "
                    + "xmlns:data=\"clr-namespace:pl.consdata.iew.ges.components.data\"";

    public static final String META =
            "xmlns:ns6=\"http://www.eclipse.org/xwt/presentation\" "
                    + "xmlns:p1=\"clr-namespace:pl.consdata.iew.ges.components\" "
                    + "xmlns:p2=\"clr-namespace:pl.consdata.iew.ges.additional.components\" "
                    + "xmlns:system=\"clr-namespace:pl.consdata.iew.ges.components.system\" "
                    + "xmlns:ns7=\"http://www.eclipse.org/xwt\" "
                    + "xmlns:data=\"clr-namespace:pl.consdata.iew.ges.components.data\"";

    private EximeeNamespaces() {}
}
