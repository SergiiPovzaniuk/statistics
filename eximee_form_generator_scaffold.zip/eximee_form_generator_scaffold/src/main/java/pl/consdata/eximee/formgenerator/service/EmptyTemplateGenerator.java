package pl.consdata.eximee.formgenerator.service;

import org.springframework.stereotype.Service;
import pl.consdata.eximee.formgenerator.model.FormDefinition;
import pl.consdata.eximee.formgenerator.model.FormPage;

@Service
public class EmptyTemplateGenerator {

    private final FormXmlRenderer renderer;

    public EmptyTemplateGenerator(FormXmlRenderer renderer) {
        this.renderer = renderer;
    }

    public String generate() {
        FormDefinition form = new FormDefinition()
                .title("")
                .addPage(new FormPage("Page1", "", ""));
        return renderer.render(form);
    }
}
