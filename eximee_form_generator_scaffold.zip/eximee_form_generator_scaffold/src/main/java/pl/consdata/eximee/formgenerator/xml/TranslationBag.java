package pl.consdata.eximee.formgenerator.xml;

import java.util.LinkedHashMap;
import java.util.Map;

public final class TranslationBag {

    private final Map<String, String> entries = new LinkedHashMap<>();

    public void put(String key, String value) {
        entries.putIfAbsent(key, value == null ? "" : value);
    }

    public void putEmpty(String key) {
        put(key, "");
    }

    public Map<String, String> entries() {
        return entries;
    }

    public void write(XmlWriter xml) {
        xml.open("ecTranslations").indent();
        xml.open("localization", EximeeNamespaces.META).indent();
        xml.empty("language", "default=\"true\" name=\"Polski\" tag=\"pl\"");
        for (Map.Entry<String, String> entry : entries.entrySet()) {
            xml.open("entry", "key=\"" + XmlWriter.escape(entry.getKey()) + "\"").indent();
            if (entry.getValue().isEmpty()) {
                xml.empty("item", "tag=\"pl\"");
            } else {
                xml.line("<item tag=\"pl\">" + XmlWriter.escape(entry.getValue()) + "</item>");
            }
            xml.outdent().close("entry");
        }
        xml.outdent().close("localization");
        xml.outdent().close("ecTranslations");
    }
}
