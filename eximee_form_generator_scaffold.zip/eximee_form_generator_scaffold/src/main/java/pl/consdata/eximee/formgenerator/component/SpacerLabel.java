package pl.consdata.eximee.formgenerator.component;

import java.util.UUID;
import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class SpacerLabel implements FormComponent {

    @Override
    public int horizontalSpan() {
        return 1;
    }

    @Override
    public void write(XmlWriter xml, TranslationBag translations) {
        xml.open("ns6:Label", "uuid=\"" + UUID.randomUUID() + "\"").indent();
        xml.empty("data:ListeningOn");
        xml.empty("data:ClearOn");
        xml.outdent().close("ns6:Label");
    }
}
