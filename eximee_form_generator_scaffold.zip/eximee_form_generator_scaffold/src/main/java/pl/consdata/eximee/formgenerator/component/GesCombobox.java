package pl.consdata.eximee.formgenerator.component;

import java.util.ArrayList;
import java.util.List;
import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class GesCombobox extends AbstractGesComponent {

    private String label = "";
    private String description = "";
    private boolean searchable;
    private final List<Option> options = new ArrayList<>();

    public GesCombobox(String id) {
        this(id, id, GridData.fill(16));
    }

    public GesCombobox(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("defaultValueKey", id + ".defaultValue");
        attr("labelKey", id + ".label");
        attr("ariaLabelKey", id + ".ariaLabelKey");
        attr("ariaDescriptionKey", id + ".ariaDescription");
        attr("descriptionLabelKey", id + ".descriptionLabel");
        attr("emptyOptionCustomTextKey", id + ".emptyOptionCustomText");
        attr("descriptionKey", id + ".description");
        attr("searchable", "false");
    }

    public GesCombobox label(String label) {
        this.label = label == null ? "" : label;
        return this;
    }

    public GesCombobox description(String description) {
        this.description = description == null ? "" : description;
        return this;
    }

    public GesCombobox searchable(boolean searchable) {
        this.searchable = searchable;
        return this;
    }

    public GesCombobox option(String value, String text) {
        options.add(new Option(value, text));
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesCombobox";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesCombobox.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.put(id + ".label", label);
        translations.put(id + ".description", description);
        translations.putEmpty(id + ".defaultValue");
        translations.putEmpty(id + ".ariaLabelKey");
        translations.putEmpty(id + ".ariaDescription");
        translations.putEmpty(id + ".descriptionLabel");
        translations.putEmpty(id + ".emptyOptionCustomText");
        for (int i = 0; i < options.size(); i++) {
            translations.put(id + ".option." + i, options.get(i).text());
        }
    }

    @Override
    public void write(XmlWriter xml, TranslationBag translations) {
        attr("searchable", Boolean.toString(searchable));
        super.write(xml, translations);
    }

    @Override
    protected void writeBody(XmlWriter xml, TranslationBag translations) {
        if (options.isEmpty()) {
            return;
        }
        xml.open("data:Options").indent();
        for (int i = 0; i < options.size(); i++) {
            Option option = options.get(i);
            xml.empty("data:Option",
                    "value=\"" + XmlWriter.escape(option.value()) + "\""
                            + " textKey=\"" + XmlWriter.escape(id + ".option." + i) + "\"");
        }
        xml.outdent().close("data:Options");
    }

    private record Option(String value, String text) {}
}
