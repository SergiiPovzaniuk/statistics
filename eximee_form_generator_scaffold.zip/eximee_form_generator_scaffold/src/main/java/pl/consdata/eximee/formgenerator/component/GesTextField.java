package pl.consdata.eximee.formgenerator.component;

import java.util.ArrayList;
import java.util.List;
import pl.consdata.eximee.formgenerator.relation.DataSourceBinding;
import pl.consdata.eximee.formgenerator.relation.ValidatorBinding;
import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class GesTextField extends AbstractGesComponent {

    private String label = "";
    private String expectedType;
    private String formatter;
    private String mask;
    private String valueSourceId;
    private String visibleCondition;
    private String requiredCondition;
    private String enabledCondition;
    private String visibleMask;
    private boolean technicalField;
    private DataSourceBinding dataSource;
    private final List<ValidatorBinding> validators = new ArrayList<>();

    public GesTextField(String id) {
        this(id, id, GridData.fill(16));
    }

    public GesTextField(String id, int span) {
        this(id, id, GridData.fill(span));
    }

    public GesTextField(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("defaultValueKey", id + ".defaultValue");
        attr("labelKey", id + ".label");
        attr("ariaLabelKey", id + ".ariaLabelKey");
        attr("ariaDescriptionKey", id + ".ariaDescription");
        attr("maskValidationErrorKey", id + ".maskValidationError");
        attr("placeholderTextKey", id + ".placeholderText");
        attr("prefixKey", id + ".prefix");
        attr("suffixKey", id + ".suffix");
        attr("descriptionKey", id + ".description");
        attr("maxLengthWarningKey", id + ".maxLengthWarning");
        attr("autocompleteOptionsFilterEnabled", "true");
    }

    public GesTextField label(String label) {
        this.label = label;
        return this;
    }

    public GesTextField expectedType(String expectedType) {
        this.expectedType = expectedType;
        return this;
    }

    public GesTextField formatter(String formatter) {
        this.formatter = formatter;
        return this;
    }

    public GesTextField mask(String mask) {
        this.mask = mask;
        return this;
    }

    public GesTextField valueSourceId(String valueSourceId) {
        this.valueSourceId = valueSourceId;
        return this;
    }

    public GesTextField dataSource(DataSourceBinding dataSource) {
        this.dataSource = dataSource;
        return this;
    }

    public GesTextField visibleCondition(String visibleCondition) {
        this.visibleCondition = visibleCondition;
        return this;
    }

    public GesTextField requiredCondition(String requiredCondition) {
        this.requiredCondition = requiredCondition;
        return this;
    }

    public GesTextField enabledCondition(String enabledCondition) {
        this.enabledCondition = enabledCondition;
        return this;
    }

    public GesTextField visibleMask(String visibleMask) {
        this.visibleMask = visibleMask;
        return this;
    }

    public GesTextField technicalField(boolean technicalField) {
        this.technicalField = technicalField;
        return this;
    }

    public GesTextField validator(String name, String serviceName) {
        validators.add(ValidatorBinding.simple(name, id, serviceName));
        return this;
    }

    @Override
    public GesTextField listenTo(String fieldId) {
        super.listenTo(fieldId);
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesTextField";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesTextField.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.put(id + ".label", label);
        translations.putEmpty(id + ".defaultValue");
        translations.putEmpty(id + ".ariaLabelKey");
        translations.putEmpty(id + ".ariaDescription");
        translations.putEmpty(id + ".maskValidationError");
        translations.putEmpty(id + ".placeholderText");
        translations.putEmpty(id + ".prefix");
        translations.putEmpty(id + ".suffix");
        translations.putEmpty(id + ".description");
        translations.putEmpty(id + ".maxLengthWarning");
        translations.putEmpty(id + ".prefixVisibleCondition");
        translations.putEmpty(id + ".pasteEnabledCondition");
    }

    @Override
    public void write(XmlWriter xml, TranslationBag translations) {
        if (expectedType != null) {
            attr("expectedType", expectedType);
        }
        if (formatter != null) {
            attr("formatter", formatter);
        }
        if (mask != null) {
            attr("mask", mask);
        }
        if (valueSourceId != null) {
            attr("valueSourceId", valueSourceId);
        }
        if (visibleCondition != null) {
            attr("visibleCondition", visibleCondition);
        }
        if (requiredCondition != null) {
            attr("requiredCondition", requiredCondition);
        }
        if (enabledCondition != null) {
            attr("enabledCondition", enabledCondition);
        }
        if (visibleMask != null) {
            attr("visibleMask", visibleMask);
        }
        if (technicalField) {
            attr("technicalField", "true");
        }
        super.write(xml, translations);
    }

    @Override
    protected void writeBody(XmlWriter xml, TranslationBag translations) {
        if (dataSource != null) {
            dataSource.write(xml);
        }
    }

    @Override
    protected void writeBetweenClearAndLayout(XmlWriter xml, TranslationBag translations) {
        ValidatorBinding.writeAll(xml, validators);
    }
}
