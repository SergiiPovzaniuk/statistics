package pl.consdata.eximee.formgenerator.component;

import pl.consdata.eximee.formgenerator.relation.DataSourceBinding;
import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class GesDatePicker extends AbstractGesComponent {

    private String label = "";
    private String dateRange;
    private String startViewMode;
    private Boolean defaultValueOnToday;
    private Boolean disabledInputTyping;
    private DataSourceBinding dataSource;

    public GesDatePicker(String id) {
        this(id, id, GridData.fill(16));
    }

    public GesDatePicker(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("defaultValueKey", id + ".defaultValue");
        attr("labelKey", id + ".label");
        attr("dateRangeValidationTextKey", id + ".dateRangeValidationText");
        attr("placeholderTextKey", id + ".placeholderText");
    }

    public GesDatePicker label(String label) {
        this.label = label == null ? "" : label;
        return this;
    }

    public GesDatePicker dateRange(String dateRange) {
        this.dateRange = dateRange;
        return this;
    }

    public GesDatePicker startViewMode(String startViewMode) {
        this.startViewMode = startViewMode;
        return this;
    }

    public GesDatePicker defaultValueOnToday(boolean value) {
        this.defaultValueOnToday = value;
        return this;
    }

    public GesDatePicker disabledInputTyping(boolean value) {
        this.disabledInputTyping = value;
        return this;
    }

    public GesDatePicker dataSource(DataSourceBinding dataSource) {
        this.dataSource = dataSource;
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesDatePicker";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesDatePicker.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.put(id + ".label", label);
        translations.putEmpty(id + ".defaultValue");
        translations.putEmpty(id + ".dateRangeValidationText");
        translations.putEmpty(id + ".placeholderText");
    }

    @Override
    public void write(XmlWriter xml, TranslationBag translations) {
        if (dateRange != null) {
            attr("dateRange", dateRange);
        }
        if (defaultValueOnToday != null) {
            attr("defaultValueOnToday", Boolean.toString(defaultValueOnToday));
        }
        if (disabledInputTyping != null) {
            attr("disabledInputTyping", Boolean.toString(disabledInputTyping));
        }
        if (startViewMode != null) {
            attr("startViewMode", startViewMode);
        }
        super.write(xml, translations);
    }

    @Override
    protected void writeBody(XmlWriter xml, TranslationBag translations) {
        if (dataSource != null) {
            dataSource.write(xml);
        }
    }
}
