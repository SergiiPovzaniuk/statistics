package pl.consdata.eximee.formgenerator.component;

import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class GesText extends AbstractGesComponent {

    private String text = "";
    private String label = "";
    private String visibleCondition;

    public GesText(String id) {
        this(id, id, GridData.fill(16));
    }

    public GesText(String id, int span) {
        this(id, id, GridData.fill(span));
    }

    public GesText(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("labelKey", id + ".label");
        attr("textKey", id + ".text");
        attr("sensitiveDataMaskCondition", "true");
        attr("displayAsParagraph", "true");
    }

    public GesText text(String text) {
        this.text = text;
        return this;
    }

    public GesText label(String label) {
        this.label = label;
        return this;
    }

    @Override
    public GesText visibleCondition(String visibleCondition) {
        this.visibleCondition = visibleCondition;
        return this;
    }

    @Override
    public GesText styleName(String styleName) {
        super.styleName(styleName);
        return this;
    }

    @Override
    public GesText listenTo(String fieldId) {
        super.listenTo(fieldId);
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesText";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesText.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.put(id + ".text", text);
        translations.put(id + ".label", label);
    }

    @Override
    public void write(XmlWriter xml, TranslationBag translations) {
        if (visibleCondition != null) {
            attr("visibleCondition", visibleCondition);
        }
        super.write(xml, translations);
    }
}
