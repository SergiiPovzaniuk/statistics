package pl.consdata.eximee.formgenerator.component;

import java.util.ArrayList;
import java.util.List;
import pl.consdata.eximee.formgenerator.relation.DataSourceBinding;
import pl.consdata.eximee.formgenerator.relation.InputMapping;
import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class GesCustomComponent extends AbstractGesComponent {

    private String htmlContent;
    private final List<InputMapping> mappings = new ArrayList<>();
    private boolean echoDataSource = true;

    public GesCustomComponent(String id, String artifact) {
        this(id, id, artifact, GridData.fill(16));
    }

    public GesCustomComponent(String id, String mid, String artifact, GridData layout) {
        super(id, mid, layout);
        attr("inheritLayout", "false");
        attr("artifact", artifact);
    }

    public GesCustomComponent htmlContent(String htmlContent) {
        this.htmlContent = htmlContent;
        return this;
    }

    public GesCustomComponent mapping(InputMapping mapping) {
        mappings.add(mapping);
        return this;
    }

    public GesCustomComponent withoutEchoDataSource() {
        this.echoDataSource = false;
        return this;
    }

    @Override
    public GesCustomComponent listenTo(String fieldId) {
        super.listenTo(fieldId);
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesCustomComponent";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesCustomComponent.layoutData";
    }

    @Override
    protected void writeBody(XmlWriter xml, TranslationBag translations) {
        if (echoDataSource && htmlContent != null) {
            DataSourceBinding.echoScript().write(xml);
        }
    }

    @Override
    protected void writeAfterLayout(XmlWriter xml, TranslationBag translations) {
        if (htmlContent == null && mappings.isEmpty()) {
            xml.empty("data:CustomComponentInputMapping");
            return;
        }
        xml.open("data:CustomComponentInputMapping").indent();
        if (htmlContent != null) {
            xml.empty("data:ComponentMapping",
                    "name=\"htmlContent\" constant=\"" + XmlWriter.escape(htmlContent) + "\"");
        }
        for (InputMapping mapping : mappings) {
            if (mapping.isComponentBound()) {
                xml.empty("data:ComponentMapping",
                        "componentId=\"" + XmlWriter.escape(mapping.componentId()) + "\""
                                + " name=\"" + XmlWriter.escape(mapping.name()) + "\"");
            } else {
                xml.empty("data:ComponentMapping",
                        "name=\"" + XmlWriter.escape(mapping.name()) + "\""
                                + " constant=\"" + XmlWriter.escape(mapping.constant()) + "\"");
            }
        }
        xml.outdent().close("data:CustomComponentInputMapping");
    }
}
