package pl.consdata.eximee.formgenerator.component;

import java.util.ArrayList;
import java.util.List;
import pl.consdata.eximee.formgenerator.model.FormPage;
import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class GesRepeatableSection extends AbstractGesComponent {

    private final List<FormComponent> children = new ArrayList<>();
    private String label = "";
    private String toolTipText = "";
    private Boolean printable;

    public GesRepeatableSection(String id) {
        this(id, id, GridData.fill(16));
    }

    public GesRepeatableSection(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("labelKey", id + ".label");
        attr("toolTipTextKey", id + ".toolTipText");
        attr("inheritLayout", "true");
    }

    public GesRepeatableSection label(String label) {
        this.label = label == null ? "" : label;
        return this;
    }

    public GesRepeatableSection toolTipText(String toolTipText) {
        this.toolTipText = toolTipText == null ? "" : toolTipText;
        return this;
    }

    public GesRepeatableSection printable(boolean printable) {
        this.printable = printable;
        return this;
    }

    public GesRepeatableSection add(FormComponent child) {
        children.add(child);
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesRepeatableSection";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesRepeatableSection.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.put(id + ".label", label);
        translations.put(id + ".toolTipText", toolTipText);
    }

    @Override
    public void write(XmlWriter xml, TranslationBag translations) {
        if (printable != null) {
            attr("printable", Boolean.toString(printable));
        }
        registerTranslations(translations);
        StringBuilder attrs = new StringBuilder();
        attrs.append(XmlWriter.attr("id", id));
        attrs.append(XmlWriter.attr("mid", mid));
        attributes.forEach((k, v) -> attrs.append(XmlWriter.attr(k, v)));
        xml.open(elementName(), attrs.toString().trim()).indent();

        int usedInRow = 0;
        for (FormComponent child : children) {
            child.write(xml, translations);
            usedInRow += child.horizontalSpan();
            if (usedInRow >= FormPage.COLUMNS) {
                usedInRow = 0;
            }
        }
        int remaining = usedInRow == 0 ? 0 : FormPage.COLUMNS - usedInRow;
        for (int i = 0; i < remaining; i++) {
            new SpacerLabel().write(xml, translations);
        }

        writeListeningOn(xml);
        xml.empty("data:ClearOn");
        layout.write(xml, layoutDataTag());
        xml.open("p1:GesRepeatableSection.layout").indent();
        xml.empty("ns6:GridLayout", "makeColumnsEqualWidth=\"true\" numColumns=\"" + FormPage.COLUMNS + "\"");
        xml.outdent().close("p1:GesRepeatableSection.layout");
        xml.outdent().close(elementName());
    }
}
