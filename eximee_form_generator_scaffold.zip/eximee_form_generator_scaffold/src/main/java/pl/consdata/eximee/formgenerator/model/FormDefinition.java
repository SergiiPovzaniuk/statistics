package pl.consdata.eximee.formgenerator.model;

import java.util.ArrayList;
import java.util.List;
import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class FormDefinition {

    private String title = "";
    private final List<FormPage> pages = new ArrayList<>();

    public FormDefinition title(String title) {
        this.title = title == null ? "" : title;
        return this;
    }

    public String title() {
        return title;
    }

    public FormDefinition addPage(FormPage page) {
        pages.add(page);
        return this;
    }

    public List<FormPage> pages() {
        return pages;
    }

    public void registerBaseTranslations(TranslationBag translations) {
        translations.put("form.title", title);
    }

    public void writePages(XmlWriter xml, TranslationBag translations) {
        int pageNumber = 1;
        for (FormPage page : pages) {
            page.write(xml, translations, pageNumber++);
        }
    }
}
