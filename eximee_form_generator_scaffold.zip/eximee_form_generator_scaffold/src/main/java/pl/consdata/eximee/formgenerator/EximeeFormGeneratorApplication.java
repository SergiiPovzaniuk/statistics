package pl.consdata.eximee.formgenerator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EximeeFormGeneratorApplication {

    public static void main(String[] args) {
        SpringApplication.run(EximeeFormGeneratorApplication.class, args);
    }
}
