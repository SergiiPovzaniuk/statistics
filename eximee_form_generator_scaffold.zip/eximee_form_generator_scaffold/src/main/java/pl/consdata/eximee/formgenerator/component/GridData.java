package pl.consdata.eximee.formgenerator.component;

import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public record GridData(int horizontalSpan, String horizontalAlignment, String verticalAlignment) {

    public static GridData fill(int span) {
        return new GridData(span, "FILL", "CENTER");
    }

    public static GridData spanOnly(int span) {
        return new GridData(span, null, null);
    }

    public void write(XmlWriter xml, String layoutDataTag) {
        xml.open(layoutDataTag).indent();
        StringBuilder attrs = new StringBuilder();
        if (horizontalAlignment != null) {
            attrs.append(XmlWriter.attr("horizontalAlignment", horizontalAlignment));
        }
        attrs.append(XmlWriter.attr("horizontalSpan", horizontalSpan));
        if (verticalAlignment != null) {
            attrs.append(XmlWriter.attr("verticalAlignment", verticalAlignment));
        }
        xml.empty("ns6:GridData", attrs.toString().trim());
        xml.outdent().close(layoutDataTag);
    }
}
