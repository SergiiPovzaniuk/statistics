package pl.consdata.eximee.formgenerator.component;

import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class GesStepSlider extends AbstractGesComponent {

    private String label = "";
    private String description = "";
    private Integer maxValue;
    private Integer step;

    public GesStepSlider(String id) {
        this(id, id, GridData.fill(16));
    }

    public GesStepSlider(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("labelKey", id + ".label");
        attr("ariaLabelKey", id + ".ariaLabel");
        attr("ariaDescriptionKey", id + ".ariaDescription");
        attr("maxValueSuggestKey", id + ".maxValueSuggest");
        attr("minValueSuggestKey", id + ".minValueSuggest");
        attr("textInputSuffixKey", id + ".textInputSuffix");
        attr("descriptionKey", id + ".description");
        attr("placeholderKey", id + ".placeholder");
    }

    public GesStepSlider label(String label) {
        this.label = label == null ? "" : label;
        return this;
    }

    public GesStepSlider description(String description) {
        this.description = description == null ? "" : description;
        return this;
    }

    public GesStepSlider maxValue(int maxValue) {
        this.maxValue = maxValue;
        return this;
    }

    public GesStepSlider step(int step) {
        this.step = step;
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesStepSlider";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesStepSlider.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.put(id + ".label", label);
        translations.put(id + ".description", description);
        translations.putEmpty(id + ".ariaLabel");
        translations.putEmpty(id + ".ariaDescription");
        translations.putEmpty(id + ".maxValueSuggest");
        translations.putEmpty(id + ".minValueSuggest");
        translations.putEmpty(id + ".textInputSuffix");
        translations.putEmpty(id + ".placeholder");
    }

    @Override
    public void write(XmlWriter xml, TranslationBag translations) {
        if (maxValue != null) {
            attr("maxValue", Integer.toString(maxValue));
        }
        if (step != null) {
            attr("step", Integer.toString(step));
        }
        super.write(xml, translations);
    }
}
