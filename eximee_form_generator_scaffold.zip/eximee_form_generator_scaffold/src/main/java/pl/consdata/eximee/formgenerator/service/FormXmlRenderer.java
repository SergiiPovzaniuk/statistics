package pl.consdata.eximee.formgenerator.service;

import java.util.List;
import org.springframework.stereotype.Service;
import pl.consdata.eximee.formgenerator.model.FormDefinition;
import pl.consdata.eximee.formgenerator.model.FormPage;
import pl.consdata.eximee.formgenerator.xml.EximeeNamespaces;
import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

@Service
public class FormXmlRenderer {

    private static final List<String[]> SESSION_VARS = List.of(
            arr("startTime", "false"),
            arr("finishTime", "false"),
            arr("userAgent", "false"),
            arr("ip", "false"),
            arr("visitedPages", "false"),
            arr("currentPageMid", "false"),
            arr("channel", "false"),
            arr("channelDescription", "false"),
            arr("formId", "false"),
            arr("abandonTime", "false"),
            arr("finishTimeAfterPayment", "false"),
            arr("cmisObjectId", "false"),
            arr("paymentResult", "false"),
            arr("cvc", "false"),
            arr("operatingSystem", "false"),
            arr("__userEmail__", "true"),
            arr("uuid", "false"),
            arr("browserName", "true"),
            arr("SESSIONKEY", "false"),
            arr("formTitle", "true"),
            arr("formHistory", "false"),
            arr("domain", "false"),
            arr("currentPageId", "false"),
            arr("formInstanceNumber", "false"),
            arr("externalFormContextId", "false"),
            arr("businessFormIdentifier", "false"),
            arr("seller", "false")
    );

    public String render(FormDefinition form) {
        TranslationBag translations = new TranslationBag();
        form.registerBaseTranslations(translations);

        XmlWriter xml = new XmlWriter();
        xml.open("ecProcess").indent();
        writeForm(xml, form, translations);
        translations.write(xml);
        writeMetadata(xml, form);
        writeModelMapping(xml);
        writeEditorMetadata(xml);
        xml.outdent().close("ecProcess");
        return xml.toString();
    }

    private void writeForm(XmlWriter xml, FormDefinition form, TranslationBag translations) {
        xml.open("ecForm").indent();
        xml.open("system:InternetForm", EximeeNamespaces.FORM).indent();
        xml.open("system:Properties").indent();
        xml.empty("system:Property", "key=\"canPark\" value=\"false\"");
        xml.empty("system:Property", "key=\"partners\" value=\"false\"");
        xml.empty("system:Property", "key=\"preloaderStyleName\" value=\"preloader\"");
        xml.outdent().close("system:Properties");
        form.writePages(xml, translations);
        xml.empty("system:Steps");
        xml.outdent().close("system:InternetForm");
        xml.outdent().close("ecForm");
    }

    private void writeMetadata(XmlWriter xml, FormDefinition form) {
        xml.open("ecMetadata").indent();
        xml.open("iftTemplateMetadata", EximeeNamespaces.META).indent();
        xml.empty("abandonActions");
        xml.open("authentication").indent();
        xml.empty("inputMapping");
        xml.text("presentation", "navbar");
        xml.outdent().close("authentication");
        xml.empty("authorizationComponent");
        xml.empty("bundleDependencies");
        xml.empty("componentsMapping");
        xml.empty("concurrentConfig");
        xml.empty("contact");
        xml.empty("customStepsServices");
        xml.empty("dataModelTransformer");
        xml.empty("dependencies");
        writeListeningWrapper(xml, "disableBottomBar");
        xml.empty("documentation");
        xml.empty("draftConfiguration");
        xml.empty("entryServices");
        xml.empty("errorPages");
        xml.empty("exitServices");
        xml.open("externalAuthorization").indent();
        xml.empty("listeningOn");
        xml.empty("inputMapping");
        xml.empty("tranTypes");
        xml.outdent().close("externalAuthorization");
        xml.text("externalStatsEnabled", "false");
        xml.empty("extraTranslations");
        xml.empty("floatingActionButtonData");
        writeListeningWrapper(xml, "floatingActionButtonSensitiveDataMaskVisibility");
        writeListeningWrapper(xml, "floatingActionButtonStatementsVisibility");
        writeListeningWrapper(xml, "floatingActionButtonVisibility");
        xml.empty("formActions");
        xml.empty("formStyles");
        xml.empty("formTitles");
        xml.text("generateHtmlFormView", "false");
        writeListeningWrapper(xml, "headerAdditionalItem1Visibility");
        xml.empty("injectableFields");
        xml.empty("mappingEntryServices");
        xml.empty("nativeApiIntegration");
        writeListeningWrapper(xml, "navbarVisibility");
        xml.empty("navigationActions");
        writeListeningWrapper(xml, "navigationButtonVisibility");
        xml.empty("notifications");
        xml.empty("notifyMobileAppOnSave");
        writeListeningWrapper(xml, "onExitPopup");
        xml.empty("pages");
        xml.empty("parkActions");
        xml.open("parking").indent();
        xml.text("autoParkEnabledForLoggedUser", "false");
        xml.text("autoParkEnabledForNotLoggedUser", "false");
        xml.empty("fieldsConstraintList");
        xml.outdent().close("parking");
        xml.open("payment").indent();
        xml.empty("listeningOn");
        xml.empty("inputMapping");
        xml.outdent().close("payment");
        xml.empty("payments");
        writeListeningWrapper(xml, "printButtonVisibility");
        xml.empty("saveActions");
        xml.empty("searchFieldsForHtmlFormView");
        writeSessionVariables(xml);
        xml.text("showParkButton", "false");
        xml.open("sidebar").indent();
        xml.empty("items");
        xml.outdent().close("sidebar");
        xml.open("statisticsOptions").indent();
        xml.text("errors", "false");
        xml.text("fieldEdition", "false");
        xml.text("formEntry", "true");
        xml.text("formExit", "false");
        xml.text("frequency", "10");
        xml.outdent().close("statisticsOptions");
        writeSteps(xml, form);
        writeListeningWrapper(xml, "stepsVisibility");
        xml.empty("switchForm");
        xml.empty("unparkEntryServices");
        xml.text("updateServerOnAnyChange", "false");
        xml.outdent().close("iftTemplateMetadata");
        xml.outdent().close("ecMetadata");
    }

    private void writeSteps(XmlWriter xml, FormDefinition form) {
        xml.open("steps").indent();
        int i = 1;
        for (FormPage page : form.pages()) {
            String stepId = "Step" + i;
            xml.open("step").indent();
            xml.text("id", stepId);
            xml.open("pages").indent();
            xml.open("page").indent();
            xml.text("pageId", page.id());
            xml.outdent().close("page");
            xml.outdent().close("pages");
            xml.text("summaryStep", "false");
            xml.text("titleKey", stepId + ".title");
            xml.outdent().close("step");
            i++;
        }
        xml.open("step").indent();
        xml.text("id", "SummaryPage");
        xml.empty("pages");
        xml.text("summaryStep", "true");
        xml.text("titleKey", "SummaryPage.title");
        xml.outdent().close("step");
        xml.outdent().close("steps");
    }

    private void writeSessionVariables(XmlWriter xml) {
        xml.open("sessionVariables").indent();
        for (String[] sessionVar : SESSION_VARS) {
            xml.open("sessionVariable", "exposed=\"" + sessionVar[1] + "\"").indent();
            xml.text("gtmPushTagEnabled", "false");
            xml.text("id", sessionVar[0]);
            xml.text("sendStatsEnabled", "false");
            xml.empty("value");
            xml.outdent().close("sessionVariable");
        }
        xml.outdent().close("sessionVariables");
    }

    private void writeModelMapping(XmlWriter xml) {
        xml.open("ecModelMapping").indent();
        xml.open("modelMappings", EximeeNamespaces.META).indent();
        xml.empty("processes");
        xml.empty("mappings");
        xml.empty("groups");
        xml.outdent().close("modelMappings");
        xml.outdent().close("ecModelMapping");
    }

    private void writeEditorMetadata(XmlWriter xml) {
        xml.open("ecEditorMetadata").indent();
        xml.open("editorMetadata", EximeeNamespaces.META).indent();
        xml.text("defaultFormColumnNumber", Integer.toString(FormPage.COLUMNS));
        xml.outdent().close("editorMetadata");
        xml.outdent().close("ecEditorMetadata");
    }

    private void writeListeningWrapper(XmlWriter xml, String tag) {
        xml.open(tag).indent();
        xml.empty("listeningOn");
        xml.outdent().close(tag);
    }

    private static String[] arr(String id, String exposed) {
        return new String[] {id, exposed};
    }
}
