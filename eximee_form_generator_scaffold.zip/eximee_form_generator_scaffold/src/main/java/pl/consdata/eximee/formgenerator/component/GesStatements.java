package pl.consdata.eximee.formgenerator.component;

import pl.consdata.eximee.formgenerator.xml.TranslationBag;

public final class GesStatements extends AbstractGesComponent {

    private String label = "";

    public GesStatements(String id) {
        this(id, id, GridData.fill(16));
    }

    public GesStatements(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("labelKey", id + ".label");
        attr("ariaLabelKey", id + ".ariaLabelKey");
        attr("ariaDescriptionKey", id + ".ariaDescription");
        attr("acceptAllTextKey", id + ".acceptAllText");
        attr("acceptSomeTextKey", id + ".acceptSomeText");
        attr("foldTextKey", id + ".foldText");
        attr("unfoldTextKey", id + ".unfoldText");
        attr("notAllSelectedErrorTextKey", id + ".notAllSelectedErrorText");
        attr("notAllRequiredAcceptedErrorTextKey", id + ".notAllRequiredAcceptedErrorText");
        attr("masterCheckboxLabelKey", id + ".masterCheckboxLabel");
    }

    public GesStatements label(String label) {
        this.label = label == null ? "" : label;
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesStatements";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesStatements.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.put(id + ".label", label);
        translations.putEmpty(id + ".ariaLabelKey");
        translations.putEmpty(id + ".ariaDescription");
        translations.putEmpty(id + ".acceptAllText");
        translations.putEmpty(id + ".acceptSomeText");
        translations.putEmpty(id + ".foldText");
        translations.putEmpty(id + ".unfoldText");
        translations.putEmpty(id + ".notAllSelectedErrorText");
        translations.putEmpty(id + ".notAllRequiredAcceptedErrorText");
        translations.putEmpty(id + ".masterCheckboxLabel");
    }
}
