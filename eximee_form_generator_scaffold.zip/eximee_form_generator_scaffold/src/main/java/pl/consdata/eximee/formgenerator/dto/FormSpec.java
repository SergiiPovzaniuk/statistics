package pl.consdata.eximee.formgenerator.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import java.util.List;

public record FormSpec(
        String title,
        @NotEmpty List<@Valid PageSpec> pages
) {
    public record PageSpec(
            @NotBlank String id,
            String title,
            String nextButton,
            @NotEmpty List<@Valid ComponentSpec> components
    ) {}

    public record ComponentSpec(
            @NotBlank String type,
            String id,
            String mid,
            String label,
            String text,
            String title,
            String artifact,
            String componentName,
            String htmlContent,
            Integer span,
            String expectedType,
            String formatter,
            String mask,
            String valueSourceId,
            String visibleCondition,
            String requiredCondition,
            String foldedCondition,
            String enabledCondition,
            String styleName,
            String visibleMask,
            String defaultValue,
            Boolean technicalField,
            Boolean printable,
            String extensions,
            Integer maxFiles,
            Integer requiredCount,
            Integer maxFileSize,
            Integer maxTotalFilesSize,
            String buttonLabel,
            String description,
            String toolTipText,
            String pageMid,
            String imageUrl,
            String dateRange,
            String startViewMode,
            Boolean defaultValueOnToday,
            Boolean disabledInputTyping,
            Boolean searchable,
            Integer maxValue,
            Integer step,
            List<String> listenTo,
            List<@Valid ValidatorSpec> validators,
            List<@Valid MappingSpec> mappings,
            @Valid DataSourceSpec dataSource,
            List<@Valid OptionSpec> options,
            List<@Valid ComponentSpec> components
    ) {}

    public record ValidatorSpec(
            @NotBlank String name,
            String serviceName,
            List<@Valid ValidatorInputSpec> inputs
    ) {}

    public record ValidatorInputSpec(
            @NotBlank String localName,
            @NotBlank String serviceName,
            Boolean nullable
    ) {}

    public record MappingSpec(
            @NotBlank String name,
            String componentId,
            String constant
    ) {}

    public record DataSourceSpec(
            @NotBlank String name,
            @NotBlank String type,
            List<@Valid DataFieldSpec> inputs,
            List<@Valid DataFieldSpec> outputs
    ) {}

    public record DataFieldSpec(
            String localName,
            String serviceName,
            String constantValue
    ) {}

    public record OptionSpec(
            String id,
            @NotBlank String option,
            String text
    ) {}
}
