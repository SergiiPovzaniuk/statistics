package pl.consdata.eximee.formgenerator.component;

import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class GesImage extends AbstractGesComponent {

    private String imageUrl = "";

    public GesImage(String id) {
        this(id, id, GridData.fill(16));
    }

    public GesImage(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("ariaLabelKey", id + ".ariaLabel");
        attr("ariaDescriptionKey", id + ".ariaDescription");
        attr("imageAltKey", id + ".imageAlt");
    }

    public GesImage imageUrl(String imageUrl) {
        this.imageUrl = imageUrl == null ? "" : imageUrl;
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesImage";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesImage.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.putEmpty(id + ".ariaLabel");
        translations.putEmpty(id + ".ariaDescription");
        translations.putEmpty(id + ".imageAlt");
    }

    @Override
    public void write(XmlWriter xml, TranslationBag translations) {
        if (!imageUrl.isBlank()) {
            attr("imageUrl", imageUrl);
        }
        super.write(xml, translations);
    }
}
