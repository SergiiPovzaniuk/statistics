package pl.consdata.eximee.formgenerator.component;

import java.util.ArrayList;
import java.util.List;
import pl.consdata.eximee.formgenerator.model.FormPage;
import pl.consdata.eximee.formgenerator.xml.TranslationBag;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

public final class GesInlineTable extends AbstractGesComponent {

    private final List<FormComponent> children = new ArrayList<>();
    private String title = "";

    public GesInlineTable(String id) {
        this(id, id, GridData.fill(16));
    }

    public GesInlineTable(String id, String mid, GridData layout) {
        super(id, mid, layout);
        attr("inheritLayout", "true");
        attr("titleKey", id + ".title");
    }

    public GesInlineTable title(String title) {
        this.title = title == null ? "" : title;
        return this;
    }

    public GesInlineTable add(FormComponent child) {
        children.add(child);
        return this;
    }

    @Override
    protected String elementName() {
        return "p1:GesInlineTable";
    }

    @Override
    protected String layoutDataTag() {
        return "p1:GesInlineTable.layoutData";
    }

    @Override
    protected void registerTranslations(TranslationBag translations) {
        translations.put(id + ".title", title);
    }

    @Override
    public void write(XmlWriter xml, TranslationBag translations) {
        registerTranslations(translations);
        StringBuilder attrs = new StringBuilder();
        attrs.append(XmlWriter.attr("id", id));
        attrs.append(XmlWriter.attr("mid", mid));
        attributes.forEach((k, v) -> attrs.append(XmlWriter.attr(k, v)));
        xml.open(elementName(), attrs.toString().trim()).indent();
        for (FormComponent child : children) {
            child.write(xml, translations);
        }
        writeListeningOn(xml);
        xml.empty("data:ClearOn");
        layout.write(xml, layoutDataTag());
        xml.open("p1:GesInlineTable.layout").indent();
        xml.empty("ns6:GridLayout", "makeColumnsEqualWidth=\"true\" numColumns=\"" + FormPage.COLUMNS + "\"");
        xml.outdent().close("p1:GesInlineTable.layout");
        xml.outdent().close(elementName());
    }
}
