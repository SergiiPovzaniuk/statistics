package pl.consdata.eximee.formgenerator.relation;

import java.util.List;
import java.util.UUID;
import pl.consdata.eximee.formgenerator.xml.XmlWriter;

/**
 * {@code data:ExternalValidator} with one or more input field bindings
 * (e.g. multi-checkbox "at least one required").
 */
public record ValidatorBinding(String name, List<InputField> inputs) {

    public record InputField(String localName, String serviceName, boolean nullable) {}

    public static ValidatorBinding simple(String name, String localName, String serviceName) {
        return new ValidatorBinding(name, List.of(new InputField(localName, serviceName, false)));
    }

    public void write(XmlWriter xml) {
        xml.open("data:ExternalValidator",
                        "name=\"" + XmlWriter.escape(name) + "\""
                                + " id=\"" + UUID.randomUUID() + "\""
                                + " type=\"VALIDATION_SCRIPT\" version=\"Current version\"")
                .indent();
        xml.open("data:InputFields").indent();
        for (InputField input : inputs) {
            xml.empty("data:Field",
                    "id=\"" + UUID.randomUUID() + "\""
                            + XmlWriter.attr("localName", input.localName())
                            + XmlWriter.attr("serviceName", input.serviceName())
                            + XmlWriter.attr("nullable", Boolean.toString(input.nullable())));
        }
        xml.outdent().close("data:InputFields");
        xml.outdent().close("data:ExternalValidator");
    }

    public static void writeAll(XmlWriter xml, List<ValidatorBinding> validators) {
        if (validators == null || validators.isEmpty()) {
            return;
        }
        xml.open("data:ExternalValidators").indent();
        validators.forEach(v -> v.write(xml));
        xml.outdent().close("data:ExternalValidators");
    }
}
