package pl.consdata.eximee.formgenerator.web;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.header;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

@SpringBootTest
@AutoConfigureMockMvc
class FormGeneratorControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    void getEmptyTemplateReturnsXml() throws Exception {
        mockMvc.perform(get("/api/forms/empty"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_XML))
                .andExpect(header().string(HttpHeaders.CONTENT_DISPOSITION,
                        "attachment; filename=\"empty_template.xml\""))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("<ecProcess>")));
    }

    @Test
    void postGenerateReturnsXmlFromSpec() throws Exception {
        String body = """
                {
                  "title": "Demo",
                  "pages": [
                    {
                      "id": "Page1",
                      "title": "Page",
                      "nextButton": "Next",
                      "components": [
                        { "type": "textField", "id": "street", "label": "Street", "span": 8, "formatter": "kyc_ulica" }
                      ]
                    }
                  ]
                }
                """;

        mockMvc.perform(post("/api/forms/generate")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_XML))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("id=\"street\"")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("formatter=\"kyc_ulica\"")));
    }

    @Test
    void getCatalogReturnsComponentAndRelationMetadata() throws Exception {
        mockMvc.perform(get("/api/forms/catalog"))
                .andExpect(status().isOk())
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("valueSourceId")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("section")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("radioGroup")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("upload_to_technical_field")))
                .andExpect(content().string(org.hamcrest.Matchers.containsString("PAGE_SERVICE")));
    }
}
