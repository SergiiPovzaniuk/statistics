package pl.consdata.eximee.formgenerator.service;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class EmptyTemplateGeneratorTest {

    private final EmptyTemplateGenerator generator = new EmptyTemplateGenerator(new FormXmlRenderer());

    @Test
    void generateReturnsEmptyTemplateXml() {
        String xml = generator.generate();

        assertThat(xml).contains("<ecProcess>");
        assertThat(xml).contains("<system:InternetForm");
        assertThat(xml).contains("id=\"Page1\"");
        assertThat(xml).contains("<ecTranslations>");
        assertThat(xml).contains("<ecMetadata>");
        assertThat(xml).contains("<ns6:Label");
    }
}
