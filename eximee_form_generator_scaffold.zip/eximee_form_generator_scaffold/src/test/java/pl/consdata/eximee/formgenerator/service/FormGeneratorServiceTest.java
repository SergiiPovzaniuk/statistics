package pl.consdata.eximee.formgenerator.service;

import static org.assertj.core.api.Assertions.assertThat;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import pl.consdata.eximee.formgenerator.dto.FormSpec;
import pl.consdata.eximee.formgenerator.relation.ValueSource;

class FormGeneratorServiceTest {

    private final ObjectMapper objectMapper = new ObjectMapper();
    private final FormGeneratorService service =
            new FormGeneratorService(new FormSpecMapper(), new FormXmlRenderer());

    @Test
    void generateBuildsTextFieldAndUploadFromCompactSpec() throws Exception {
        FormSpec spec = objectMapper.readValue("""
                {
                  "title": "Complaint",
                  "pages": [{
                    "id": "Page1",
                    "title": "Details",
                    "nextButton": "Next",
                    "components": [
                      { "type": "textField", "id": "email", "label": "Email", "expectedType": "EMAIL" },
                      { "type": "upload", "id": "files", "label": "Attachments", "extensions": "JPG, PDF", "maxFiles": 3 },
                      { "type": "textField", "id": "nrb", "mid": "validatorTest", "label": "Account",
                        "validators": [{ "name": "common_NRB_walidator", "serviceName": "number" }] }
                    ]
                  }]
                }
                """, FormSpec.class);

        String xml = service.generate(spec);

        assertThat(xml).contains("<ecProcess>");
        assertThat(xml).contains("id=\"email\"");
        assertThat(xml).contains("expectedType=\"EMAIL\"");
        assertThat(xml).contains("<p1:GesUploadFile");
        assertThat(xml).contains("common_NRB_walidator");
        assertThat(xml).contains("<item tag=\"pl\">Email</item>");
        assertThat(xml).contains("numColumns=\"16\"");
    }

    @Test
    void generateBuildsRelationsFromExample2Patterns() throws Exception {
        FormSpec spec = objectMapper.readValue("""
                {
                  "title": "Relations",
                  "pages": [{
                    "id": "Page9",
                    "title": "Upload",
                    "components": [
                      { "type": "text", "id": "GesText11", "text": "Header", "span": 11 },
                      { "type": "textField", "id": "GesTextField16", "label": "Name",
                        "mask": "^[a-zA-Z]+$" },
                      { "type": "textField", "id": "GesTextField14", "mid": "fileNamesPT",
                        "technicalField": true,
                        "valueSourceId": "GesUploadFile3$fileNames",
                        "listenTo": ["GesUploadFile3"] },
                      { "type": "upload", "id": "GesUploadFile3", "mid": "fileUploaderComponent",
                        "label": "Files", "requiredCount": 10, "maxFiles": 10 },
                      {
                        "type": "section",
                        "id": "GesSection5",
                        "title": "Covers",
                        "foldedCondition": "js:true",
                        "listenTo": ["GesCheckbox2", "GesCheckbox3"],
                        "validators": [{
                          "name": "wymaganyMinJedenCheckboxWalidator",
                          "inputs": [
                            { "localName": "GesCheckbox2", "serviceName": "oc", "nullable": false },
                            { "localName": "GesCheckbox3", "serviceName": "ac", "nullable": false }
                          ]
                        }],
                        "components": [
                          { "type": "checkbox", "id": "GesCheckbox2", "mid": "oc", "label": "OC", "span": 3 },
                          { "type": "checkbox", "id": "GesCheckbox3", "mid": "ac", "label": "AC", "span": 3 }
                        ]
                      },
                      {
                        "type": "radioGroup",
                        "id": "GesRadioGroup1",
                        "label": "Choice",
                        "defaultValue": "1",
                        "options": [
                          { "id": "GesRadio1", "option": "1", "text": "Yes" },
                          { "id": "GesRadio2", "option": "2", "text": "No" }
                        ]
                      },
                      {
                        "type": "custom",
                        "id": "GesCustomComponent7",
                        "artifact": "sme-comparison_table-*",
                        "listenTo": ["GesTextField11"],
                        "mappings": [{ "name": "data", "componentId": "GesTextField11" }]
                      },
                      { "type": "textField", "id": "GesTextField11", "mid": "data", "label": "Data" }
                    ]
                  }]
                }
                """, FormSpec.class);

        String xml = service.generate(spec);

        assertThat(xml).contains("valueSourceId=\"GesUploadFile3$fileNames\"");
        assertThat(xml).contains("<data:ListenField id=\"GesUploadFile3\"/>");
        assertThat(xml).contains("requiredCount=\"10\"");
        assertThat(xml).contains("<p1:GesSection");
        assertThat(xml).contains("wymaganyMinJedenCheckboxWalidator");
        assertThat(xml).contains("<p1:GesCheckbox");
        assertThat(xml).contains("<p1:GesRadioGroup");
        assertThat(xml).contains("option=\"1\"");
        assertThat(xml).contains("componentId=\"GesTextField11\"");
        assertThat(xml).contains("name=\"data\"");
        assertThat(ValueSource.parse("GesUploadFile3$fileNames").property()).isEqualTo("fileNames");
    }

    @Test
    void generateBuildsPageServiceDataSource() throws Exception {
        FormSpec spec = objectMapper.readValue("""
                {
                  "pages": [{
                    "id": "Page9",
                    "title": "P",
                    "components": [{
                      "type": "textField",
                      "id": "GesTextField15",
                      "span": 12,
                      "dataSource": {
                        "name": "PageService5",
                        "type": "PAGE_SERVICE",
                        "outputs": [{ "localName": "text", "serviceName": "validationResultMessages" }]
                      }
                    }]
                  }]
                }
                """, FormSpec.class);

        String xml = service.generate(spec);

        assertThat(xml).contains("name=\"PageService5\"");
        assertThat(xml).contains("type=\"PAGE_SERVICE\"");
        assertThat(xml).contains("serviceName=\"validationResultMessages\"");
    }

    @Test
    void generateBuildsExample2DedicatedComponents() throws Exception {
        FormSpec spec = objectMapper.readValue("""
                {
                  "pages": [{
                    "id": "Page1",
                    "title": "P",
                    "components": [
                      { "type": "datePicker", "id": "GesDatePicker3", "label": "Date",
                        "dateRange": "FUTURE_WITHOUT_TODAY" },
                      { "type": "combobox", "id": "GesCombobox1", "label": "City",
                        "options": [{ "option": "WAW", "text": "Warsaw" }] },
                      { "type": "stepSlider", "id": "GesStepSlider1", "mid": "rabat",
                        "label": "Discount", "maxValue": 100, "step": 10 },
                      { "type": "singleSlider", "id": "GesSingleSlider1", "label": "Amount" },
                      { "type": "image", "id": "GesImage1",
                        "imageUrl": "https://example.com/a.png" },
                      { "type": "pageNavigationLink", "id": "GesPageNavigationLink1",
                        "text": "Go", "pageMid": "Page1" },
                      { "type": "statements", "id": "GesStatements1", "label": "Consents" },
                      { "type": "inlineTable", "id": "GesInlineTable1", "title": "Table" },
                      {
                        "type": "repeatableSection",
                        "id": "GesRepeatableSection1",
                        "label": "People",
                        "components": [
                          { "type": "textField", "id": "GesTextField2", "label": "Name" }
                        ]
                      }
                    ]
                  }]
                }
                """, FormSpec.class);

        String xml = service.generate(spec);

        assertThat(xml).contains("<p1:GesDatePicker");
        assertThat(xml).contains("dateRange=\"FUTURE_WITHOUT_TODAY\"");
        assertThat(xml).contains("<p1:GesCombobox");
        assertThat(xml).contains("<p1:GesStepSlider");
        assertThat(xml).contains("maxValue=\"100\"");
        assertThat(xml).contains("<p1:GesSingleSlider");
        assertThat(xml).contains("<p1:GesImage");
        assertThat(xml).contains("imageUrl=\"https://example.com/a.png\"");
        assertThat(xml).contains("<p1:GesPageNavigationLink");
        assertThat(xml).contains("pageMid=\"Page1\"");
        assertThat(xml).contains("<p1:GesStatements");
        assertThat(xml).contains("<p1:GesInlineTable");
        assertThat(xml).contains("<p1:GesRepeatableSection");
    }
}
